"""
AutoBotic Unified Startup Script

Launches both Flask API (port 5003) and React Dev Server (port 3001) together.
Handles process cleanup on shutdown and stale port release.
"""

# =============================================================================
# IMPORTS
# =============================================================================

import subprocess
import sys
import os
import signal
import threading
import time
import atexit

# =============================================================================
# TERMINAL COLORS
# =============================================================================

class Colors:
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'

# =============================================================================
# BANNER
# =============================================================================

def print_banner():
    print(f"""
{Colors.BLUE}{Colors.BOLD}================================================================
                     AutoBotic Launcher                        
          Flask API (5003) + React Frontend (3001)              
================================================================{Colors.END}
""")

# =============================================================================
# PROCESS MANAGEMENT
# =============================================================================

def kill_process_tree(pid):
    """Kill a process and all its children on Windows."""
    if sys.platform == "win32":
        try:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10
            )
        except Exception as e:
            print(f"{Colors.YELLOW}[WARN]{Colors.END} Failed to kill process tree {pid}: {e}")
    else:
        try:
            os.killpg(os.getpgid(pid), signal.SIGTERM)
        except ProcessLookupError:
            pass


def kill_port_processes(port):
    """Kill any processes using a specific port on Windows."""
    if sys.platform == "win32":
        try:
            result = subprocess.run(
                ["netstat", "-ano"],
                capture_output=True,
                text=True,
                timeout=10
            )
            for line in result.stdout.split('\n'):
                if f":{port}" in line and "LISTENING" in line:
                    parts = line.split()
                    if parts:
                        pid = parts[-1]
                        try:
                            subprocess.run(
                                ["taskkill", "/F", "/PID", pid],
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL,
                                timeout=5
                            )
                            print(f"{Colors.YELLOW}[INFO]{Colors.END} Killed stale process on port {port} (PID {pid})")
                        except Exception:
                            pass
        except Exception:
            pass

# =============================================================================
# OUTPUT STREAMING
# =============================================================================

def stream_output(process, prefix, color):
    """Stream output from a process with a colored prefix."""
    if process.stdout:
        for line in iter(process.stdout.readline, ''):
            if line:
                print(f"{color}[{prefix}]{Colors.END} {line.strip()}", flush=True)

# =============================================================================
# MAIN
# =============================================================================

def main():
    print_banner()
    
    # Clean up any stale processes from previous runs on Windows
    if sys.platform == "win32":
        print(f"{Colors.YELLOW}[INFO]{Colors.END} Checking for stale processes on ports 5003 and 3001...")
        kill_port_processes(5003)
        kill_port_processes(3001)
        time.sleep(1)  # Give OS time to release ports
    
    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    frontend_dir = os.path.join(script_dir, "auto-listings-pro-main", "auto-listings-pro-main")
    
    # Check if frontend directory exists
    if not os.path.exists(frontend_dir):
        print(f"{Colors.RED}[ERROR]{Colors.END} Frontend directory not found: {frontend_dir}")
        sys.exit(1)
    
    # Python executable - prefer venv if available
    venv_python = os.path.join(script_dir, ".venv", "Scripts", "python.exe")
    if not os.path.exists(venv_python):
        venv_python = os.path.join(script_dir, "venv", "Scripts", "python.exe")
    
    if os.path.exists(venv_python):
        python_exe = venv_python
        print(f"{Colors.GREEN}[INFO]{Colors.END} Using venv Python: {python_exe}")
    else:
        python_exe = sys.executable
        print(f"{Colors.YELLOW}[WARN]{Colors.END} No venv found, using system Python: {python_exe}")
    
    # FIX 1: Determine the correct Flask entry point (app.py preferred, fallback to api.py)
    flask_entry = "app.py" if os.path.exists(os.path.join(script_dir, "app.py")) else "api.py"
    if not os.path.exists(os.path.join(script_dir, flask_entry)):
        print(f"{Colors.RED}[ERROR]{Colors.END} Flask entry point not found (tried app.py and api.py)")
        sys.exit(1)
    print(f"{Colors.GREEN}[INFO]{Colors.END} Flask entry point: {flask_entry}")

    # Check for npm
    npm_cmd = "npm.cmd" if sys.platform == "win32" else "npm"
    
    processes = []
    
    try:
        # ── Flask API ──────────────────────────────────────────────────────────
        print(f"{Colors.GREEN}[INFO]{Colors.END} Starting Flask API server on port 5003...")
        flask_env = os.environ.copy()
        flask_env['PYTHONUNBUFFERED'] = '1'
        flask_env['PYTHONIOENCODING'] = 'utf-8'
        
        # Use CREATE_NEW_PROCESS_GROUP on Windows for cleaner termination
        creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0
        
        flask_process = subprocess.Popen(
            [python_exe, flask_entry],
            cwd=script_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            encoding='utf-8',
            errors='replace',
            env=flask_env,
            creationflags=creation_flags
        )
        processes.append(("Flask", flask_process))
        
        # Give Flask a moment to start, and verify it actually came up
        time.sleep(2)
        if flask_process.poll() is not None:
            print(f"{Colors.RED}[ERROR]{Colors.END} Flask failed to start (exit code {flask_process.returncode}). "
                  f"Check {flask_entry} for errors.")
            sys.exit(1)
        
        # ── React Dev Server ───────────────────────────────────────────────────
        print(f"{Colors.BLUE}[INFO]{Colors.END} Starting React dev server on port 3001...")

        # FIX 2: On Windows, do NOT use shell=True with piped stdout — it causes
        # a stdout buffer deadlock that hangs the entire process.
        # Instead, pass npm.cmd directly as the executable (no shell needed).
        # Also add encoding/errors so readline() never blocks on bad characters.
        react_process = subprocess.Popen(
            [npm_cmd, "run", "dev"],
            cwd=frontend_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            encoding='utf-8',
            errors='replace',
            shell=False,   # ← explicit: never use shell=True with PIPE on Windows
            creationflags=creation_flags
        )
        processes.append(("React", react_process))
        
        print(f"""
{Colors.GREEN}{Colors.BOLD}================================================================
                     Servers Running                           
----------------------------------------------------------------
  Flask API:      http://localhost:5003                        
  React Frontend: http://localhost:3001                        
----------------------------------------------------------------
  Press Ctrl+C to stop both servers                            
================================================================{Colors.END}
""")
        
        # Stream output in background threads
        flask_thread = threading.Thread(
            target=stream_output, 
            args=(flask_process, "API", Colors.GREEN),
            daemon=True
        )
        react_thread = threading.Thread(
            target=stream_output, 
            args=(react_process, "WEB", Colors.BLUE),
            daemon=True
        )
        
        flask_thread.start()
        react_thread.start()
        
        # FIX 3: If a critical process dies, abort everything instead of silently looping
        while True:
            for name, proc in processes:
                if proc.poll() is not None:
                    print(f"{Colors.RED}[ERROR]{Colors.END} {name} process exited unexpectedly "
                          f"(code {proc.returncode}). Shutting down.")
                    raise SystemExit(1)   # triggers the finally cleanup block
            time.sleep(1)
            
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}[INFO]{Colors.END} Shutting down servers...")

    except SystemExit:
        pass  # already printed reason above, fall through to cleanup
        
    finally:
        # Cleanup: terminate all processes using process tree kill on Windows
        for name, proc in processes:
            if proc.poll() is None:
                print(f"{Colors.YELLOW}[INFO]{Colors.END} Stopping {name} (PID {proc.pid})...")
                kill_process_tree(proc.pid)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    print(f"{Colors.YELLOW}[WARN]{Colors.END} Force killing {name}...")
                    proc.kill()
        
        # Final cleanup: ensure ports are released
        if sys.platform == "win32":
            time.sleep(1)
            kill_port_processes(5003)
            kill_port_processes(3001)
        
        print(f"{Colors.GREEN}[INFO]{Colors.END} All servers stopped.")

if __name__ == "__main__":
    main()