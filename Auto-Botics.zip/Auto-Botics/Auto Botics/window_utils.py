"""
Reliable Chrome window maximization for SeleniumBase / uc Chrome.
Multiple concurrent browsers sometimes stay restored-size until maximize is retried.
"""

from __future__ import annotations

import logging
import time

logger = logging.getLogger(__name__)


def ensure_chrome_maximized(driver, headless: bool = False, retries: int = 4) -> None:
    """
    Ensure the browser window is maximized (Windows multi-monitor / UC quirks).
    Safe to call repeatedly (e.g. after navigation).
    """
    if headless or driver is None:
        return

    for attempt in range(1, retries + 1):
        try:
            handles = driver.window_handles
            if handles:
                driver.switch_to.window(handles[0])
        except Exception:
            pass

        try:
            driver.maximize_window()
        except Exception as e:
            logger.debug("maximize_window attempt %s: %s", attempt, e)

        try:
            cdp = getattr(driver, "cdp", None)
            if cdp is not None and hasattr(cdp, "maximize"):
                cdp.maximize()
        except Exception:
            pass

        try:
            size = driver.get_window_size()
            w = int(size.get("width", 0))
            # Typical maximized width on desktop is large; tiny window → retry
            if w >= 1100:
                return
        except Exception:
            pass

        time.sleep(0.4)

    try:
        driver.maximize_window()
    except Exception:
        pass
