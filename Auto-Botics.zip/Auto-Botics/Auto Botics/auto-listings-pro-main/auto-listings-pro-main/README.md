# AutoBotic

Facebook Marketplace Automation Tool

## Features

- **Multi-Account Support**: Manage multiple Facebook accounts
- **Automated Listing**: Create listings automatically with images, titles, and descriptions
- **Concurrent Browsers**: Run multiple browser instances simultaneously
- **Tag Management**: Add tags for better listing visibility
- **Price Configuration**: Set listing prices from the dashboard
- **Image Folder Selection**: Browse and select image folders directly

## Getting Started

### Requirements

- Python 3.9+
- Node.js & npm
- Chrome browser

### Installation

```sh
# Install Python dependencies
pip install -r requirements.txt

# Install frontend dependencies
cd auto-listings-pro-main/auto-listings-pro-main
npm install
```

### Running

```sh
python start.py
```

This will start both the API server and frontend, then open the app in your browser.

## Usage

1. **Add Accounts**: Go to Add Data → Accounts and add your Facebook accounts
2. **Set Tags & Price**: Configure tags and listing price
3. **Add Titles & Description**: Set your listing content
4. **Select Image Folder**: Browse to select your product images
5. **Run Automation**: Go to Automation tab and start

## Technologies

- Python / Flask (Backend API)
- React / TypeScript (Frontend)
- Selenium (Browser Automation)
- Tailwind CSS (Styling)

