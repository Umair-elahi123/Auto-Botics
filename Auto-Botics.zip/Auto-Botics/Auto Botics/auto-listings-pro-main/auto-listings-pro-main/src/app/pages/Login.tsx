import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { authApi } from "@/lib/api";
import { toast } from "sonner";

const Login = () => {
  const [tab, setTab] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast.error("Please fill in all fields");
      return;
    }
    
    setLoading(true);
    try {
      const response = await authApi.login(username, password);
      if (response.success && response.user) {
        localStorage.setItem("user", JSON.stringify(response.user));
        localStorage.setItem("loggedIn", "true");
        toast.success("Login successful!");
        navigate("/add-data");
      } else {
        toast.error(response.error || "Login failed");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !username || !password) {
      toast.error("Please fill in all fields");
      return;
    }
    if (password !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    if (password.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }
    
    setLoading(true);
    try {
      const response = await authApi.signup({ email, username, password, name });
      if (response.success) {
        toast.success("Account created! Please login.");
        setTab("login");
        setEmail("");
        setUsername("");
        setPassword("");
        setConfirmPassword("");
        setName("");
      } else {
        toast.error(response.error || "Signup failed");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen w-screen bg-gradient-to-br from-primary/5 via-background to-primary/10 flex flex-col items-center justify-center p-8">
      <div className="w-full max-w-md bg-card rounded-2xl shadow-2xl shadow-primary/10 overflow-hidden border border-border/30 h-[580px] flex flex-col">
        <div className="flex items-center justify-center py-4 border-b border-border/50 pl-6">
          <img src="/Auto_Botic.png" alt="AutoBotic" className="h-28 w-full max-w-[280px] object-contain drop-shadow-lg" />
        </div>
        <div className="flex border-b border-border/50 shrink-0">
          <button
            className={`flex-1 py-4 text-base font-semibold transition-all duration-200 relative ${tab === "login" ? "text-primary bg-primary/5" : "text-muted-foreground hover:bg-muted/30"}`}
            onClick={() => setTab("login")}
          >
            Login
            {tab === "login" && <span className="absolute bottom-0 left-0 right-0 h-[3px] bg-primary rounded-t-full" />}
          </button>
          <button
            className={`flex-1 py-4 text-base font-semibold transition-all duration-200 relative ${tab === "signup" ? "text-primary bg-primary/5" : "text-muted-foreground hover:bg-muted/30"}`}
            onClick={() => setTab("signup")}
          >
            Sign Up
            {tab === "signup" && <span className="absolute bottom-0 left-0 right-0 h-[3px] bg-primary rounded-t-full" />}
          </button>
        </div>
        
        {tab === "login" ? (
          <form onSubmit={handleLogin} className="p-8 space-y-6 flex-1">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-base">Username</Label>
              <Input 
                id="username" 
                value={username} 
                onChange={(e) => setUsername(e.target.value)} 
                placeholder="Enter your username" 
                disabled={loading}
                className="h-14 text-lg"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-base">Password</Label>
              <Input 
                id="password" 
                type="password" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                placeholder="Enter your password" 
                disabled={loading}
                className="h-14 text-lg"
              />
            </div>
            <Button type="submit" className="w-full h-14 text-xl font-semibold" disabled={loading}>
              {loading ? "Logging in..." : "Login"}
            </Button>
          </form>
        ) : (
          <form onSubmit={handleSignup} className="p-8 space-y-5 flex-1 overflow-y-auto">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-base">Full Name</Label>
              <Input 
                id="name" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Enter your name" 
                disabled={loading}
                className="h-14 text-lg"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-email" className="text-base">Email</Label>
              <Input 
                id="signup-email" 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                placeholder="Enter your email" 
                disabled={loading}
                className="h-14 text-lg"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-username" className="text-base">Username</Label>
              <Input 
                id="signup-username" 
                value={username} 
                onChange={(e) => setUsername(e.target.value)} 
                placeholder="Choose a username" 
                disabled={loading}
                className="h-14 text-lg"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="signup-password" className="text-base">Password</Label>
              <Input 
                id="signup-password" 
                type="password" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                placeholder="Create a password" 
                disabled={loading}
                className="h-14 text-lg"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm-password" className="text-base">Confirm Password</Label>
              <Input 
                id="confirm-password" 
                type="password" 
                value={confirmPassword} 
                onChange={(e) => setConfirmPassword(e.target.value)} 
                placeholder="Re-enter password" 
                disabled={loading}
                className="h-14 text-lg"
              />
            </div>
            <Button type="submit" className="w-full h-14 text-xl font-semibold" disabled={loading}>
              {loading ? "Creating Account..." : "Create Account"}
            </Button>
          </form>
        )}
      </div>
    </div>
  );
};

export default Login;
