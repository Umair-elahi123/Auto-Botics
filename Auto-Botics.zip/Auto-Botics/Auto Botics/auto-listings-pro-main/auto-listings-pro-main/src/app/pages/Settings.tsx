/**
 * Settings Page
 * 
 * User account and system settings:
 * - View account information
 * - Logout functionality
 * - Clear logs
 * - Reset all data (danger zone)
 */

import { useState, useEffect } from "react";
import { NavyCard } from "@/components/NavyCard";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useNavigate } from "react-router-dom";
import { LogOut, Trash2, RefreshCw } from "lucide-react";
import { settingsApi } from "@/lib/api";
import { toast } from "sonner";

const SettingsPage = () => {
  const [confirmReset, setConfirmReset] = useState(false);
  const [loading, setLoading] = useState(true);
  const [accountsCount, setAccountsCount] = useState(0);
  const [plan, setPlan] = useState("Professional");
  const [resetting, setResetting] = useState(false);
  const [clearingLogs, setClearingLogs] = useState(false);
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user") || '{"username": "User", "email": "user@autobotic.io"}');

  const fetchSettings = async () => {
    try {
      const response = await settingsApi.getUserSettings();
      setAccountsCount(response.accountsCount);
      setPlan(response.plan);
    } catch (error) {
      console.error("Failed to load settings:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("loggedIn");
    toast.success("Logged out successfully");
    navigate("/");
  };

  const handleClearLogs = async () => {
    setClearingLogs(true);
    try {
      const response = await settingsApi.clearLogs();
      toast.success(response.message || "Logs cleared");
    } catch (error) {
      toast.error("Failed to clear logs");
    } finally {
      setClearingLogs(false);
    }
  };

  const handleReset = async () => {
    if (!confirmReset) return;
    
    setResetting(true);
    try {
      const response = await settingsApi.resetData();
      if (response.success) {
        toast.success("All data has been reset!");
        setConfirmReset(false);
        fetchSettings();
      } else {
        toast.error(response.error || "Failed to reset data");
      }
    } catch (error) {
      toast.error("Failed to reset data");
    } finally {
      setResetting(false);
    }
  };

  return (
    <div className="space-y-6 h-full">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground text-sm mt-1">Manage your account and preferences</p>
      </div>

      <NavyCard title="Account Information">
        <div className="space-y-1">
          {[
            ["Username", user.username],
            ["Email", user.email],
            ["Plan", plan],
            ["Accounts", loading ? "Loading..." : `${accountsCount} connected`],
          ].map(([label, value]) => (
            <div key={label} className="flex justify-between py-3.5 border-b border-border/50 last:border-0">
              <span className="text-sm font-medium text-foreground">{label}</span>
              <span className="text-sm text-muted-foreground">{value}</span>
            </div>
          ))}
        </div>
      </NavyCard>

      <NavyCard title="System Actions">
        <div className="flex gap-3 flex-wrap">
          <Button variant="outline" className="gap-2" onClick={handleLogout}>
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
          <Button 
            variant="outline" 
            className="gap-2" 
            onClick={handleClearLogs}
            disabled={clearingLogs}
          >
            <RefreshCw className={`h-4 w-4 ${clearingLogs ? 'animate-spin' : ''}`} />
            {clearingLogs ? "Clearing..." : "Clear Logs"}
          </Button>
        </div>
      </NavyCard>

      <div className="bg-card rounded-xl border-2 border-destructive/30 shadow-sm overflow-hidden">
        <div className="bg-destructive/10 px-6 py-4 font-semibold text-base text-destructive flex items-center gap-2">
          <Trash2 className="h-4 w-4" />
          Danger Zone
        </div>
        <div className="p-6 space-y-5">
          <p className="text-sm text-muted-foreground">
            This will permanently delete all data including accounts, titles, descriptions, prices, logs, and analytics.
          </p>
          <div className="flex items-center gap-3">
            <Checkbox
              id="confirm"
              checked={confirmReset}
              onCheckedChange={(c) => setConfirmReset(!!c)}
              disabled={resetting}
              className="h-5 w-5 rounded border-2"
            />
            <label htmlFor="confirm" className="text-sm text-foreground cursor-pointer">
              I understand this action is irreversible
            </label>
          </div>
          <Button 
            variant="destructive" 
            disabled={!confirmReset || resetting} 
            className="gap-2"
            onClick={handleReset}
          >
            <Trash2 className="h-4 w-4" />
            {resetting ? "Resetting..." : "Reset All Data"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
