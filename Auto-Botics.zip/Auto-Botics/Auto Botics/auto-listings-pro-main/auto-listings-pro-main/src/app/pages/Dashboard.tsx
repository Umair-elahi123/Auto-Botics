/**
 * Dashboard Page
 * 
 * Displays marketplace performance overview with charts:
 * - Total IDs, clicks, saves, followers
 * - Clicks comparison between accounts
 */

import { useState, useEffect } from "react";
import { NavyCard } from "@/components/NavyCard";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { RefreshCw } from "lucide-react";
import { dashboardApi, DashboardData } from "@/lib/api";
import { toast } from "sonner";

const Dashboard = () => {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [data, setData] = useState<DashboardData | null>(null);
  const [selectedAccount, setSelectedAccount] = useState("all");

  const fetchData = async (showLoading = true) => {
    if (showLoading) setLoading(true);
    setRefreshing(true);
    try {
      const response = await dashboardApi.getOverview(selectedAccount);
      setData(response);
    } catch (error) {
      toast.error("Failed to load dashboard data");
      console.error(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedAccount]);

  const overviewData = data ? [
    { name: "Total IDs", value: data.overview.totalIds },
    { name: "Total Clicks", value: data.overview.totalClicks },
    { name: "Total Saves", value: data.overview.totalSaves },
    { name: "Total Followers", value: data.overview.totalFollowers },
  ] : [];

  const clicksData = data?.clicksComparison.map(item => ({
    account: item.account,
    clicks: item.clicks
  })) || [];

  const formatLastUpdated = (timestamp: string) => {
    if (!timestamp) return null;
    try {
      const date = new Date(timestamp);
      return date.toLocaleString('en-US', { 
        month: 'short', 
        day: 'numeric', 
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      });
    } catch {
      return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin"></div>
          <span className="text-muted-foreground text-sm">Loading dashboard...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 h-full">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-1">Overview of your marketplace performance</p>
        </div>
        <select 
          className="border-2 border-border rounded-xl px-4 py-2.5 text-sm bg-card text-foreground font-medium focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
          value={selectedAccount}
          onChange={(e) => setSelectedAccount(e.target.value)}
        >
          <option value="all">All Accounts</option>
          {data?.accounts.map((acc) => (
            <option key={acc.email} value={acc.email}>{acc.name}</option>
          ))}
        </select>
      </div>

      {data?.lastUpdated && (
        <div className="inline-flex items-center gap-2 text-sm text-green-700 bg-green-50 border border-green-200 px-4 py-2 rounded-xl">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          Last updated: {formatLastUpdated(data.lastUpdated)}
        </div>
      )}

      <NavyCard title="Overview">
        <div className="h-64">
          {overviewData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={overviewData} barSize={60}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 13%, 90%)" />
                <XAxis dataKey="name" tick={{ fontSize: 14 }} />
                <YAxis tick={{ fontSize: 14 }} />
                <Tooltip />
                <Bar dataKey="value" fill="hsl(240, 100%, 25%)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground text-lg">
              No data available
            </div>
          )}
        </div>
      </NavyCard>

      <NavyCard title="Clicks Comparison">
        <div className="h-64">
          {clicksData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={clicksData} barSize={60}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 13%, 90%)" />
                <XAxis dataKey="account" tick={{ fontSize: 14 }} />
                <YAxis tick={{ fontSize: 14 }} />
                <Tooltip />
                <Bar dataKey="clicks" fill="hsl(221, 82%, 48%)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground text-lg">
              No clicks data available
            </div>
          )}
        </div>
      </NavyCard>

      <div className="flex justify-end">
        <Button className="gap-2 text-base px-5 py-2" onClick={() => fetchData(false)} disabled={refreshing}>
          <RefreshCw className={`h-5 w-5 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? "Refreshing..." : "Refresh"}
        </Button>
      </div>
    </div>
  );
};

export default Dashboard;
