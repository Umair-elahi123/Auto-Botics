/**
 * Chatbot Page
 * 
 * Manages AI-powered chatbot for customer responses:
 * - Select accounts to run chatbot
 * - Start/stop chatbot monitoring
 * - View activity log of conversations
 */

import { useState, useEffect, useRef } from "react";
import { NavyCard } from "@/components/NavyCard";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { chatbotApi, ChatbotAccount, ChatbotActivity } from "@/lib/api";
import { toast } from "sonner";
import { RefreshCw, Eye, EyeOff, Trash2, CheckSquare, Square } from "lucide-react";

const Chatbot = () => {

  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [accounts, setAccounts] = useState<ChatbotAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [runningCount, setRunningCount] = useState(0);
  const [headless, setHeadless] = useState(false);
  const [activity, setActivity] = useState<ChatbotActivity[]>([]);
  const activityPollRef = useRef<number | null>(null);
  const initialLoadDone = useRef(false);

  const fetchAccounts = async () => {
    try {
      const response = await chatbotApi.getAccounts();
      setAccounts(response.accounts);
      setRunningCount(response.runningCount);
      // Auto-select all accounts on first load only
      if (!initialLoadDone.current && response.accounts.length > 0) {
        setSelected(new Set(response.accounts.map(a => a.email)));
        initialLoadDone.current = true;
      }
    } catch (error) {
      toast.error("Failed to load chatbot accounts");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchHeadless = async () => {
    try {
      const response = await chatbotApi.getHeadless();
      setHeadless(response.headless);
    } catch (error) {
      console.error("Failed to fetch headless state:", error);
    }
  };

  const fetchActivity = async () => {
    try {
      const response = await chatbotApi.getActivity();
      setActivity(response.activity);
    } catch (error) {
      console.error("Failed to fetch activity:", error);
    }
  };

  const toggleHeadless = async () => {
    try {
      const response = await chatbotApi.setHeadless(!headless);
      setHeadless(response.headless);
      toast.success(response.message || `Headless mode ${response.headless ? 'enabled' : 'disabled'}`);
    } catch (error) {
      toast.error("Failed to toggle headless mode");
    }
  };

  const clearActivity = async () => {
    try {
      await chatbotApi.clearActivity();
      setActivity([]);
      toast.success("Activity log cleared");
    } catch (error) {
      toast.error("Failed to clear activity log");
    }
  };

  useEffect(() => {
    fetchAccounts();
    fetchHeadless();
    fetchActivity();

    // Poll activity log every 5 seconds when chatbots are running
    activityPollRef.current = window.setInterval(fetchActivity, 5000);

    return () => {
      if (activityPollRef.current) {
        window.clearInterval(activityPollRef.current);
      }
    };
  }, []);

  const toggle = (email: string) => {
    setSelected((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(email)) {
        newSet.delete(email);
      } else {
        newSet.add(email);
      }
      return newSet;
    });
  };

  const toggleSelectAll = () => {
    if (selected.size === accounts.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(accounts.map(a => a.email)));
    }
  };

  const handleStart = async () => {
    const selectedIds = Array.from(selected);
    if (selectedIds.length === 0) {
      toast.error("Please select at least one account");
      return;
    }

    setActionLoading(true);
    try {
      const response = await chatbotApi.start(selectedIds, 'unread');
      if (response.started.length > 0) {
        toast.success(`Started ${response.started.length} chatbot(s)!`);
      }
      if (response.skipped.length > 0) {
        toast.info(`${response.skipped.length} account(s) already running`);
      }
      if (response.notFound.length > 0) {
        toast.error(`${response.notFound.length} account(s) not found`);
      }
      await fetchAccounts();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to start chatbot");
    } finally {
      setActionLoading(false);
    }
  };

  const handleStop = async () => {
    const selectedIds = Array.from(selected);
    const runningSelected = selectedIds.filter(id =>
      accounts.find(a => a.email === id)?.status === "running"
    );

    const idsToStop = runningSelected.length > 0
      ? runningSelected
      : accounts.filter(a => a.status === "running").map(a => a.email);

    if (idsToStop.length === 0) {
      toast.info("No chatbots are currently running");
      return;
    }

    setActionLoading(true);
    try {
      const response = await chatbotApi.stop(idsToStop);
      if (response.stopped.length > 0) {
        toast.success(`Stopped ${response.stopped.length} chatbot(s)`);
      }
      await fetchAccounts();
    } catch (error) {
      toast.error("Failed to stop chatbot");
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading chatbot accounts...</div>
      </div>
    );
  }

  if (accounts.length === 0) {
    return (
      <div className="space-y-5 h-full">
        <h1 className="text-2xl font-bold text-foreground">Chatbot</h1>
        <NavyCard title="No Accounts">
          <p className="text-muted-foreground text-lg">
            No accounts available. Please add accounts in the Add Data section.
          </p>
        </NavyCard>
      </div>
    );
  }

  const filteredAccounts = accounts;

  const statusLabel = runningCount > 0 ? `${runningCount} Running` : "Bot: Idle";

  return (
    <div className="space-y-5 h-full">
      <h1 className="text-2xl font-bold text-foreground">Chatbot</h1>

      <NavyCard title={`${selected.size} account(s) selected - ${statusLabel}`}>
        <div className="space-y-5">
          <div className="flex gap-3 items-center">
            <span className="text-base font-medium text-muted-foreground">Mode: Unread Messages Only</span>
            <Button
              variant="outline"
              onClick={toggleSelectAll}
              className="ml-auto gap-2 text-base px-5 py-2"
            >
              {selected.size === accounts.length ? <CheckSquare className="h-5 w-5" /> : <Square className="h-5 w-5" />}
              {selected.size === accounts.length ? "Deselect All" : "Select All"}
            </Button>
            <Button
              variant="outline"
              onClick={fetchAccounts}
              className="gap-2 text-base px-5 py-2"
            >
              <RefreshCw className="h-5 w-5" />
              Refresh
            </Button>
          </div>

          <div className="space-y-3 max-h-80 overflow-y-auto">
            {filteredAccounts.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground text-lg">
                No accounts available. Please add accounts in the Add Data section.
              </div>
            ) : (
              filteredAccounts.map((account) => (
                <div
                  key={account.id}
                  className={`flex items-center justify-between p-4 border border-border rounded-lg ${selected.has(account.email) ? "bg-primary/5" : "bg-card"
                    }`}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-primary flex items-center justify-center text-primary-foreground text-lg font-bold">
                      {account.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-lg font-medium text-foreground">{account.name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`inline-block w-2.5 h-2.5 rounded-full ${account.status === "running" ? "bg-green-500" : "bg-muted-foreground/40"
                          }`} />
                        <span className="text-base text-muted-foreground capitalize">{account.status}</span>
                        {account.unread > 0 && (
                          <span className="ml-2 text-sm bg-accent text-accent-foreground px-2 py-1 rounded-full font-medium">
                            {account.unread} unread
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <Checkbox
                    checked={selected.has(account.email)}
                    onCheckedChange={() => toggle(account.email)}
                    className="h-6 w-6"
                  />
                </div>
              ))
            )}
          </div>

          <div className="flex gap-4">
            <Button
              disabled={selected.size === 0 || actionLoading}
              className="flex-1 h-14 text-lg font-semibold"
              onClick={handleStart}
            >
              {actionLoading ? "Starting..." : "Start Chatbot"}
            </Button>
            <Button
              variant="outline"
              className="flex-1 h-14 text-lg font-semibold"
              onClick={handleStop}
              disabled={runningCount === 0 || actionLoading}
            >
              {actionLoading ? "Stopping..." : "Stop"}
            </Button>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div className="flex items-center gap-3">
              <span className="text-base font-medium">Hide Browsers:</span>
              <Button
                variant={headless ? "default" : "outline"}
                size="sm"
                onClick={toggleHeadless}
                className="gap-2"
              >
                {headless ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                {headless ? "ON" : "OFF"}
              </Button>
            </div>
            {runningCount > 0 && (
              <p className="text-base text-muted-foreground">
                {runningCount} browser(s) running {headless ? "hidden" : "visible"}
              </p>
            )}
          </div>
        </div>
      </NavyCard>

      <NavyCard title={`Activity Log (${activity.length})`}>
        <div className="space-y-4">
          <div className="flex justify-end">
            <Button variant="outline" size="sm" onClick={clearActivity} className="gap-2">
              <Trash2 className="h-4 w-4" />
              Clear
            </Button>
          </div>
          <div className="space-y-3 max-h-80 overflow-y-auto">
            {activity.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No activity yet. Start chatbots to see responses here.
              </div>
            ) : (
              [...activity].reverse().map((item, index) => (
                <div key={index} className="p-4 bg-muted/50 rounded-lg space-y-2 border border-border">
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span className="font-medium">{item.account.split('@')[0]}</span>
                    <span>{new Date(item.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm">
                      <span className="text-blue-600 font-medium">Customer:</span>{" "}
                      <span className="text-foreground">{item.customer_message.slice(0, 100)}{item.customer_message.length > 100 ? '...' : ''}</span>
                    </p>
                    <p className="text-sm">
                      <span className="text-green-600 font-medium">AI Response:</span>{" "}
                      <span className="text-foreground">{item.ai_response.slice(0, 150)}{item.ai_response.length > 150 ? '...' : ''}</span>
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </NavyCard>
    </div>
  );
};

export default Chatbot;
