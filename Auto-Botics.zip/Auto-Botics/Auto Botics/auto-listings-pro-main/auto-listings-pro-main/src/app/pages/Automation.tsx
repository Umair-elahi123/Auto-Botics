/**
 * Automation Page
 * 
 * Controls Facebook Marketplace listing automation:
 * - Configure batch size and concurrent browsers
 * - Start/stop automation with real-time progress
 * - View automation logs
 */

import { useState, useEffect, useRef } from "react";
import { NavyCard } from "@/components/NavyCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Play, Square, Save, Eye, EyeOff, CheckSquare } from "lucide-react";
import { automationApi, AutomationConfig, accountsApi, Account } from "@/lib/api";
import { toast } from "sonner";

const Automation = () => {
  const [config, setConfig] = useState<AutomationConfig | null>(null);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [batchSize, setBatchSize] = useState(2);
  const [savingConfig, setSavingConfig] = useState(false);
  const [headless, setHeadless] = useState(false);
  const pollIntervalRef = useRef<number | null>(null);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [selectedEmails, setSelectedEmails] = useState<Set<string>>(new Set());
  const initialAccountsLoaded = useRef(false);

  const fetchAccountsList = async () => {
    try {
      const res = await accountsApi.getAll();
      setAccounts(res.accounts);
      if (!initialAccountsLoaded.current && res.accounts.length > 0) {
        setSelectedEmails(new Set(res.accounts.map((a) => a.email)));
        initialAccountsLoaded.current = true;
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchConfig = async () => {
    try {
      const response = await automationApi.getConfig();
      setConfig(response.config);
      setBatchSize(response.config.batchSize);
    } catch (error) {
      toast.error("Failed to load automation config");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveConfig = async () => {
    setSavingConfig(true);
    try {
      const response = await automationApi.updateConfig({ batchSize });
      if (response.success) {
        toast.success(response.message || "Config updated!");
        fetchConfig();
      } else {
        toast.error(response.error || "Failed to update config");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to update config");
    } finally {
      setSavingConfig(false);
    }
  };

  const pollStatus = async () => {
    try {
      const status = await automationApi.getStatus();
      setRunning(status.running);
      setProgress(status.progress);
      setLogs(status.logs);
      
      if (!status.running && pollIntervalRef.current) {
        window.clearInterval(pollIntervalRef.current);
        pollIntervalRef.current = null;
      }
    } catch (error) {
      console.error("Failed to poll status:", error);
    }
  };

  const fetchHeadless = async () => {
    try {
      const res = await automationApi.getHeadless();
      setHeadless(res.headless);
    } catch (err) {
      console.error("Failed to fetch headless mode", err);
    }
  };

  const toggleHeadless = async () => {
    try {
      const res = await automationApi.setHeadless(!headless);
      if (res.success) {
        setHeadless(!headless);
        toast.success(res.headless ? "Browsers will be hidden" : "Browsers will be visible");
      }
    } catch (err) {
      toast.error("Failed to toggle headless mode");
    }
  };

  useEffect(() => {
    fetchConfig();
    fetchAccountsList();
    fetchHeadless();
    pollStatus();
    
    return () => {
      if (pollIntervalRef.current) {
        window.clearInterval(pollIntervalRef.current);
      }
    };
  }, []);

  const toggleAccount = (email: string) => {
    setSelectedEmails((prev) => {
      const next = new Set(prev);
      if (next.has(email)) next.delete(email);
      else next.add(email);
      return next;
    });
  };

  const toggleSelectAllAccounts = () => {
    if (selectedEmails.size === accounts.length) {
      setSelectedEmails(new Set());
    } else {
      setSelectedEmails(new Set(accounts.map((a) => a.email)));
    }
  };

  const handleStart = async () => {
    if (selectedEmails.size === 0) {
      toast.error("Select at least one Marketplace account to run");
      return;
    }
    try {
      const response = await automationApi.start(Array.from(selectedEmails));
      if (response.success) {
        setRunning(true);
        setProgress(5);
        setLogs(["[INFO] Starting automation engine...", "[INFO] Loading accounts..."]);
        toast.success("Automation started!");
        
        // Start polling for status
        pollIntervalRef.current = window.setInterval(pollStatus, 2000);
      } else {
        toast.error(response.error || "Failed to start automation");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to start automation");
    }
  };

  const handleStop = async () => {
    try {
      const response = await automationApi.stop();
      if (response.success) {
        setRunning(false);
        toast.success("Automation stopped");
        
        if (pollIntervalRef.current) {
          window.clearInterval(pollIntervalRef.current);
          pollIntervalRef.current = null;
        }
      }
    } catch (error) {
      toast.error("Failed to stop automation");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading automation config...</div>
      </div>
    );
  }

  const canStart =
    config &&
    config.accountsReady > 0 &&
    config.imagesAvailable > 0 &&
    selectedEmails.size > 0;

  return (
    <div className="space-y-5 h-full">
      <h1 className="text-2xl font-bold text-foreground">Automation</h1>

      <NavyCard title="Configuration">
        <div className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center py-4">
            <div>
              <p className="text-3xl font-bold text-foreground">{config?.accountsReady || 0}</p>
              <p className="text-base text-muted-foreground mt-1">Accounts Ready</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-foreground">{config?.imagesAvailable || 0}</p>
              <p className="text-base text-muted-foreground mt-1">Images Available</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-foreground">{config?.listingsToDo || 0}</p>
              <p className="text-base text-muted-foreground mt-1">Listings to do</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-border">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Concurrent Browsers:</span>
              <Input 
                type="number"
                min="1"
                max="5"
                value={batchSize}
                onChange={(e) => setBatchSize(Math.min(5, Math.max(1, Number(e.target.value))))}
                className="h-9 w-20 text-center text-sm"
              />
            </div>
            <Button 
              onClick={handleSaveConfig} 
              disabled={savingConfig || batchSize === config?.batchSize}
              className="h-9 px-4 gap-2"
            >
              <Save className="h-4 w-4" />
              {savingConfig ? "Saving..." : "Save"}
            </Button>
          </div>
        </div>
      </NavyCard>

      <NavyCard title={`Accounts for this run (${selectedEmails.size}/${accounts.length})`}>
        <div className="space-y-4">
          <div className="flex justify-end">
            <Button variant="outline" size="sm" onClick={toggleSelectAllAccounts} className="gap-2">
              <CheckSquare className="h-4 w-4" />
              {selectedEmails.size === accounts.length ? "Deselect all" : "Select all"}
            </Button>
          </div>
          {accounts.length === 0 ? (
            <p className="text-muted-foreground">No accounts in Add Data — add Facebook accounts first.</p>
          ) : (
            <div className="space-y-2 max-h-56 overflow-y-auto">
              {accounts.map((acc) => (
                <div
                  key={acc.id}
                  className={`flex items-center justify-between p-3 border rounded-lg ${
                    selectedEmails.has(acc.email) ? "bg-primary/5" : "bg-card"
                  }`}
                >
                  <div>
                    <p className="font-medium">{acc.email}</p>
                    <p className="text-sm text-muted-foreground">ID {acc.id}</p>
                  </div>
                  <Checkbox
                    checked={selectedEmails.has(acc.email)}
                    onCheckedChange={() => toggleAccount(acc.email)}
                  />
                </div>
              ))}
            </div>
          )}
          <p className="text-sm text-muted-foreground">
            Only checked accounts run. IDs match chatbot (1-based index or full email / phone string).
          </p>
        </div>
      </NavyCard>

      <NavyCard title="Control Panel">
        <div className="space-y-5">
          {!canStart && !running && (
            <p className="text-base text-yellow-600 bg-yellow-50 px-4 py-3 rounded-lg">
              {config?.accountsReady === 0 
                ? "No accounts configured. Please add accounts in Add Data section."
                : "No images found. Please add images to the folder."}
            </p>
          )}
          
          <p className="text-lg text-muted-foreground">
            {running ? "Automation is running..." : "Ready to start automation."}
          </p>
          
          <div className="flex gap-4">
            <Button 
              onClick={handleStart} 
              disabled={running || !canStart} 
              className="gap-3 flex-1 h-14 text-lg font-semibold"
            >
              <Play className="h-6 w-6" />
              START
            </Button>
            <Button 
              onClick={handleStop} 
              disabled={!running} 
              variant="outline"
              className="gap-3 flex-1 h-14 text-lg font-semibold"
            >
              <Square className="h-6 w-6" />
              STOP
            </Button>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div className="flex items-center gap-3">
              <span className="text-base font-medium">Hide Browsers:</span>
              <Button
                variant={headless ? "default" : "outline"}
                size="sm"
                onClick={toggleHeadless}
                className="gap-2"
              >
                {headless ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                {headless ? "ON" : "OFF"}
              </Button>
            </div>
            {running && (
              <p className="text-base text-muted-foreground">
                Running {headless ? "hidden" : "visible"}
              </p>
            )}
          </div>
          
          {(running || logs.length > 0) && (
            <>
              <Progress value={progress} className="h-3" />
              <div className="bg-muted rounded-lg p-4 max-h-52 overflow-auto font-mono text-sm text-foreground space-y-1">
                {logs.map((log, i) => (
                  <div 
                    key={i} 
                    className={log.includes("[ERROR]") ? "text-red-500" : ""}
                  >
                    {log}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </NavyCard>
    </div>
  );
};

export default Automation;
