/**
 * Add Data Page
 * 
 * Manage automation data inputs:
 * - Facebook accounts (email/password)
 * - Listing price configuration
 * - Description and title templates
 * - Image folder settings
 */

import { useState, useEffect } from "react";
import { NavyCard } from "@/components/NavyCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { X, RefreshCw, FolderOpen, Save, ArrowUpDown, DollarSign } from "lucide-react";
import { accountsApi, contentApi, imagesApi, priceApi, Account, ImagesData, ImagesConfig } from "@/lib/api";
import { toast } from "sonner";

const tabs = ["Accounts", "Price", "Description & Titles", "Image Folder"] as const;

const AddData = () => {
  const [activeTab, setActiveTab] = useState<typeof tabs[number]>("Accounts");
  
  // Accounts state
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [accountsLoading, setAccountsLoading] = useState(true);
  const [addingAccount, setAddingAccount] = useState(false);
  
  // Price state
  const [price, setPrice] = useState<number>(0);
  const [savingPrice, setSavingPrice] = useState(false);
  
  // Content state - single description + multiple titles
  const [description, setDescription] = useState("");
  const [titles, setTitles] = useState<string[]>([]);
  const [newTitle, setNewTitle] = useState("");
  const [contentLoading, setContentLoading] = useState(true);
  const [savingDescription, setSavingDescription] = useState(false);
  const [addingTitle, setAddingTitle] = useState(false);
  
  // Images state
  const [imagesData, setImagesData] = useState<ImagesData | null>(null);
  const [imagesLoading, setImagesLoading] = useState(true);
  const [imagesConfig, setImagesConfig] = useState<ImagesConfig | null>(null);
  const [folderPath, setFolderPath] = useState("");
  const [imagesPerListingMin, setImagesPerListingMin] = useState(1);
  const [imagesPerListingMax, setImagesPerListingMax] = useState(1);
  const [listingRangeStart, setListingRangeStart] = useState(1);
  const [listingRangeEnd, setListingRangeEnd] = useState(1);
  const [savingConfig, setSavingConfig] = useState(false);
  const [arrangingImages, setArrangingImages] = useState(false);

  const fetchAccounts = async () => {
    try {
      const response = await accountsApi.getAll();
      setAccounts(response.accounts);
    } catch (error) {
      toast.error("Failed to load accounts");
    } finally {
      setAccountsLoading(false);
    }
  };

  const fetchPrice = async () => {
    try {
      const response = await priceApi.get();
      setPrice(response.price || 0);
    } catch (error) {
      console.error("Failed to load price:", error);
    }
  };

  const handleSavePrice = async () => {
    setSavingPrice(true);
    try {
      const response = await priceApi.update(price);
      if (response.success) {
        toast.success("Price saved!");
      } else {
        toast.error(response.error || "Failed to save price");
      }
    } catch (error) {
      toast.error("Failed to save price");
    } finally {
      setSavingPrice(false);
    }
  };

  const fetchContent = async () => {
    try {
      const response = await contentApi.getAll();
      setDescription(response.description || "");
      setTitles(response.titles || []);
    } catch (error) {
      toast.error("Failed to load content");
    } finally {
      setContentLoading(false);
    }
  };

  const fetchImages = async () => {
    try {
      const response = await imagesApi.getStats();
      setImagesData(response);
    } catch (error) {
      toast.error("Failed to load images");
    } finally {
      setImagesLoading(false);
    }
  };

  const fetchImagesConfig = async () => {
    try {
      const response = await imagesApi.getConfig();
      setImagesConfig(response);
      setFolderPath(response.folderPath);
      setImagesPerListingMin(response.imagesPerListingMin);
      setImagesPerListingMax(response.imagesPerListingMax);
      setListingRangeStart(response.listingRangeStart || 1);
      setListingRangeEnd(response.listingRangeEnd || 1);
    } catch (error) {
      console.error("Failed to load images config:", error);
    }
  };

  const handleSaveConfig = async () => {
    setSavingConfig(true);
    try {
      const response = await imagesApi.updateConfig({
        folderPath,
        imagesPerListingMin,
        imagesPerListingMax
      });
      if (response.success) {
        toast.success(response.message || "Configuration saved!");
        setImagesConfig(response);
        fetchImages(); // Refresh images list
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to save configuration");
    } finally {
      setSavingConfig(false);
    }
  };

  const handleArrangeImages = async () => {
    setArrangingImages(true);
    try {
      const response = await imagesApi.arrangeImages();
      if (response.success) {
        toast.success(response.message || `Renamed ${response.count} images`);
        fetchImages(); // Refresh images list
      } else {
        toast.error(response.error || "Failed to arrange images");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to arrange images");
    } finally {
      setArrangingImages(false);
    }
  };

  useEffect(() => {
    fetchAccounts();
    fetchPrice();
    fetchContent();
    fetchImages();
    fetchImagesConfig();
  }, []);

  const handleAddAccount = async () => {
    if (!newEmail || !newPassword) {
      toast.error("Please fill in all fields");
      return;
    }
    setAddingAccount(true);
    try {
      const response = await accountsApi.add(newEmail, newPassword);
      if (response.success) {
        toast.success("Account added!");
        setNewEmail("");
        setNewPassword("");
        fetchAccounts();
      } else {
        toast.error(response.error || "Failed to add account");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to add account");
    } finally {
      setAddingAccount(false);
    }
  };

  const handleDeleteAccount = async (email: string) => {
    try {
      const response = await accountsApi.delete(email);
      if (response.success) {
        toast.success("Account deleted");
        fetchAccounts();
      } else {
        toast.error(response.error || "Failed to delete account");
      }
    } catch (error) {
      toast.error("Failed to delete account");
    }
  };

  const handleSaveDescription = async () => {
    setSavingDescription(true);
    try {
      const response = await contentApi.updateDescription(description);
      if (response.success) {
        toast.success("Description saved!");
      } else {
        toast.error(response.error || "Failed to save description");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to save description");
    } finally {
      setSavingDescription(false);
    }
  };

  const handleAddTitle = async () => {
    if (!newTitle) {
      toast.error("Please enter a title");
      return;
    }
    setAddingTitle(true);
    try {
      const response = await contentApi.addTitle(newTitle);
      if (response.success) {
        toast.success("Title added!");
        setNewTitle("");
        fetchContent();
      } else {
        toast.error(response.error || "Failed to add title");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to add title");
    } finally {
      setAddingTitle(false);
    }
  };

  const handleDeleteTitle = async (index: number) => {
    try {
      const response = await contentApi.deleteTitle(index);
      if (response.success) {
        toast.success("Title deleted");
        fetchContent();
      } else {
        toast.error(response.error || "Failed to delete title");
      }
    } catch (error) {
      toast.error("Failed to delete title");
    }
  };

  return (
    <div className="space-y-5 h-full">
      <h1 className="text-2xl font-bold text-foreground">Add Data</h1>

      <div className="flex border-b border-border">
        {tabs.map((t) => (
          <button
            key={t}
            className={`px-5 py-3 text-base font-semibold transition-colors ${activeTab === t ? "text-primary border-b-2 border-primary" : "text-muted-foreground"}`}
            onClick={() => setActiveTab(t)}
          >
            {t}
          </button>
        ))}
      </div>

      {activeTab === "Accounts" && (
        <div className="space-y-5">
          <NavyCard title="Add New Account">
            <div className="grid grid-cols-2 gap-5">
              <div className="space-y-2">
                <Label className="text-base">Email</Label>
                <Input placeholder="Enter email" type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} disabled={addingAccount} className="h-12 text-base" />
              </div>
              <div className="space-y-2">
                <Label className="text-base">Password</Label>
                <Input placeholder="Enter password" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} disabled={addingAccount} className="h-12 text-base" />
              </div>
              <div className="col-span-2">
                <Button className="w-full h-12 text-base font-semibold" onClick={handleAddAccount} disabled={addingAccount}>
                  {addingAccount ? "Adding..." : "Add Account"}
                </Button>
              </div>
            </div>
          </NavyCard>
          <NavyCard title="Existing Accounts">
            {accountsLoading ? (
              <div className="text-center py-6 text-muted-foreground text-lg">Loading accounts...</div>
            ) : accounts.length === 0 ? (
              <div className="text-center py-6 text-muted-foreground text-lg">No accounts added yet.</div>
            ) : (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {accounts.map((acc) => (
                  <div key={acc.id} className="flex items-center justify-between p-4 bg-card border border-border rounded-lg border-l-4 border-l-primary">
                    <div>
                      <p className="text-lg font-medium text-foreground">{acc.name}</p>
                      <p className="text-base text-muted-foreground">{acc.email}</p>
                    </div>
                    <Button variant="ghost" onClick={() => handleDeleteAccount(acc.email)}>
                      <X className="h-5 w-5" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </NavyCard>
        </div>
      )}

      {activeTab === "Price" && (
        <div className="space-y-5">
          <NavyCard title="Price">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Label className="text-base flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Listing Price
                </Label>
                <Input 
                  type="number" 
                  min="0" 
                  step="0.01"
                  value={price} 
                  onChange={(e) => setPrice(Number(e.target.value))} 
                  className="h-12 text-base w-32" 
                  placeholder="0.00"
                />
                <Button onClick={handleSavePrice} disabled={savingPrice} className="h-12 px-6 text-base gap-2">
                  <Save className="h-4 w-4" />
                  {savingPrice ? "Saving..." : "Save Price"}
                </Button>
              </div>
            </div>
          </NavyCard>
        </div>
      )}

      {activeTab === "Description & Titles" && (
        <div className="space-y-5">
          <NavyCard title="Listing Description">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-base">Description (used for all listings)</Label>
                <Textarea 
                  placeholder="Enter your listing description..." 
                  className="min-h-[150px] text-base" 
                  value={description} 
                  onChange={(e) => setDescription(e.target.value)} 
                  disabled={savingDescription}
                />
              </div>
              <Button onClick={handleSaveDescription} disabled={savingDescription} className="h-12 px-6 text-base gap-2">
                <Save className="h-4 w-4" />
                {savingDescription ? "Saving..." : "Save Description"}
              </Button>
            </div>
          </NavyCard>
          
          <NavyCard title="Listing Titles">
            <div className="space-y-4">
              <div className="flex gap-3">
                <Input 
                  placeholder="Enter a title..." 
                  value={newTitle} 
                  onChange={(e) => setNewTitle(e.target.value)} 
                  disabled={addingTitle} 
                  onKeyDown={(e) => e.key === 'Enter' && handleAddTitle()} 
                  className="h-12 text-base" 
                />
                <Button onClick={handleAddTitle} disabled={addingTitle} className="h-12 px-6 text-base">
                  {addingTitle ? "Adding..." : "Add Title"}
                </Button>
              </div>
              
              {contentLoading ? (
                <div className="text-center py-5 text-muted-foreground text-base">Loading titles...</div>
              ) : titles.length === 0 ? (
                <div className="text-center py-5 text-muted-foreground text-base">No titles added yet. Add titles above.</div>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {titles.map((title, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted/50 border border-border rounded-lg">
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-medium text-muted-foreground w-6">{index + 1}.</span>
                        <span className="text-base text-foreground">{title}</span>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => handleDeleteTitle(index)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </NavyCard>
        </div>
      )}

      {activeTab === "Image Folder" && (
        <div className="space-y-5">
          <NavyCard title="Folder Configuration">
            <div className="space-y-5">
              <div className="space-y-2">
                <Label className="text-base flex items-center gap-2">
                  <FolderOpen className="h-4 w-4" />
                  Image Folder Path
                </Label>
                <div className="flex gap-3">
                  <div className="flex-1 h-12 px-4 flex items-center bg-muted rounded-md border border-border text-base text-foreground">
                    {folderPath || "Not configured"}
                  </div>
                  <Button 
                    onClick={async () => {
                      try {
                        const res = await fetch('/api/images/browse', { method: 'POST' });
                        const data = await res.json();
                        if (data.success) {
                          setFolderPath(data.folderPath);
                          fetchImages();
                        }
                      } catch (err) {
                        console.error('Browse failed:', err);
                      }
                    }}
                    className="h-12 px-6 text-base gap-2"
                  >
                    <FolderOpen className="h-5 w-5" />
                    Browse
                  </Button>
                </div>
              </div>
              <div className="flex gap-3">
                <Button 
                  onClick={handleArrangeImages} 
                  disabled={arrangingImages || !imagesData?.folderExists}
                  className="h-12 px-6 text-base gap-3"
                >
                  <ArrowUpDown className="h-5 w-5" />
                  {arrangingImages ? "Arranging..." : "Arrange Images"}
                </Button>
                <Button onClick={fetchImages} variant="outline" className="h-12 px-6 text-base gap-3">
                  <RefreshCw className="h-5 w-5" />
                  Scan Folder
                </Button>
              </div>
            </div>
          </NavyCard>

          <NavyCard title="Folder Status">
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div className="p-5 bg-muted rounded-md">
                  <p className="text-3xl font-bold text-foreground">{imagesLoading ? "..." : imagesData?.imageCount || 0}</p>
                  <p className="text-base text-muted-foreground">Total Images</p>
                </div>
                <div className="p-5 bg-muted rounded-md">
                  <p className={`text-3xl font-bold ${imagesData?.folderExists ? "text-green-600" : "text-red-600"}`}>
                    {imagesLoading ? "..." : imagesData?.folderExists ? "Yes" : "No"}
                  </p>
                  <p className="text-base text-muted-foreground">Connected</p>
                </div>
                <div className="p-5 bg-muted rounded-md min-w-0">
                  <div className="flex items-center justify-center gap-1 mb-2 whitespace-nowrap">
                    <Input 
                      type="number"
                      min="1"
                      max={imagesData?.imageCount || 999}
                      value={listingRangeStart}
                      onChange={(e) => setListingRangeStart(Math.max(1, Math.min(Number(e.target.value), listingRangeEnd)))}
                      className="h-10 w-12 text-center text-lg font-bold px-1"
                    />
                    <span className="text-xl font-bold text-muted-foreground px-1">-</span>
                    <Input 
                      type="number"
                      min={listingRangeStart}
                      max={imagesData?.imageCount || 999}
                      value={listingRangeEnd}
                      onChange={(e) => setListingRangeEnd(Math.max(listingRangeStart, Math.min(Number(e.target.value), imagesData?.imageCount || 999)))}
                      className="h-10 w-12 text-center text-lg font-bold px-1"
                    />
                  </div>
                  <p className="text-base text-muted-foreground text-center">Listings to do</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Button 
                  onClick={async () => {
                    try {
                      const response = await imagesApi.updateConfig({
                        listingRangeStart,
                        listingRangeEnd
                      });
                      if (response.success) {
                        toast.success("Listing range saved!");
                      }
                    } catch (error) {
                      toast.error("Failed to save listing range");
                    }
                  }}
                  className="h-12 px-6 text-base gap-3"
                >
                  <Save className="h-5 w-5" />
                  Save Range
                </Button>
                <Button onClick={fetchImages} variant="outline" className="h-12 px-6 text-base gap-3">
                  <RefreshCw className="h-5 w-5" />
                  Scan Folder
                </Button>
              </div>
            </div>
          </NavyCard>

          {imagesData && imagesData.images.length > 0 && (
            <NavyCard title={`Image Files (${imagesData.images.length})`}>
              <div className="grid grid-cols-6 gap-3 max-h-48 overflow-y-auto">
                {imagesData.images.slice(0, 30).map((img, index) => (
                  <div key={index} className="p-3 bg-muted rounded text-base text-center truncate" title={img}>
                    {img.length > 12 ? img.slice(0, 9) + "..." : img}
                  </div>
                ))}
              </div>
              {imagesData.images.length > 30 && (
                <p className="text-center text-base text-muted-foreground mt-3">
                  Showing 30 of {imagesData.images.length} images
                </p>
              )}
            </NavyCard>
          )}
        </div>
      )}
    </div>
  );
};

export default AddData;
