/**
 * API Client Module
 * 
 * Centralized API client for communicating with the Flask backend.
 * All API endpoints are organized by feature (auth, dashboard, accounts, etc.)
 */

const API_BASE_URL = '/api';

interface ApiResponse<T = unknown> {
  success: boolean;
  error?: string;
  message?: string;
  data?: T;
}

/**
 * Generic fetch wrapper with error handling
 */
async function fetchApi<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const defaultHeaders: HeadersInit = {
    'Content-Type': 'application/json',
  };

  const response = await fetch(url, {
    ...options,
    headers: {
      ...defaultHeaders,
      ...options.headers,
    },
  });

  const text = await response.text();
  const data = text ? JSON.parse(text) : {};
  
  if (!response.ok) {
    throw new Error(data.error || 'An error occurred');
  }
  
  return data;
}

// =============================================================================
// AUTH API
// =============================================================================

export const authApi = {
  login: (username: string, password: string) =>
    fetchApi<{ success: boolean; user?: { username: string; email: string }; error?: string }>(
      '/auth/login',
      {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      }
    ),
  
  signup: (data: { email: string; username: string; password: string; name?: string }) =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      '/auth/signup',
      {
        method: 'POST',
        body: JSON.stringify(data),
      }
    ),
};

// =============================================================================
// DASHBOARD API
// =============================================================================

export interface DashboardOverview {
  totalIds: number;
  totalClicks: number;
  totalSaves: number;
  totalFollowers: number;
}

export interface ClicksComparison {
  account: string;
  email: string;
  clicks: number;
}

export interface DashboardData {
  success: boolean;
  overview: DashboardOverview;
  lastUpdated: string;
  clicksComparison: ClicksComparison[];
  accounts: { email: string; name: string }[];
}

export const dashboardApi = {
  getOverview: (account: string = 'all') =>
    fetchApi<DashboardData>(`/dashboard/overview?account=${encodeURIComponent(account)}`),
};

// =============================================================================
// ACCOUNTS API
// =============================================================================

export interface Account {
  id: number;
  email: string;
  name: string;
  added_at?: string;
}

export const accountsApi = {
  getAll: () =>
    fetchApi<{ success: boolean; accounts: Account[] }>('/accounts'),
  
  add: (email: string, password: string) =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      '/accounts',
      {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      }
    ),
  
  delete: (email: string) =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      `/accounts/${encodeURIComponent(email)}`,
      { method: 'DELETE' }
    ),
};

// Tags API
export const tagsApi = {
  getAll: () =>
    fetchApi<{ success: boolean; tags: string[] }>('/tags'),
  
  add: (tag: string) =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      '/tags',
      {
        method: 'POST',
        body: JSON.stringify({ tag }),
      }
    ),
  
  delete: (tag: string) =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      `/tags/${encodeURIComponent(tag)}`,
      { method: 'DELETE' }
    ),
};

// Price API
export const priceApi = {
  get: () =>
    fetchApi<{ success: boolean; price: number }>('/price'),
  
  update: (price: number) =>
    fetchApi<{ success: boolean; message?: string; price?: number; error?: string }>(
      '/price',
      {
        method: 'PUT',
        body: JSON.stringify({ price }),
      }
    ),
};

// Content API
export const contentApi = {
  getAll: () =>
    fetchApi<{ success: boolean; description: string; titles: string[] }>('/content'),
  
  updateDescription: (description: string) =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      '/content/description',
      {
        method: 'PUT',
        body: JSON.stringify({ description }),
      }
    ),
  
  addTitle: (title: string) =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      '/content/titles',
      {
        method: 'POST',
        body: JSON.stringify({ title }),
      }
    ),
  
  deleteTitle: (index: number) =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      `/content/titles/${index}`,
      { method: 'DELETE' }
    ),
};

// Images API
export interface ImagesData {
  success: boolean;
  folderPath: string;
  folderExists: boolean;
  imageCount: number;
  images: string[];
}

export interface ImagesConfig {
  success: boolean;
  folderPath: string;
  imagesPerListingMin: number;
  imagesPerListingMax: number;
  listingRangeStart: number;
  listingRangeEnd: number;
  message?: string;
}

export const imagesApi = {
  getStats: () => fetchApi<ImagesData>('/images'),
  
  getConfig: () => fetchApi<ImagesConfig>('/images/config'),
  
  updateConfig: (config: { folderPath?: string; imagesPerListingMin?: number; imagesPerListingMax?: number; listingRangeStart?: number; listingRangeEnd?: number }) =>
    fetchApi<ImagesConfig>('/images/config', {
      method: 'PUT',
      body: JSON.stringify(config),
    }),
  
  arrangeImages: () =>
    fetchApi<{ success: boolean; message?: string; count?: number; error?: string }>(
      '/images/arrange',
      { method: 'POST' }
    ),
};

// Automation API
export interface AutomationConfig {
  accountsReady: number;
  imagesAvailable: number;
  batchSize: number;
  listingsToDo: number;
  folderPath: string;
}

export interface AutomationStatus {
  success: boolean;
  running: boolean;
  progress: number;
  logs: string[];
  startTime?: string;
}

export const automationApi = {
  getConfig: () =>
    fetchApi<{ success: boolean; config: AutomationConfig }>('/automation/config'),
  
  updateConfig: (config: { batchSize?: number }) =>
    fetchApi<{ success: boolean; message?: string; error?: string }>
      ('/automation/config',
      { method: 'PUT', body: JSON.stringify(config) }
    ),
  
  getStatus: () =>
    fetchApi<AutomationStatus>('/automation/status'),
  
  start: (accountIds?: (string | number)[]) =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      '/automation/start',
      {
        method: 'POST',
        body: JSON.stringify(
          accountIds && accountIds.length > 0 ? { accountIds } : {}
        ),
      }
    ),
  
  stop: () =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      '/automation/stop',
      { method: 'POST' }
    ),
  
  getHeadless: () =>
    fetchApi<{ success: boolean; headless: boolean }>('/automation/headless'),
  
  setHeadless: (enabled: boolean) =>
    fetchApi<{ success: boolean; headless: boolean; message?: string }>(
      '/automation/headless',
      { method: 'PUT', body: JSON.stringify({ enabled }) }
    ),
};

// Chatbot API
export interface ChatbotAccount {
  id: number;
  email: string;
  name: string;
  status: 'idle' | 'running';
  unread: number;
}

export const chatbotApi = {
  getAccounts: () =>
    fetchApi<{ success: boolean; accounts: ChatbotAccount[]; runningCount: number }>(
      '/chatbot/accounts'
    ),
  
  start: (accountIds: string[], mode: 'unread' | 'all' = 'unread') =>
    fetchApi<{ success: boolean; started: string[]; skipped: string[]; notFound: string[]; message: string }>(
      '/chatbot/start',
      {
        method: 'POST',
        body: JSON.stringify({ accountIds, mode }),
      }
    ),
  
  stop: (accountIds?: string[]) =>
    fetchApi<{ success: boolean; stopped: string[]; message: string }>(
      '/chatbot/stop',
      {
        method: 'POST',
        body: JSON.stringify({ accountIds }),
      }
    ),
  
  getConversations: (email: string) =>
    fetchApi<{ success: boolean; conversations: unknown[] }>(
      `/chatbot/conversations/${encodeURIComponent(email)}`
    ),
  
  getHeadless: () =>
    fetchApi<{ success: boolean; headless: boolean }>('/chatbot/headless'),
  
  setHeadless: (enabled: boolean) =>
    fetchApi<{ success: boolean; headless: boolean; message?: string }>(
      '/chatbot/headless',
      { method: 'PUT', body: JSON.stringify({ enabled }) }
    ),
  
  getActivity: () =>
    fetchApi<{ success: boolean; activity: ChatbotActivity[] }>('/chatbot/activity'),
  
  clearActivity: () =>
    fetchApi<{ success: boolean; message?: string }>(
      '/chatbot/activity',
      { method: 'DELETE' }
    ),
};

export interface ChatbotActivity {
  timestamp: string;
  account: string;
  customer_id: string;
  customer_message: string;
  ai_response: string;
}

// Settings API
export const settingsApi = {
  getUserSettings: () =>
    fetchApi<{ success: boolean; accountsCount: number; plan: string }>(
      '/settings/user'
    ),
  
  resetData: () =>
    fetchApi<{ success: boolean; message?: string; error?: string }>(
      '/settings/reset',
      { method: 'POST' }
    ),
  
  clearLogs: () =>
    fetchApi<{ success: boolean; message?: string }>(
      '/settings/clear-logs',
      { method: 'POST' }
    ),
};
