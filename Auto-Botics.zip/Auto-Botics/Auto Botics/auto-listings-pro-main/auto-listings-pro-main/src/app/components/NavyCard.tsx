import { ReactNode } from "react";

interface NavyCardProps {
  title: string;
  children: ReactNode;
  className?: string;
  icon?: ReactNode;
}

export const NavyCard = ({ title, children, className = "", icon }: NavyCardProps) => (
  <div className={`bg-card rounded-xl border border-border/50 shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden ${className}`}>
    <div className="bg-gradient-to-r from-primary to-primary/90 text-primary-foreground px-6 py-4 font-semibold text-base flex items-center gap-3">
      {icon && <span className="opacity-90">{icon}</span>}
      {title}
    </div>
    <div className="p-6">{children}</div>
  </div>
);
