import { LayoutDashboard, Zap, PlusCircle, MessageSquare, Settings } from "lucide-react";
import { NavLink } from "react-router-dom";
import { useLayout } from "./AppLayout";

const navItems = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
  { title: "Add Data", url: "/add-data", icon: PlusCircle },
  { title: "Automation", url: "/automation", icon: Zap },
  { title: "Chatbot", url: "/chatbot", icon: MessageSquare },
  { title: "Settings", url: "/settings", icon: Settings },
];

export const AppSidebar = () => {
  const { sidebarOpen } = useLayout();

  if (!sidebarOpen) return null;

  return (
    <aside className="w-[240px] bg-card border-r border-border/50 shrink-0 flex flex-col h-full overflow-y-auto shadow-sm">
      <nav className="flex flex-col gap-1.5 p-4 mt-3">
        {navItems.map((item) => (
          <NavLink
            key={item.title}
            to={item.url}
            className={({ isActive }) =>
              `nav-item group ${isActive ? "nav-item-active" : "nav-item-inactive"}`
            }
          >
            <item.icon className="h-5 w-5 transition-transform group-hover:scale-110" />
            <span className="font-medium">{item.title}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
};
