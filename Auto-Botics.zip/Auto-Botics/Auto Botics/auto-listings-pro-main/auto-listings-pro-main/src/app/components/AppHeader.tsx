import { Menu, User, ChevronDown } from "lucide-react";
import { useLayout } from "./AppLayout";

export const AppHeader = () => {
  const { setSidebarOpen, sidebarOpen } = useLayout();
  const user = JSON.parse(localStorage.getItem("user") || '{"username": "User"}');

  return (
    <header className="bg-gradient-to-r from-primary via-primary to-primary/95 h-16 flex items-center justify-between px-6 shrink-0 z-50 shadow-lg shadow-primary/20">
      <div className="flex items-center gap-5">
        <button 
          onClick={() => setSidebarOpen(!sidebarOpen)} 
          className="text-primary-foreground/90 hover:text-primary-foreground hover:bg-white/10 p-2 rounded-lg transition-all duration-200"
        >
          <Menu className="h-6 w-6" />
        </button>
        <div className="flex items-center gap-3">
          <div className="bg-white/10 rounded-xl p-1.5">
            <img src="/Auto_Botic_1.png" alt="AutoBotic" className="h-8 w-auto" />
          </div>
          <div className="flex flex-col">
            <span className="text-primary-foreground font-bold text-lg tracking-tight leading-none">Auto Botic</span>
            <span className="text-primary-foreground/60 text-xs font-medium">Automation Platform</span>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-3 bg-white/10 hover:bg-white/15 rounded-xl px-4 py-2 cursor-pointer transition-all duration-200">
          <div className="bg-primary-foreground/20 rounded-full p-1.5">
            <User className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-primary-foreground text-sm font-medium">{user.username || 'User'}</span>
          <ChevronDown className="h-4 w-4 text-primary-foreground/70" />
        </div>
      </div>
    </header>
  );
};
