"""
AutoBotic Port Cleanup Utility

Cleans up stuck processes on ports 5001, 5003, 8080, and 3001.
Also kills orphaned Chrome and Node processes from Selenium.
Handles zombie sockets (TIME_WAIT, CLOSE_WAIT states).

Usage: python cleanup_ports.py
"""

# =============================================================================
# IMPORTS
# =============================================================================

import subprocess
import sys
import time

# =============================================================================
# PORT CLEANUP
# =============================================================================

def get_pids_on_port(port):
    """Get all PIDs using a specific port."""
    pids = set()
    try:
        result = subprocess.run(
            ["netstat", "-ano"],
            capture_output=True,
            text=True,
            timeout=10
        )
        for line in result.stdout.split('\n'):
            if f":{port}" in line:
                parts = line.split()
                if len(parts) >= 5:
                    pid = parts[-1]
                    if pid.isdigit() and int(pid) > 0:
                        pids.add(pid)
    except Exception:
        pass
    return pids


def is_port_free(port):
    """Check if port is completely free (no LISTENING)."""
    try:
        result = subprocess.run(
            ["netstat", "-ano"],
            capture_output=True,
            text=True,
            timeout=10
        )
        for line in result.stdout.split('\n'):
            if f":{port}" in line and "LISTENING" in line:
                return False
        return True
    except Exception:
        return False


def can_bind_port(port):
    """Test if we can actually bind to the port (works even with zombie sockets)."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('0.0.0.0', port))
        s.close()
        return True
    except Exception:
        return False


def kill_pid(pid):
    """Kill a process by PID, return True if successful or already dead."""
    try:
        result = subprocess.run(
            ["taskkill", "/F", "/T", "/PID", str(pid)],
            capture_output=True,
            text=True,
            timeout=5
        )
        return "SUCCESS" in result.stdout or "not found" in result.stderr.lower()
    except Exception:
        return False


def kill_port(port, max_retries=3, wait_seconds=2):
    """Kill processes using a specific port on Windows with retry logic."""
    if sys.platform != "win32":
        print(f"This script is for Windows only. Use 'lsof -ti:{port} | xargs kill -9' on Linux/Mac")
        return
    
    for attempt in range(max_retries):
        pids = get_pids_on_port(port)
        
        if not pids:
            if is_port_free(port):
                if attempt == 0:
                    print(f"Port {port}: Already free")
                else:
                    print(f"Port {port}: Now free")
                return
            else:
                # Port in TIME_WAIT/CLOSE_WAIT state - need to wait
                print(f"Port {port}: Waiting for zombie sockets to clear...")
                time.sleep(wait_seconds)
                continue
        
        # Kill all PIDs
        for pid in pids:
            kill_pid(pid)
            print(f"Port {port}: Killed PID {pid}")
        
        # Wait and verify
        time.sleep(1)
        
        if is_port_free(port):
            print(f"Port {port}: Successfully freed")
            return
    
    # Final check
    if is_port_free(port):
        print(f"Port {port}: Freed after retries")
    else:
        print(f"Port {port}: WARNING - Still has zombie sockets (will auto-clear in ~60s)")

# =============================================================================
# ORPHAN PROCESS CLEANUP
# =============================================================================

def kill_orphan_chrome():
    """Kill orphaned Chrome/chromedriver processes from Selenium."""
    if sys.platform != "win32":
        return
    
    killed = False
    try:
        result = subprocess.run(
            ["taskkill", "/F", "/IM", "chromedriver.exe"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if "SUCCESS" in result.stdout:
            print("Killed orphaned chromedriver processes")
            killed = True
    except Exception:
        pass
    
    if not killed:
        print("No orphaned chromedriver found")


def main():
    print("=" * 50)
    print("AutoBotic Port Cleanup Utility")
    print("=" * 50)
    print("\nKilling processes on AutoBotic ports...\n")
    
    # Kill old ports (5001, 8080) and new ports (5003, 3001)
    kill_port(5001)
    kill_port(5003)
    kill_port(8080)
    kill_port(3001)
    
    print("\nKilling orphaned Chrome/Selenium processes...")
    kill_orphan_chrome()
    
    # Final status check
    print("\n" + "=" * 50)
    print("Final port status:")
    all_usable = True
    for port in [5001, 5003, 8080, 3001]:
        free = is_port_free(port)
        usable = can_bind_port(port)
        if free and usable:
            print(f"  Port {port}: FREE")
        elif usable:
            print(f"  Port {port}: USABLE (has zombie sockets but can bind)")
        else:
            print(f"  Port {port}: BLOCKED (cannot bind)")
            all_usable = False
    
    print("=" * 50)
    if all_usable:
        print("\nAll ports ready! Run: python start.py")
    else:
        print("\nSome ports are blocked. Wait ~60s or restart PC.")

if __name__ == "__main__":
    main()
