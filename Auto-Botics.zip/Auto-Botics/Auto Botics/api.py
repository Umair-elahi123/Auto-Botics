"""
AutoBotic Flask API Backend

Main backend server providing REST API endpoints for the React frontend.
Handles automation control, chatbot management, account management, and data persistence.
"""

# =============================================================================
# IMPORTS
# =============================================================================

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import atexit
import signal
from datetime import datetime
from pathlib import Path
import io

# =============================================================================
# OPTIONAL DEPENDENCIES
# =============================================================================

# Tkinter for native folder browser dialog
try:
    import tkinter as tk
    from tkinter import filedialog
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False
    print("[WARN] tkinter not available — folder browse dialog disabled")

# Fix Windows console encoding for emoji/unicode support
if isinstance(sys.stdout, io.TextIOWrapper) and sys.stdout.writable():
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
if isinstance(sys.stderr, io.TextIOWrapper) and sys.stderr.writable():
    try:
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# =============================================================================
# FLASK APP INITIALIZATION
# =============================================================================

app = Flask(__name__, static_folder='auto-listings-pro-main/auto-listings-pro-main/dist')
CORS(app, resources={r"/api/*": {"origins": "*"}})

# =============================================================================
# GLOBAL CONFIGURATION
# =============================================================================

CONFIG = {
    "data_file": "products.json",
    "mattress_folder": "",
    "automation_script": r"D:\Project\automation_script.py",
    "batch_size": 2,
    "listings_to_do": 5,
    "num_titles": 5,
    "images_per_listing_min": 1,
    "images_per_listing_max": 1,
    "listing_range_start": 1,
    "listing_range_end": 1,
    "logs_folder": "logs",
    "insights_file": "insights_data.json",
    "chatbot_config": "chatbot_config.json"
}

# =============================================================================
# AUTOMATION STATE MANAGEMENT
# =============================================================================

automation_state = {
    "running": False,
    "progress": 0,
    "logs": [],
    "process": None,
    "start_time": None,
    "selected_account_emails": [],  # subset of products.json emails; empty = run all
}
automation_lock = threading.Lock()

# =============================================================================
# MODULE IMPORTS (CHATBOT & AUTOMATION)
# =============================================================================

try:
    import chatbot
    CHATBOT_AVAILABLE = True
except ImportError:
    CHATBOT_AVAILABLE = False
    print("[WARN] chatbot.py not found")

try:
    import automation_script
    AUTOMATION_MODULE_AVAILABLE = True
except ImportError:
    AUTOMATION_MODULE_AVAILABLE = False
    print("[WARN] automation_script.py not importable as module")

# =============================================================================
# PROCESS CLEANUP UTILITIES
# =============================================================================

def kill_process_tree(pid):
    """Kill a process and all its child processes."""
    if sys.platform == "win32":
        try:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10
            )
        except Exception as e:
            print(f"[WARN] Failed to kill process tree {pid}: {e}")
    else:
        try:
            os.killpg(os.getpgid(pid), signal.SIGTERM)
        except ProcessLookupError:
            pass


def cleanup_on_shutdown():
    """Clean up all running processes when API shuts down."""
    print("[CLEANUP] Shutting down API - cleaning up resources...")
    
    # Stop all active chatbots
    if CHATBOT_AVAILABLE:
        try:
            print("[CLEANUP] Stopping all chatbots...")
            chatbot.stop_all_chatbots()
            chatbot.force_quit_all_drivers()
        except Exception as e:
            print(f"[CLEANUP] Error stopping chatbots: {e}")
    
    # Terminate automation process if running
    global automation_state
    with automation_lock:
        if automation_state.get("process"):
            try:
                proc = automation_state["process"]
                if proc.poll() is None:
                    print("[CLEANUP] Stopping automation process...")
                    kill_process_tree(proc.pid)
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        proc.kill()
            except Exception as e:
                print(f"[CLEANUP] Error stopping automation: {e}")
            automation_state["process"] = None
            automation_state["running"] = False
    
    print("[CLEANUP] Cleanup complete")


# Register cleanup on exit
atexit.register(cleanup_on_shutdown)


def signal_handler(signum, frame):
    """Handle termination signals gracefully."""
    print(f"\n[SIGNAL] Received signal {signum}, initiating cleanup...")
    cleanup_on_shutdown()
    sys.exit(0)


if sys.platform != "win32":
    signal.signal(signal.SIGTERM, signal_handler)

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def hash_password(password):
    """Hash password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()


def load_data():
    """Load application data from JSON file."""
    try:
        if os.path.exists(CONFIG["data_file"]):
            with open(CONFIG["data_file"], "r", encoding="utf-8") as f:
                return json.load(f)
        return {"accounts": [], "mattress_tags": [], "users": [], "analytics": {}, "content": []}
    except Exception as e:
        print(f"Error loading data: {e}")
        return {"accounts": [], "mattress_tags": [], "users": [], "analytics": {}, "content": []}


def save_data(data):
    """Save application data to JSON file."""
    try:
        with open(CONFIG["data_file"], "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
        return True
    except Exception as e:
        print(f"Error saving data: {e}")
        return False


def save_log(log_message):
    """Append log message to daily log file."""
    Path(CONFIG["logs_folder"]).mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d")
    log_file = os.path.join(CONFIG["logs_folder"], f"automation_{timestamp}.log")
    try:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {log_message}\n")
    except Exception as e:
        print(f"Error saving log: {e}")

# =============================================================================
# CONFIG PERSISTENCE
# =============================================================================

AUTOMATION_CONFIG_FILE = "automation_config.json"


def load_automation_config():
    """Load automation configuration from file."""
    global CONFIG
    try:
        if os.path.exists(AUTOMATION_CONFIG_FILE):
            with open(AUTOMATION_CONFIG_FILE, "r", encoding="utf-8") as f:
                saved_config = json.load(f)
                if saved_config.get("mattress_folder"):
                    CONFIG["mattress_folder"] = saved_config["mattress_folder"]
                    print(f"[CONFIG] Loaded mattress folder: {CONFIG['mattress_folder']}")
                if "batch_size" in saved_config:
                    CONFIG["batch_size"] = saved_config["batch_size"]
                if "listings_to_do" in saved_config:
                    CONFIG["listings_to_do"] = saved_config["listings_to_do"]
    except Exception as e:
        print(f"[CONFIG] Could not load automation config: {e}")


def save_automation_config():
    """Persist automation configuration to file."""
    try:
        config_to_save = {
            "mattress_folder": CONFIG["mattress_folder"],
            "batch_size": CONFIG["batch_size"],
            "listings_to_do": CONFIG["listings_to_do"],
            "listing_range_start": CONFIG["listing_range_start"],
            "listing_range_end": CONFIG["listing_range_end"],
        }
        with open(AUTOMATION_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(config_to_save, f, indent=2)
        print(f"[CONFIG] Saved automation config")
    except Exception as e:
        print(f"[CONFIG] Could not save automation config: {e}")


# Load config at startup
load_automation_config()


def load_insights_data():
    """Load marketplace insights data."""
    try:
        if os.path.exists(CONFIG["insights_file"]):
            with open(CONFIG["insights_file"], "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def get_image_stats():
    """Get image count and filenames from mattress folder."""
    if not os.path.exists(CONFIG["mattress_folder"]):
        return 0, []
    images = [f for f in os.listdir(CONFIG["mattress_folder"])
              if f.lower().endswith((".jpg", ".jpeg", ".png", ".gif"))]
    return len(images), images


def load_chatbot_config():
    """Load chatbot configuration."""
    try:
        if os.path.exists(CONFIG["chatbot_config"]):
            with open(CONFIG["chatbot_config"], "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

# =============================================================================
# AUTH API ENDPOINTS
# =============================================================================

@app.route('/api/auth/login', methods=['POST'])
def login():
    body = request.json
    username = body.get('username', '').strip()
    password = body.get('password', '').strip()
    
    if not username or not password:
        return jsonify({"success": False, "error": "Please fill in all fields"}), 400
    
    data = load_data()
    hashed_pwd = hash_password(password)
    user = next((u for u in data.get("users", [])
                 if u.get("username") == username and u.get("password") == hashed_pwd), None)
    
    if user:
        save_log(f"User {username} logged in successfully")
        return jsonify({
            "success": True,
            "user": {
                "username": username,
                "email": user.get("email", f"{username}@autobotic.io")
            }
        })
    else:
        return jsonify({"success": False, "error": "Invalid username or password"}), 401

@app.route('/api/auth/signup', methods=['POST'])
def signup():
    body = request.json
    email = body.get('email', '').strip()
    username = body.get('username', '').strip()
    password = body.get('password', '').strip()
    name = body.get('name', '').strip()
    
    if not all([email, username, password]):
        return jsonify({"success": False, "error": "Please fill in all fields"}), 400
    
    if len(password) < 6:
        return jsonify({"success": False, "error": "Password must be at least 6 characters"}), 400
    
    data = load_data()
    users = data.get("users", [])
    
    if any(u.get("username") == username for u in users):
        return jsonify({"success": False, "error": "Username already exists"}), 400
    
    if any(u.get("email") == email for u in users):
        return jsonify({"success": False, "error": "Email already registered"}), 400
    
    users.append({
        "email": email,
        "username": username,
        "password": hash_password(password),
        "name": name,
        "created_at": datetime.now().isoformat()
    })
    data["users"] = users
    
    if save_data(data):
        save_log(f"New user registered: {username}")
        return jsonify({"success": True, "message": "Account created successfully"})
    else:
        return jsonify({"success": False, "error": "Failed to save user"}), 500

# ===================== DASHBOARD ENDPOINTS =====================

@app.route('/api/dashboard/overview', methods=['GET'])
def dashboard_overview():
    account_filter = request.args.get('account', 'all')
    
    insights_data = load_insights_data()
    data = load_data()
    all_accounts = data.get("accounts", [])
    all_emails = [a["email"] for a in all_accounts]
    
    if account_filter == 'all':
        active_emails = all_emails
    else:
        active_emails = [account_filter] if account_filter in all_emails else []
    
    filtered_insights = {e: insights_data.get(e, {}) for e in active_emails if e in insights_data}
    
    total_clicks = 0
    total_saves = 0
    total_followers = 0
    latest_ts = ""
    
    for ad in filtered_insights.values():
        m = ad.get("metrics", {})
        total_clicks += m.get("clicks_on_listings", 0)
        total_saves += m.get("listing_saves", 0)
        total_followers += m.get("marketplace_followers", 0)
        ts = ad.get("last_updated", "")
        if ts > latest_ts:
            latest_ts = ts
    
    comparison_data = []
    for email in active_emails:
        ad = filtered_insights.get(email)
        if not ad:
            continue
        clicks = ad.get("metrics", {}).get("clicks_on_listings", 0)
        comparison_data.append({
            "account": email.split("@")[0],
            "email": email,
            "clicks": clicks
        })
    
    return jsonify({
        "success": True,
        "overview": {
            "totalIds": len(active_emails),
            "totalClicks": total_clicks,
            "totalSaves": total_saves,
            "totalFollowers": total_followers
        },
        "lastUpdated": latest_ts,
        "clicksComparison": comparison_data,
        "accounts": [{"email": e, "name": e.split("@")[0]} for e in all_emails]
    })

# ===================== ACCOUNTS ENDPOINTS =====================

@app.route('/api/accounts', methods=['GET'])
def get_accounts():
    data = load_data()
    accounts = data.get("accounts", [])
    return jsonify({
        "success": True,
        "accounts": [{
            "id": i + 1,
            "email": acc["email"],
            "name": acc["email"].split("@")[0],
            "added_at": acc.get("added_at", "")
        } for i, acc in enumerate(accounts)]
    })

@app.route('/api/accounts', methods=['POST'])
def add_account():
    body = request.json
    email = body.get('email', '').strip()
    password = body.get('password', '').strip()
    
    if not email or not password:
        return jsonify({"success": False, "error": "Please fill in all fields"}), 400
    
    data = load_data()
    if "accounts" not in data:
        data["accounts"] = []
    
    if any(a["email"] == email for a in data["accounts"]):
        return jsonify({"success": False, "error": "Account already exists"}), 400
    
    data["accounts"].append({
        "email": email,
        "password": password,
        "added_at": datetime.now().isoformat()
    })
    
    if save_data(data):
        save_log(f"Account added: {email}")
        return jsonify({"success": True, "message": "Account added successfully"})
    else:
        return jsonify({"success": False, "error": "Failed to save account"}), 500

@app.route('/api/accounts/<email>', methods=['DELETE'])
def delete_account(email):
    data = load_data()
    original_count = len(data.get("accounts", []))
    data["accounts"] = [a for a in data.get("accounts", []) if a["email"] != email]
    
    if len(data["accounts"]) < original_count:
        if save_data(data):
            save_log(f"Account deleted: {email}")
            return jsonify({"success": True, "message": "Account deleted"})
        else:
            return jsonify({"success": False, "error": "Failed to save"}), 500
    else:
        return jsonify({"success": False, "error": "Account not found"}), 404

# ===================== TAGS ENDPOINTS =====================

@app.route('/api/tags', methods=['GET'])
def get_tags():
    data = load_data()
    return jsonify({
        "success": True,
        "tags": data.get("mattress_tags", [])
    })

@app.route('/api/tags', methods=['POST'])
def add_tag():
    body = request.json
    tag = body.get('tag', '').strip()
    
    if not tag:
        return jsonify({"success": False, "error": "Please enter a tag name"}), 400
    
    data = load_data()
    if "mattress_tags" not in data:
        data["mattress_tags"] = []
    
    if tag in data["mattress_tags"]:
        return jsonify({"success": False, "error": "Tag already exists"}), 400
    
    data["mattress_tags"].append(tag)
    
    if save_data(data):
        return jsonify({"success": True, "message": "Tag added"})
    else:
        return jsonify({"success": False, "error": "Failed to save"}), 500

@app.route('/api/tags/<tag>', methods=['DELETE'])
def delete_tag(tag):
    data = load_data()
    if tag in data.get("mattress_tags", []):
        data["mattress_tags"].remove(tag)
        if save_data(data):
            return jsonify({"success": True, "message": "Tag deleted"})
        else:
            return jsonify({"success": False, "error": "Failed to save"}), 500
    else:
        return jsonify({"success": False, "error": "Tag not found"}), 404

# ===================== PRICE ENDPOINT =====================

@app.route('/api/price', methods=['GET', 'PUT'])
def price_config():
    data = load_data()
    
    if request.method == 'GET':
        return jsonify({
            "success": True,
            "price": data.get("price", 0)
        })
    
    body = request.json
    price = body.get('price', 0)
    
    try:
        price = float(price)
        if price < 0:
            return jsonify({"success": False, "error": "Price cannot be negative"}), 400
    except (ValueError, TypeError):
        return jsonify({"success": False, "error": "Invalid price value"}), 400
    
    data["price"] = price
    
    if save_data(data):
        return jsonify({"success": True, "message": "Price updated", "price": price})
    else:
        return jsonify({"success": False, "error": "Failed to save"}), 500

# ===================== CONTENT ENDPOINTS =====================

@app.route('/api/content', methods=['GET'])
def get_content():
    data = load_data()
    return jsonify({
        "success": True,
        "description": data.get("description", ""),
        "titles": data.get("titles", [])
    })

@app.route('/api/content/description', methods=['PUT'])
def update_description():
    body = request.json
    description = body.get('description', '').strip()
    
    data = load_data()
    data["description"] = description
    
    if save_data(data):
        return jsonify({"success": True, "message": "Description saved"})
    else:
        return jsonify({"success": False, "error": "Failed to save"}), 500

@app.route('/api/content/titles', methods=['POST'])
def add_title():
    body = request.json
    title = body.get('title', '').strip()
    
    if not title:
        return jsonify({"success": False, "error": "Please enter a title"}), 400
    
    data = load_data()
    if "titles" not in data:
        data["titles"] = []
    
    data["titles"].append(title)
    
    if save_data(data):
        return jsonify({"success": True, "message": "Title added"})
    else:
        return jsonify({"success": False, "error": "Failed to save"}), 500

@app.route('/api/content/titles/<int:index>', methods=['DELETE'])
def delete_title(index):
    data = load_data()
    titles = data.get("titles", [])
    
    if 0 <= index < len(titles):
        titles.pop(index)
        data["titles"] = titles
        if save_data(data):
            return jsonify({"success": True, "message": "Title deleted"})
        else:
            return jsonify({"success": False, "error": "Failed to save"}), 500
    else:
        return jsonify({"success": False, "error": "Title not found"}), 404

# ===================== IMAGES ENDPOINTS =====================

@app.route('/api/images', methods=['GET'])
def get_images():
    folder_exists = os.path.exists(CONFIG["mattress_folder"])
    image_count, images = get_image_stats()
    
    return jsonify({
        "success": True,
        "folderPath": CONFIG["mattress_folder"],
        "folderExists": folder_exists,
        "imageCount": image_count,
        "images": images[:50]
    })

@app.route('/api/images/browse', methods=['POST'])
def browse_folder():
    """Open a native folder picker dialog and return the selected path"""
    if not TKINTER_AVAILABLE:
        return jsonify({"success": False, "error": "Folder browser not available on this system (tkinter missing)"}), 500

    try:
        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        
        folder_path = filedialog.askdirectory(
            title="Select Image Folder",
            initialdir=CONFIG["mattress_folder"] if os.path.exists(CONFIG["mattress_folder"]) else os.path.expanduser("~")
        )
        
        root.destroy()
        
        if folder_path:
            CONFIG["mattress_folder"] = folder_path
            save_automation_config()
            return jsonify({
                "success": True,
                "folderPath": folder_path,
                "folderExists": True
            })
        else:
            return jsonify({
                "success": False,
                "error": "No folder selected",
                "cancelled": True
            })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/images/config', methods=['GET', 'PUT'])
def images_config():
    if request.method == 'GET':
        return jsonify({
            "success": True,
            "folderPath": CONFIG["mattress_folder"],
            "imagesPerListingMin": CONFIG["images_per_listing_min"],
            "imagesPerListingMax": CONFIG["images_per_listing_max"],
            "listingRangeStart": CONFIG["listing_range_start"],
            "listingRangeEnd": CONFIG["listing_range_end"]
        })
    
    data = request.json
    updated = []

    new_min = CONFIG["images_per_listing_min"]
    new_max = CONFIG["images_per_listing_max"]

    if "imagesPerListingMin" in data:
        try:
            new_min = int(data["imagesPerListingMin"])
            if new_min < 1:
                return jsonify({"success": False, "error": "Min must be at least 1"}), 400
        except ValueError:
            return jsonify({"success": False, "error": "Invalid min value"}), 400

    if "imagesPerListingMax" in data:
        try:
            new_max = int(data["imagesPerListingMax"])
        except ValueError:
            return jsonify({"success": False, "error": "Invalid max value"}), 400

    if new_max < new_min:
        return jsonify({"success": False, "error": "Max must be >= min"}), 400

    if "imagesPerListingMin" in data:
        CONFIG["images_per_listing_min"] = new_min
        updated.append("imagesPerListingMin")
    if "imagesPerListingMax" in data:
        CONFIG["images_per_listing_max"] = new_max
        updated.append("imagesPerListingMax")

    if "folderPath" in data:
        new_path = data["folderPath"]
        if os.path.exists(new_path):
            CONFIG["mattress_folder"] = new_path
            updated.append("folderPath")
        else:
            return jsonify({"success": False, "error": f"Folder does not exist: {new_path}"}), 400
    
    if "listingRangeStart" in data:
        try:
            start_val = int(data["listingRangeStart"])
            if start_val >= 1:
                CONFIG["listing_range_start"] = start_val
                updated.append("listingRangeStart")
        except ValueError:
            pass
    
    if "listingRangeEnd" in data:
        try:
            end_val = int(data["listingRangeEnd"])
            if end_val >= CONFIG["listing_range_start"]:
                CONFIG["listing_range_end"] = end_val
                updated.append("listingRangeEnd")
        except ValueError:
            pass
    
    if updated:
        save_automation_config()
    
    return jsonify({
        "success": True,
        "message": f"Updated: {', '.join(updated)}",
        "folderPath": CONFIG["mattress_folder"],
        "imagesPerListingMin": CONFIG["images_per_listing_min"],
        "imagesPerListingMax": CONFIG["images_per_listing_max"],
        "listingRangeStart": CONFIG["listing_range_start"],
        "listingRangeEnd": CONFIG["listing_range_end"]
    })

@app.route('/api/images/arrange', methods=['POST'])
def arrange_images():
    """Rename images in folder to sequential numbers (1.jpg, 2.png, etc.)"""
    folder = CONFIG["mattress_folder"]
    
    if not os.path.exists(folder):
        return jsonify({"success": False, "error": "Folder does not exist"}), 400
    
    try:
        images = sorted([
            f for f in os.listdir(folder)
            if f.lower().endswith((".jpg", ".jpeg", ".png", ".gif", ".webp"))
        ])
        
        if not images:
            return jsonify({"success": False, "error": "No images found in folder"}), 400
        
        temp_names = []
        for i, img in enumerate(images):
            ext = os.path.splitext(img)[1]
            temp_name = f"_temp_{i}{ext}"
            old_path = os.path.join(folder, img)
            temp_path = os.path.join(folder, temp_name)
            os.rename(old_path, temp_path)
            temp_names.append((temp_path, ext))
        
        for i, (temp_path, ext) in enumerate(temp_names, start=1):
            final_name = f"{i}{ext}"
            final_path = os.path.join(folder, final_name)
            os.rename(temp_path, final_path)
        
        return jsonify({
            "success": True,
            "message": f"Renamed {len(images)} images to 1, 2, 3...",
            "count": len(images)
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

# ===================== AUTOMATION ENDPOINTS =====================

def run_automation_worker():
    global automation_state
    
    script_path = CONFIG["automation_script"]
    if not os.path.exists(script_path):
        with automation_lock:
            automation_state["running"] = False
            automation_state["logs"].append(f"[ERROR] Script not found: {script_path}")
        return
    
    try:
        listings_to_do = max(1, CONFIG["listing_range_end"] - CONFIG["listing_range_start"] + 1)
        headless_mode = automation_script.get_headless_mode() if AUTOMATION_MODULE_AVAILABLE else False

        with automation_lock:
            selected_accounts = list(automation_state.get("selected_account_emails") or [])
        account_filter = "|".join(selected_accounts) if selected_accounts else ""

        env = {
            **os.environ,
            'PYTHONIOENCODING': 'utf-8',
            'AUTOBOTIC_LISTINGS_TO_DO': str(listings_to_do),
            'AUTOBOTIC_NUM_TITLES': str(CONFIG["num_titles"]),
            'AUTOBOTIC_BATCH_SIZE': str(CONFIG["batch_size"]),
            'AUTOBOTIC_MATTRESS_FOLDER': CONFIG["mattress_folder"],
            'AUTOBOTIC_HEADLESS_MODE': str(headless_mode),
            'AUTOBOTIC_ACCOUNT_EMAILS': account_filter,
        }
        
        with automation_lock:
            automation_state["logs"].append(f"[CONFIG] Mattress folder: {CONFIG['mattress_folder']}")
            automation_state["logs"].append(f"[CONFIG] Listings to do: {listings_to_do} (range {CONFIG['listing_range_start']}-{CONFIG['listing_range_end']})")
            automation_state["logs"].append(f"[CONFIG] Batch size: {CONFIG['batch_size']}")
        
        print(f"[AUTOMATION] Starting with folder: {CONFIG['mattress_folder']}, listings_to_do: {listings_to_do}")
        
        # Use CREATE_NEW_PROCESS_GROUP on Windows for cleaner termination
        creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0
        
        process = subprocess.Popen(
            [sys.executable, "-u", script_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True,
            encoding='utf-8',
            errors='replace',
            env=env,
            creationflags=creation_flags
        )
        
        with automation_lock:
            automation_state["process"] = process
            automation_state["progress"] = 10
        
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                with automation_lock:
                    line = output.strip()
                    if "[ERROR]" in line or "Error" in line or "❌" in line:
                        automation_state["logs"].append(f"[ERROR] {line}")
                    else:
                        automation_state["logs"].append(f"[INFO] {line}")
                    save_log(f"Script output: {line}")
                    if automation_state["progress"] < 90:
                        automation_state["progress"] += 1
        
        return_code = process.wait()
        
        with automation_lock:
            automation_state["progress"] = 100
            if return_code == 0:
                automation_state["logs"].append("[INFO] Automation completed successfully!")
                save_log("Automation completed successfully")
            else:
                automation_state["logs"].append(f"[ERROR] Completed with exit code: {return_code}")
                save_log(f"Automation completed with errors: {return_code}")
            automation_state["running"] = False
            automation_state["selected_account_emails"] = []
            
    except Exception as e:
        with automation_lock:
            automation_state["logs"].append(f"[ERROR] {str(e)}")
            automation_state["running"] = False
            automation_state["selected_account_emails"] = []
            save_log(f"Automation error: {str(e)}")

@app.route('/api/automation/config', methods=['GET', 'PUT'])
def automation_config():
    if request.method == 'GET':
        data = load_data()
        total_accounts = len(data.get("accounts", []))
        total_images, _ = get_image_stats()
        listings_to_do = max(0, CONFIG["listing_range_end"] - CONFIG["listing_range_start"] + 1)
        
        return jsonify({
            "success": True,
            "config": {
                "accountsReady": total_accounts,
                "imagesAvailable": total_images,
                "batchSize": CONFIG["batch_size"],
                "listingsToDo": listings_to_do,
                "folderPath": CONFIG["mattress_folder"]
            }
        })
    
    data = request.json
    updated = []
    
    if "batchSize" in data:
        try:
            batch = int(data["batchSize"])
            if 1 <= batch <= 5:
                CONFIG["batch_size"] = batch
                updated.append(f"Batch size: {batch}")
        except ValueError:
            pass
    
    if updated:
        save_automation_config()
        return jsonify({
            "success": True,
            "message": "Updated: " + ", ".join(updated),
            "config": {
                "batchSize": CONFIG["batch_size"]
            }
        })
    
    return jsonify({"success": False, "error": "No valid fields to update"}), 400

@app.route('/api/automation/start', methods=['POST'])
def start_automation():
    global automation_state
    
    body = request.get_json(silent=True) or {}
    raw_ids = body.get("accountIds") or body.get("account_ids") or []
    if raw_ids is None:
        raw_ids = []
    selected_emails = []
    if raw_ids:
        if not CHATBOT_AVAILABLE:
            return jsonify({"success": False, "error": "Account resolution unavailable"}), 500
        data = load_data()
        products_accounts = data.get("accounts", [])
        for tid in raw_ids:
            acc = chatbot.resolve_account_from_login_id(tid, products_accounts)
            if not acc or not acc.get("email"):
                return jsonify({"success": False, "error": f"Unknown account: {tid}"}), 400
            selected_emails.append(acc["email"].strip())
    
    with automation_lock:
        if automation_state["running"]:
            return jsonify({"success": False, "error": "Automation already running"}), 400
        
        automation_state["running"] = True
        automation_state["progress"] = 5
        automation_state["logs"] = ["[INFO] Starting automation engine...", "[INFO] Loading accounts..."]
        automation_state["start_time"] = datetime.now().isoformat()
        automation_state["selected_account_emails"] = selected_emails
    
    save_log("Automation started by user")
    
    thread = threading.Thread(target=run_automation_worker, daemon=True)
    thread.start()
    
    return jsonify({"success": True, "message": "Automation started"})

@app.route('/api/automation/stop', methods=['POST'])
def stop_automation():
    global automation_state
    
    with automation_lock:
        if automation_state["process"]:
            try:
                proc = automation_state["process"]
                if proc.poll() is None:
                    # Use kill_process_tree to kill entire process tree (including Selenium)
                    kill_process_tree(proc.pid)
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                automation_state["logs"].append("[INFO] Automation stopped by user")
            except Exception as e:
                automation_state["logs"].append(f"[WARN] Stop error: {e}")
            automation_state["process"] = None
        automation_state["running"] = False
        automation_state["progress"] = 0
        automation_state["selected_account_emails"] = []
    
    save_log("Automation stopped by user")
    return jsonify({"success": True, "message": "Automation stopped"})

@app.route('/api/automation/status', methods=['GET'])
def automation_status():
    with automation_lock:
        return jsonify({
            "success": True,
            "running": automation_state["running"],
            "progress": automation_state["progress"],
            "logs": automation_state["logs"][-50:],
            "startTime": automation_state.get("start_time")
        })

@app.route('/api/automation/activity', methods=['GET', 'DELETE'])
def automation_activity():
    if not AUTOMATION_MODULE_AVAILABLE:
        return jsonify({"success": False, "error": "Automation module not available"}), 500
    
    if request.method == 'DELETE':
        automation_script.clear_activity_log()
        return jsonify({"success": True, "message": "Activity log cleared"})
    
    activity = automation_script.get_activity_log()
    return jsonify({"success": True, "activity": activity})

@app.route('/api/automation/headless', methods=['GET', 'PUT'])
def automation_headless():
    if not AUTOMATION_MODULE_AVAILABLE:
        return jsonify({"success": False, "error": "Automation module not available"}), 500
    
    if request.method == 'GET':
        return jsonify({
            "success": True,
            "headless": automation_script.get_headless_mode()
        })
    
    data = request.json
    enabled = data.get('enabled', False)
    result = automation_script.set_headless_mode(enabled)
    return jsonify({
        "success": True,
        "headless": result,
        "message": f"Headless mode {'enabled' if result else 'disabled'}"
    })

# =============================================================================
# CHATBOT API ENDPOINTS
# =============================================================================

@app.route('/api/chatbot/accounts', methods=['GET'])
def chatbot_accounts():
    if not CHATBOT_AVAILABLE:
        return jsonify({"success": False, "error": "Chatbot module not available"}), 500
    
    data = load_data()
    accounts = data.get("accounts", [])
    running_accounts = chatbot.get_running_accounts()
    
    conversations_dir = "conversations"
    unread_counts = {}
    if os.path.exists(conversations_dir):
        for filename in os.listdir(conversations_dir):
            if filename.endswith(".json"):
                parts = filename.replace(".json", "").rsplit("_", 1)
                if parts:
                    email = parts[0]
                    unread_counts[email] = unread_counts.get(email, 0) + 1
    
    result = [{
        "id": i + 1,
        "email": acc["email"],
        "name": acc["email"].split("@")[0],
        "status": "running" if acc["email"] in running_accounts else "idle",
        "unread": unread_counts.get(acc["email"], 0)
    } for i, acc in enumerate(accounts)]
    
    return jsonify({
        "success": True,
        "accounts": result,
        "runningCount": len(running_accounts)
    })

@app.route('/api/chatbot/start', methods=['POST'])
def start_chatbot():
    if not CHATBOT_AVAILABLE:
        return jsonify({"success": False, "error": "Chatbot module not available"}), 500
    
    try:
        body = request.json
        account_ids = body.get('accountIds', [])
        mode = body.get('mode', 'unread')
        
        if not account_ids:
            return jsonify({"success": False, "error": "No accounts selected"}), 400
        
        results = chatbot.start_chatbot_for_accounts(account_ids, mode=mode)
        
        started = [l for l, r in results.items() if r == "started"]
        skipped = [l for l, r in results.items() if r == "already_running"]
        not_found = [l for l, r in results.items() if r == "not_found"]
        
        return jsonify({
            "success": True,
            "started": started,
            "skipped": skipped,
            "notFound": not_found,
            "message": f"Started {len(started)} chatbot(s)"
        })
    except Exception as e:
        print(f"[ERROR] Chatbot start failed: {e}")
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/chatbot/stop', methods=['POST'])
def stop_chatbot():
    if not CHATBOT_AVAILABLE:
        return jsonify({"success": False, "error": "Chatbot module not available"}), 500
    
    body = request.json
    account_ids = body.get('accountIds', [])
    
    if account_ids:
        results = chatbot.stop_chatbot_for_accounts(account_ids)
    else:
        results = chatbot.stop_all_chatbots()
    
    stopped = [l for l, r in results.items() if r == "stopped"]
    
    return jsonify({
        "success": True,
        "stopped": stopped,
        "message": f"Stopped {len(stopped)} chatbot(s)"
    })

@app.route('/api/chatbot/conversations/<email>', methods=['GET'])
def get_conversations(email):
    if not CHATBOT_AVAILABLE:
        return jsonify({"success": False, "error": "Chatbot module not available"}), 500
    
    conversations = chatbot.get_account_conversations(email)
    return jsonify({"success": True, "conversations": conversations})

@app.route('/api/chatbot/headless', methods=['GET', 'PUT'])
def chatbot_headless():
    if not CHATBOT_AVAILABLE:
        return jsonify({"success": False, "error": "Chatbot module not available"}), 500
    
    if request.method == 'GET':
        return jsonify({"success": True, "headless": chatbot.get_headless_mode()})
    
    data = request.json
    enabled = data.get('enabled', False)
    result = chatbot.set_headless_mode(enabled)
    return jsonify({
        "success": True,
        "headless": result,
        "message": f"Headless mode {'enabled' if result else 'disabled'}"
    })

@app.route('/api/chatbot/activity', methods=['GET', 'DELETE'])
def chatbot_activity():
    if not CHATBOT_AVAILABLE:
        return jsonify({"success": False, "error": "Chatbot module not available"}), 500
    
    if request.method == 'DELETE':
        chatbot.clear_activity_log()
        return jsonify({"success": True, "message": "Activity log cleared"})
    
    activity = chatbot.get_activity_log()
    return jsonify({"success": True, "activity": activity})

# =============================================================================
# SETTINGS API ENDPOINTS
# =============================================================================

@app.route('/api/settings/user', methods=['GET'])
def get_user_settings():
    data = load_data()
    accounts_count = len(data.get("accounts", []))
    return jsonify({"success": True, "accountsCount": accounts_count, "plan": "Professional"})

@app.route('/api/settings/reset', methods=['POST'])
def reset_data():
    data = load_data()
    # Clear all data except users (app login)
    data["accounts"] = []
    data["content"] = []
    data["analytics"] = {}
    data["titles"] = []
    data["description"] = ""
    data["price"] = 0
    
    if save_data(data):
        if os.path.exists(CONFIG["insights_file"]):
            os.remove(CONFIG["insights_file"])
        
        # Clear automation_activity.json
        automation_activity_file = "automation_activity.json"
        if os.path.exists(automation_activity_file):
            try:
                with open(automation_activity_file, "w", encoding="utf-8") as f:
                    json.dump([], f)
            except Exception:
                pass
        
        # Clear conversations folder
        conversations_dir = "conversations"
        if os.path.exists(conversations_dir):
            for filename in os.listdir(conversations_dir):
                try:
                    os.remove(os.path.join(conversations_dir, filename))
                except Exception:
                    pass
        
        # Clear logs folder
        if os.path.exists(CONFIG["logs_folder"]):
            for lf in os.listdir(CONFIG["logs_folder"]):
                try:
                    os.remove(os.path.join(CONFIG["logs_folder"], lf))
                except Exception:
                    pass
        
        # Clear chatbot activity log
        try:
            from chatbot import clear_activity_log
            clear_activity_log()
        except Exception:
            pass
        
        # Clear browser profiles (logout all Facebook accounts)
        profiles_dir = r"C:\fb_profiles"
        if os.path.exists(profiles_dir):
            try:
                shutil.rmtree(profiles_dir)
            except Exception:
                pass
        
        save_log("System reset by user")
        return jsonify({"success": True, "message": "All data has been reset"})
    else:
        return jsonify({"success": False, "error": "Failed to reset data"}), 500

@app.route('/api/settings/clear-logs', methods=['POST'])
def clear_logs():
    if os.path.exists(CONFIG["logs_folder"]):
        for lf in os.listdir(CONFIG["logs_folder"]):
            try:
                os.remove(os.path.join(CONFIG["logs_folder"], lf))
            except Exception:
                pass
        return jsonify({"success": True, "message": "All logs cleared"})
    else:
        return jsonify({"success": True, "message": "No logs to clear"})

# =============================================================================
# SERVE REACT APP (SPA FALLBACK)
# =============================================================================

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    """Serve React SPA with fallback to index.html for client-side routing."""
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, 'index.html')

# =============================================================================
# MAIN ENTRY POINT
# =============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("AutoBotic API Server")
    print("=" * 60)
    print(f"Data file: {CONFIG['data_file']}")
    print(f"Insights: {CONFIG['insights_file']}")
    print(f"Chatbot: {'Available' if CHATBOT_AVAILABLE else 'Not Available'}")
    print(f"Automation: {'Available' if AUTOMATION_MODULE_AVAILABLE else 'Not Available'}")
    print(f"Tkinter: {'Available' if TKINTER_AVAILABLE else 'Not Available'}")
    print("=" * 60)
    
    app.run(host='0.0.0.0', port=5003, debug=False, threaded=True)