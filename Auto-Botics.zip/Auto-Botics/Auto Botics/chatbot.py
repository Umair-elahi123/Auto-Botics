"""
Facebook Marketplace Chatbot

Automated chatbot for responding to customer messages using the llm module (Groq).
Features:
- Multi-account support with concurrent browsers
- Conversation history tracking
- AI-powered responses with product catalog context
"""

# =============================================================================
# IMPORTS
# =============================================================================

from seleniumbase import Driver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import (
    StaleElementReferenceException,
    NoSuchElementException,
)
import time
import json
import os
import re
import random
import threading
import sys
from datetime import datetime
import io
import logging
from urllib.parse import urlparse
from typing import Any, Dict, List, Optional

from window_utils import ensure_chrome_maximized
from llm import get_ai_reply

# =============================================================================
# LOGGING SETUP
# =============================================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)


# =============================================================================
# CONSOLE ENCODING FIX (Windows Unicode Support)
# =============================================================================

if isinstance(sys.stdout, io.TextIOWrapper) and sys.stdout.writable():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
if isinstance(sys.stderr, io.TextIOWrapper) and sys.stderr.writable():
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# =============================================================================
# GLOBAL CONFIGURATION
# =============================================================================


class Config:
    """Global chatbot settings."""

    # Browser settings
    PROFILES_DIR: str = r"C:\fb_profiles"
    HEADLESS: bool = False

    # Timing settings
    PAGE_LOAD_TIMEOUT: int = 15
    ELEMENT_TIMEOUT: int = 10
    CHECK_INTERVAL: int = 10

    # URLs
    SELLING_URL: str = "https://www.facebook.com/marketplace/you/selling"
    INBOX_URL: str = "https://www.facebook.com/marketplace/you/inbox"
    MARKETPLACE_HOME: str = "https://www.facebook.com/marketplace"
    FACEBOOK_URL: str = "https://www.facebook.com"

    # Activity log
    MAX_ACTIVITY_LOG: int = 100


# =============================================================================
# THREAD-SAFE LOCKS
# =============================================================================

_active_threads = {}
_active_drivers = {}
_stop_events = {}
_lock = threading.Lock()
_browser_launch_lock = threading.Lock()
_activity_log = []
_activity_log_lock = threading.Lock()

# =============================================================================
# ACTIVITY LOGGING
# =============================================================================


def log_activity(account_email, customer_id, customer_message, ai_response):
    """Log chatbot activity for API access."""
    with _activity_log_lock:
        _activity_log.append(
            {
                "timestamp": datetime.now().isoformat(),
                "account": account_email,
                "customer_id": customer_id,
                "customer_message": customer_message,
                "ai_response": ai_response,
            }
        )
        while len(_activity_log) > Config.MAX_ACTIVITY_LOG:
            _activity_log.pop(0)


def get_activity_log():
    """Get activity log."""
    with _activity_log_lock:
        return list(_activity_log)


def clear_activity_log():
    """Clear activity log."""
    with _activity_log_lock:
        _activity_log.clear()


def set_headless_mode(enabled: bool):
    """Set browser headless mode."""
    Config.HEADLESS = enabled
    return Config.HEADLESS


def get_headless_mode():
    """Get current headless mode setting."""
    return Config.HEADLESS


# =============================================================================
# TEXT MATCHING UTILITIES
# =============================================================================


def _normalize_text(text):
    """Normalize text for comparison."""
    if not text:
        return ""
    text = text.lower()
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def clean_message(raw_text: str) -> str:
    """
    Strip Messenger accessibility prefixes that leak into .text (e.g. aria-label copy).
    Applied to scraped bubbles and history before LLM / matching.
    """
    if not raw_text:
        return ""
    cleaned = re.sub(
        r"^Enter,\s*Message sent \d+:\d+ [AP]M by [^:]+:\s*",
        "",
        raw_text,
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(
        r"^Message sent \d+:\d+\s*[AP]M by [^:]+:\s*",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )
    return cleaned.strip()


# =============================================================================
# ITEM-PAGE POPUP CHAT
# =============================================================================

_POPUP_CONTAINER_XPATHS = [
    "//div[.//div[@role='button'][normalize-space()='See details']]"
    "[.//div[@role='button'][normalize-space()='More options']]"
    "[.//div[@contenteditable='true']]",
    "//div[.//span[contains(.,'·')]]"
    "[.//span[normalize-space()='Marketplace']]"
    "[.//div[@contenteditable='true']]",
    "//div[.//span[normalize-space()='Marketplace']]"
    "[.//div[@contenteditable='true']]"
    "[.//span[@dir='auto']]",
]


def _find_item_page_chat_popups(driver):
    """
    Return ALL visible Marketplace item-page chat popups on the page.
    Facebook can stack 2-3 popups side-by-side; each is processed independently
    so multi-buyer pages don't block on the first popup.
    """
    raw_candidates = []
    for xp in _POPUP_CONTAINER_XPATHS:
        try:
            elements = driver.find_elements(By.XPATH, xp)
        except Exception:
            continue
        for el in elements:
            try:
                if el.is_displayed():
                    raw_candidates.append(el)
            except (StaleElementReferenceException, NoSuchElementException):
                continue
            except Exception:
                continue

    if not raw_candidates:
        logger.info("📭 No item-page chat popup found")
        return []

    by_box: Dict[str, Any] = {}
    for el in raw_candidates:
        try:
            boxes = el.find_elements(By.XPATH, ".//div[@contenteditable='true']")
        except Exception:
            continue

        visible_box = None
        for b in boxes:
            try:
                if b.is_displayed():
                    visible_box = b
                    break
            except Exception:
                continue
        if visible_box is None:
            continue

        try:
            key = visible_box.id
        except Exception:
            continue

        existing = by_box.get(key)
        if existing is None:
            by_box[key] = el
            continue

        try:
            new_area = el.size["width"] * el.size["height"]
            old_area = existing.size["width"] * existing.size["height"]
            if 0 < new_area < old_area:
                by_box[key] = el
        except Exception:
            continue

    popups = list(by_box.values())
    if popups:
        logger.info("✅ Found %d item-page chat popup(s)", len(popups))
    else:
        logger.info("📭 No item-page chat popup found")
    return popups


def _find_item_page_chat_popup(driver):
    """Return the first visible Marketplace item-page chat popup, or None."""
    popups = _find_item_page_chat_popups(driver)
    return popups[0] if popups else None


def _get_buyer_name_from_popup(popup):
    """Parse buyer first name from title text before middle dot, or 'Customer'."""
    skip = {"marketplace", "facebook", "messenger"}
    try:
        for span in popup.find_elements(By.XPATH, ".//span[contains(.,'·')]"):
            try:
                raw = (span.text or "").strip()
                if "·" not in raw:
                    continue
                left = raw.split("·", 1)[0].strip()
                if not left:
                    continue
                if left.lower() in skip:
                    continue
                return left
            except (StaleElementReferenceException, NoSuchElementException):
                continue
    except Exception:
        pass
    return "Customer"


_BUYER_NAME_SKIP = {"marketplace", "facebook", "messenger", "chats", "you"}

_BUYER_NAME_PAGE_XPATHS = [
    "//*[starts-with(@id, 'mount_')]/div/div[1]/div/div[5]/div[1]/div[1]/div[1]"
    "/div/div/div/div/div/div/div/div[1]/div",
    "//*[@id='mount_0_0_jZ']/div/div[1]/div/div[5]/div[1]/div[1]/div[1]"
    "/div/div/div/div/div/div/div/div[1]/div",
]


def _clean_buyer_name(raw: str) -> str:
    """Trim a scraped header string down to a plausible buyer name."""
    if not raw:
        return ""
    name = raw.strip().split("\n", 1)[0].strip()
    name = name.split("·", 1)[0].strip()
    name = re.sub(r"\s+", " ", name)
    if not name or name.lower() in _BUYER_NAME_SKIP:
        return ""
    if len(name) > 80:
        return ""
    return name


def _get_buyer_name_from_page(driver) -> Optional[str]:
    """Read buyer name from the chat header using the user-supplied XPath."""
    for xp in _BUYER_NAME_PAGE_XPATHS:
        try:
            elements = driver.find_elements(By.XPATH, xp)
        except Exception:
            continue
        for el in elements:
            try:
                if not el.is_displayed():
                    continue
                name = _clean_buyer_name(el.text or "")
                if name:
                    return name
            except (StaleElementReferenceException, NoSuchElementException):
                continue
            except Exception:
                continue
    return None


def _resolve_buyer_identity(driver, popup, total_popups: int = 1):
    """
    Return (buyer_name, buyer_id). Includes the buyer name in buyer_id so each
    customer on the same listing gets a dedicated conversation file.

    The page-level XPath always resolves to the FIRST popup on screen, so we
    only trust it when exactly one popup is visible. With multiple popups we
    extract the name from inside that specific popup element.
    """
    buyer_name = ""
    if total_popups <= 1:
        buyer_name = _get_buyer_name_from_page(driver) or ""
    if not buyer_name:
        buyer_name = _get_buyer_name_from_popup(popup) or "Customer"

    url = ""
    try:
        url = driver.current_url or ""
    except Exception:
        pass
    m = re.search(r"/item/(\d+)", url)
    item_id = m.group(1) if m else None

    safe_name = re.sub(r"[^a-zA-Z0-9]+", "_", buyer_name).strip("_") or "Customer"

    if item_id and safe_name and safe_name.lower() != "customer":
        buyer_id = f"item_{item_id}_{safe_name}"
    elif item_id and safe_name and safe_name.lower() == "customer":
        buyer_id = f"item_{item_id}"
    else:
        buyer_id = f"buyer_{safe_name}"

    return buyer_name, buyer_id


def _normalize_fb_span_text(s: str) -> str:
    """Facebook uses narrow no-break space (U+202F) around times; normalize for regexes."""
    if not s:
        return ""
    s = s.replace("\u202f", " ").replace("\u00a0", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _get_popup_messages(popup, log_messages: bool = False) -> List[Dict[str, Any]]:
    """
    Ordered list of {"text", "is_outgoing"} for visible chat lines in the popup.
    Direction from accessibility copy ("... by You:" vs "... by Name:"). Skips duplicate
    accessibility rows. By default does not log every line (only callers that opt in).
    """
    results: List[Dict[str, Any]] = []
    seen_texts = set()

    NOISE = {
        "marketplace",
        "see details",
        "more options",
        "mark as pending",
        "sent",
        "delivered",
        "seen",
        "just now",
        "active now",
        "learn more",
        "you can now rate each other",
        "beware of common scams using payment apps",
        "block",
        "report",
        "you blocked this person",
        "this conversation is encrypted",
        "messages and calls are secured with end-to-end encryption",
    }

    NOISE_PREFIXES = (
        "beware of common scams",
        "watch out for fake emails",
        "you can now rate each other",
        "people may rate one another",
        "rate ",
        "active ",
        "sent ",
    )

    NOISE_PATTERNS = (
        re.compile(r"^sent\s+\d+\s*[smhd]\s*ago$", re.IGNORECASE),
        re.compile(
            r"^sent\s+\d+\s+(second|minute|hour|day|week)s?\s+ago$", re.IGNORECASE
        ),
        re.compile(r"^sent\s+(just\s+now|yesterday|today)\b.*$", re.IGNORECASE),
        re.compile(r"^sent\s+\d{1,2}:\d{2}\s*[ap]m$", re.IGNORECASE),
        re.compile(r"^delivered\b", re.IGNORECASE),
        re.compile(r"^seen\b", re.IGNORECASE),
        re.compile(r"^active\s+\d+\s*[smhd]\s*ago$", re.IGNORECASE),
        re.compile(
            r"^active\s+\d+\s+(second|minute|hour|day|week)s?\s+ago$", re.IGNORECASE
        ),
    )

    def is_noise(t: str) -> bool:
        if not t or len(t.strip()) < 2:
            return True
        low = t.strip().lower()
        if low in NOISE:
            return True
        if re.match(r"^\$[\d,]+", t.strip()):
            return True
        if re.match(r"^within \d+", low):
            return True
        if re.match(r"^\d{1,2}:\d{2}\s*(am|pm)$", low):
            return True
        if re.match(r"^\d+k?\s*miles", low):
            return True
        for p in NOISE_PREFIXES:
            if low.startswith(p):
                return True
        for pat in NOISE_PATTERNS:
            if pat.match(low):
                return True
        return False

    text_direction: Dict[str, bool] = {}

    try:
        all_spans = popup.find_elements(By.XPATH, ".//span[@dir='auto']")
        for span in all_spans:
            try:
                raw = (span.text or "").strip()
                if not raw:
                    continue
                norm = _normalize_fb_span_text(raw)
                m = re.match(
                    r"^(?:Enter,\s*)?Message\s+sent\s+\d{1,2}:\d{2}\s*[AP]M\s+by\s+([^:]+):\s*(.+)$",
                    norm,
                    re.IGNORECASE | re.DOTALL,
                )
                if m:
                    sender = m.group(1).strip()
                    text = m.group(2).strip()
                    is_out = sender.lower() == "you"
                    text_direction[text] = is_out
                    if len(text) > 30:
                        text_direction[text[:30]] = is_out
            except Exception:
                continue
    except Exception:
        pass

    try:
        all_spans = popup.find_elements(By.XPATH, ".//span[@dir='auto']")
        for span in all_spans:
            try:
                raw = (span.text or "").strip()
                if not raw:
                    continue
                norm = _normalize_fb_span_text(raw)
                if re.match(r"^(?:Enter,\s*)?Message\s+sent\s+\d", norm, re.IGNORECASE):
                    continue
                if is_noise(norm):
                    continue
                if norm in seen_texts:
                    continue
                seen_texts.add(norm)

                is_out = text_direction.get(norm)
                if is_out is None:
                    for k, v in text_direction.items():
                        if norm in k or k in norm:
                            is_out = v
                            break
                if is_out is None:
                    is_out = False

                results.append({"text": norm, "is_outgoing": is_out})
                if log_messages:
                    direction = "OUT" if is_out else "IN"
                    logger.info("  [%s] %s", direction, norm[:60])
            except Exception:
                continue
    except Exception:
        pass

    return results


def _recent_assistant_messages(history: list, limit: int = 4) -> List[str]:
    """Most recent assistant texts first (for matching mis-tagged outgoing bubbles)."""
    out: List[str] = []
    for h in reversed(history or []):
        if h.get("sender") == "assistant":
            t = (h.get("message") or "").strip()
            if t:
                out.append(t)
            if len(out) >= limit:
                break
    return out


def _bubble_is_likely_our_reply(bubble_text: str, assistant_text: str) -> bool:
    """
    True if visible bubble text is the same as (or a truncated head of) a reply we saved.
    Stops re-replies when Facebook marks our bubble as incoming in the DOM.
    """
    if not bubble_text or not assistant_text:
        return False
    b = _normalize_text(bubble_text)
    a = _normalize_text(assistant_text)
    if not b or not a:
        return False
    if b == a:
        return True
    min_chars = 12
    if len(b) >= min_chars and a.startswith(b):
        return True
    if len(a) >= min_chars and b.startswith(a):
        return True
    return False


def _get_last_unanswered_customer_message(popup, account_email, buyer_id):
    """
    Only the last bubble in the thread matters: if it is ours, do not reply.
    If it is the customer's, reply only when it differs from the last saved buyer line
    and does not match a recent assistant reply (misclassified outgoing).
    """
    messages = _get_popup_messages(popup, log_messages=False)
    if not messages:
        return None

    last = messages[-1]
    if last["is_outgoing"]:
        logger.info("⏭️ Last message is ours — waiting for customer")
        return None

    newest_customer_msg = last["text"]

    history = load_conversation_history(account_email, buyer_id)

    last_saved_customer_msg = None
    for h in reversed(history):
        if h.get("sender") == "buyer":
            last_saved_customer_msg = (h.get("message") or "").strip()
            break

    if last_saved_customer_msg:
        if newest_customer_msg.strip().lower() == last_saved_customer_msg.strip().lower():
            logger.info(
                "⏭️ Same as last saved buyer message ('%s') — skipping",
                newest_customer_msg[:40],
            )
            return None

    for asst in _recent_assistant_messages(history, limit=4):
        if _bubble_is_likely_our_reply(newest_customer_msg, asst):
            logger.info(
                "⏭️ Last bubble matches our sent reply (not customer) — skipping: %s...",
                newest_customer_msg[:50],
            )
            return None

    logger.info("✅ New customer message: %s", newest_customer_msg[:60])
    return newest_customer_msg


def _send_message_to_popup(driver, popup, text) -> bool:
    """Focus compose box in popup, type text in chunks, press Enter."""
    selectors = (
        ".//div[@contenteditable='true'][@role='textbox']",
        ".//div[@contenteditable='true']",
        ".//textarea",
    )
    message_box = None
    for sel in selectors:
        try:
            for el in popup.find_elements(By.XPATH, sel):
                try:
                    if el.is_displayed():
                        message_box = el
                        break
                except Exception:
                    continue
            if message_box is not None:
                break
        except Exception:
            continue

    if message_box is None:
        logger.info("❌ Could not find compose box")
        return False

    try:
        driver.execute_script("arguments[0].scrollIntoView({block:'nearest'});", message_box)
        driver.execute_script("arguments[0].focus();", message_box)
        message_box.click()
        time.sleep(random.uniform(0.05, 0.15))
        try:
            message_box.clear()
        except Exception:
            driver.execute_script(
                "arguments[0].innerText='';arguments[0].textContent='';",
                message_box,
            )

        safe = _chromedriver_typable_text(
            re.sub(r"\s+", " ", text.replace("\n", " ").replace("\r", " ")).strip()
        )
        chunk_size = 10
        for i in range(0, len(safe), chunk_size):
            chunk = safe[i : i + chunk_size]
            message_box.send_keys(chunk)
            time.sleep(random.uniform(0.05, 0.1))
        message_box.send_keys(Keys.RETURN)
        time.sleep(2)
        logger.info("✅ Sent!")
        return True
    except Exception as e:
        logger.warning("⚠️ Send failed: %s", e)
        logger.info("❌ Could not find compose box")
        return False


def _process_single_popup(
    driver, popup, account_email, total_popups: int, stop_event
) -> bool:
    """
    Run the full reply flow for ONE popup. Isolated so a stale/broken popup
    cannot abort the loop over other popups in the same browser. Returns True
    if a reply was sent for this popup (used only for logging cadence).
    """
    if stop_event and stop_event.is_set():
        return False

    try:
        buyer_name, buyer_id = _resolve_buyer_identity(driver, popup, total_popups)
    except StaleElementReferenceException:
        logger.info("⚠️ Popup went stale before identity resolve — skipping")
        return False
    except Exception as e:
        logger.warning("⚠️ Could not resolve buyer for popup: %s", str(e)[:80])
        return False

    logger.info("👤 Buyer: %s (id=%s)", buyer_name, buyer_id)

    history_file = f"conversations/{account_email}_{buyer_id}.json"
    if not os.path.exists(history_file):
        logger.info(
            "🆕 New buyer detected — starting fresh conversation file for %s", buyer_name
        )

    try:
        customer_msg = _get_last_unanswered_customer_message(
            popup, account_email, buyer_id
        )
    except StaleElementReferenceException:
        logger.info("⚠️ Popup went stale while reading messages — skipping")
        return False
    except Exception as e:
        logger.warning("⚠️ Could not read messages for %s: %s", buyer_name, str(e)[:80])
        return False

    if not customer_msg:
        logger.info("📭 No new messages from %s", buyer_name)
        return False

    logger.info("📩 %s says: %s", buyer_name, customer_msg[:60])

    save_conversation(account_email, buyer_id, buyer_name, customer_msg, "buyer")

    history = load_conversation_history(account_email, buyer_id)
    ai_response = get_ai_reply(history)
    if not ai_response:
        logger.info("⏸️ AI unavailable for %s", buyer_name)
        return False

    logger.info("🤖 AI Response (%s): %s", buyer_name, ai_response)

    try:
        sent = _send_message_to_popup(driver, popup, ai_response)
    except StaleElementReferenceException:
        logger.info("⚠️ Popup went stale while sending — skipping")
        return False
    except Exception as e:
        logger.warning("⚠️ Send error for %s: %s", buyer_name, str(e)[:80])
        return False

    if sent:
        save_conversation(
            account_email, buyer_id, buyer_name, ai_response, "assistant"
        )
        log_activity(account_email, buyer_id, customer_msg, ai_response)
        return True
    return False


def check_and_reply_item_page(driver, account_email, config, stop_event):
    """
    Detect every item-page chat popup currently visible in this browser and run
    the buyer-resolve / read / reply flow for each one independently. Multiple
    browsers (accounts) running this in their own threads remain unaffected.
    """
    if stop_event and stop_event.is_set():
        return

    popups = _find_item_page_chat_popups(driver)
    if not popups:
        logger.info("📭 No chat popup on this page")
        return

    total = len(popups)
    if total > 1:
        logger.info("🔁 Processing %d popups for %s", total, account_email)

    for idx, popup in enumerate(popups, start=1):
        if stop_event and stop_event.is_set():
            logger.info("⛔ Stop requested mid-popup-loop")
            return

        if total > 1:
            logger.info("— Popup %d/%d —", idx, total)

        sent = _process_single_popup(driver, popup, account_email, total, stop_event)

        if sent and idx < total:
            time.sleep(random.uniform(0.8, 1.6))


# =============================================================================
# CONFIGURATION & DATA LOADING
# =============================================================================


def load_config():
    """Load chatbot configuration."""
    config_file = "chatbot_config.json"
    if not os.path.exists(config_file):
        raise FileNotFoundError(f"{config_file} is missing.")
    with open(config_file, "r", encoding="utf-8") as f:
        return json.load(f)


def load_accounts():
    """Load accounts from products.json."""
    with open("products.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    return data["accounts"]


def resolve_account_from_login_id(login_token, accounts):
    """
    Resolve UI checkbox value to an account dict.
    Accepts 1-based index (same as /api/chatbot/accounts id), numeric string, or email.
    Case-insensitive email match; strips whitespace.
    """
    if login_token is None or isinstance(login_token, bool):
        return None
    token = str(login_token).strip()
    if not token:
        return None
    if token.isdigit():
        idx = int(token)
        if 1 <= idx <= len(accounts):
            return accounts[idx - 1]
        return None
    for a in accounts:
        em = (a.get("email") or "").strip()
        if em == token or em.lower() == token.lower():
            return a
    return None


def load_conversation_history(account_email, buyer_id):
    """Load conversation history for a buyer."""
    history_file = f"conversations/{account_email}_{buyer_id}.json"
    if os.path.exists(history_file):
        with open(history_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def save_conversation(account_email, buyer_id, buyer_name, message, sender="buyer"):
    """Save conversation message."""
    os.makedirs("conversations", exist_ok=True)
    history_file = f"conversations/{account_email}_{buyer_id}.json"
    conversation = load_conversation_history(account_email, buyer_id)
    conversation.append(
        {
            "timestamp": datetime.now().isoformat(),
            "sender": sender,
            "buyer_name": buyer_name,
            "message": message,
        }
    )
    with open(history_file, "w", encoding="utf-8") as f:
        json.dump(conversation, f, indent=2)
    return conversation


# =============================================================================
# AI RESPONSE GENERATION (shared with llm.py)
# =============================================================================


def _detect_stated_mattress_size(buyer_message: str, conversation_history) -> Optional[str]:
    """
    If the buyer already named a size (here or in recent turns), return canonical label.
    Order matters: California King before King.
    """
    chunks = []
    if buyer_message:
        chunks.append(clean_message(buyer_message))
    if conversation_history:
        for msg in conversation_history[-12:]:
            if msg.get("sender") == "buyer":
                chunks.append(clean_message(msg.get("message") or ""))
    blob = " ".join(chunks).lower()
    if re.search(r"\bcal(ifornia)?\s+king\b", blob):
        return "California King"
    if re.search(r"\bking\b", blob):
        return "King"
    if re.search(r"\bqueen\b", blob):
        return "Queen"
    if re.search(r"\bfull\b|\bdouble\b", blob):
        return "Full"
    if re.search(r"\btwin\b|\bsingle\b", blob):
        return "Twin"
    return None


def _fallback_reply_when_size_known(stated: str, config: dict, buyer_message_lower: str) -> str:
    """Short reply when we must not ask 'what size' again."""
    bs = config.get("box_springs") or {}
    price = bs.get(stated)
    wants_box = "box" in buyer_message_lower or "spring" in buyer_message_lower
    parts = [f"Got it - {stated}."]
    if stated == "California King" and price is None:
        parts.append(
            "For Cal King, tell me mattress only or bed+box and I'll match what we have."
        )
    elif price is not None and wants_box:
        parts.append(f"{stated} box spring is ${price}.")
    elif price is not None:
        parts.append(f"We have {stated} box springs for ${price} if you need one.")
    parts.append("Are you looking for a bed frame, mattress, or both?")
    return _clamp_reply_text(" ".join(parts))


def _repair_redundant_size_question(
    reply: str, buyer_message: str, conversation_history, config: dict
) -> str:
    """If the model still asks for size after the buyer gave it, replace with a grounded follow-up."""
    stated = _detect_stated_mattress_size(buyer_message, conversation_history)
    if not stated or not reply:
        return reply
    low = reply.lower()
    if not re.search(r"\bwhat size\b|\bwhich size\b|\bsize do you need\b", low):
        return reply
    logger.info("🔧 Replacing redundant size question (buyer already said %s)", stated)
    return _fallback_reply_when_size_known(stated, config, (buyer_message or "").lower())


def _last_clean_buyer_from_history(conversation_history) -> str:
    for m in reversed(conversation_history or []):
        if m.get("sender") == "buyer":
            t = clean_message(m.get("message") or "")
            if t:
                return t
    return ""


def _clamp_reply_text(text: str, max_words: int = 48, max_sentences: int = 3) -> str:
    """Force one short Messenger bubble: a few sentences, bounded word count."""
    if not text:
        return text
    text = re.sub(r"\s+", " ", text).strip()
    chunks = re.split(r"(?<=[.!?])\s+", text)
    chunks = [c.strip() for c in chunks if c.strip()][:max_sentences]
    text = " ".join(chunks)
    words = text.split()
    if len(words) > max_words:
        text = " ".join(words[:max_words]).rstrip(",;:")
        if text and text[-1] not in ".!?":
            text += "."
    return text


def _chromedriver_typable_text(text: str) -> str:
    """
    Selenium ChromeDriver send_keys only supports the BMP (code points <= U+FFFF).
    Astral characters (most emoji, many symbols) raise 'only supports characters in the BMP'.
    """
    if not text:
        return text
    filtered = "".join(c for c in text if ord(c) <= 0xFFFF)
    return re.sub(r"\s+", " ", filtered).strip()


# =============================================================================
# HELPER UTILITIES
# =============================================================================


class Helpers:
    """Utility functions for chatbot automation."""

    @staticmethod
    def human_wait(min_sec: float = 0.5, max_sec: float = 1.5) -> None:
        """Random delay to simulate human behavior."""
        time.sleep(random.uniform(min_sec, max_sec))

    @staticmethod
    def interruptible_sleep(seconds: float, stop_event: threading.Event = None) -> bool:
        """Sleep that can be interrupted by stop_event. Supports fractional seconds (not only ints)."""
        total = float(seconds)
        if total <= 0:
            return bool(stop_event and stop_event.is_set())
        end = time.monotonic() + total
        while time.monotonic() < end:
            if stop_event and stop_event.is_set():
                return True
            remaining = end - time.monotonic()
            time.sleep(min(0.25, remaining) if remaining > 0 else 0.0)
        return False

    @staticmethod
    def safe_navigate(driver, url: str, stop_event: threading.Event = None) -> bool:
        """Navigate to URL with timeout handling and stop_event check."""
        expected_host = (urlparse(url).netloc or "").lower()
        for attempt in range(3):
            if stop_event and stop_event.is_set():
                logger.info("⛔ Stop requested during navigation")
                return False

            try:
                try:
                    driver.set_page_load_timeout(Config.PAGE_LOAD_TIMEOUT)
                except Exception:
                    pass

                try:
                    driver.get(url)
                except Exception as nav_ex:
                    logger.warning(
                        "   Page load timeout, stopping... (%s)", str(nav_ex)[:30]
                    )
                    try:
                        driver.execute_script("window.stop();")
                    except Exception:
                        pass

                time.sleep(1)
                try:
                    current_url = (driver.current_url or "").lower()
                except Exception:
                    current_url = ""

                if expected_host and expected_host in current_url:
                    logger.info("✅ Navigation successful")
                    return True

                logger.info("   Trying JS redirect (attempt %s)...", attempt + 1)
                try:
                    driver.execute_script(f"window.location.replace('{url}');")
                except Exception as js_ex:
                    logger.warning("   JS redirect failed: %s", str(js_ex)[:30])

                time.sleep(2)

                try:
                    current_url = (driver.current_url or "").lower()
                except Exception:
                    current_url = ""
                if expected_host and expected_host in current_url:
                    return True

            except Exception as e:
                logger.warning("⚠️ Navigation attempt %s failed: %s", attempt + 1, str(e)[:50])

            time.sleep(1)

        logger.error("❌ Navigation failed after retries: %s", url)
        return False


# =============================================================================
# BROWSER MANAGER
# =============================================================================


class BrowserManager:
    """Manages Chrome browser instances with persistent profiles."""

    @staticmethod
    def get_profile_path(email: str) -> str:
        """Get profile directory path for email."""
        safe_name = re.sub(r"[^a-zA-Z0-9_.-]", "_", email)
        path = os.path.join(Config.PROFILES_DIR, safe_name)
        os.makedirs(path, exist_ok=True)
        return path

    @staticmethod
    def create_driver(email: str):
        """Create Chrome driver with persistent profile."""
        logger.info("🌐 Opening Chrome for %s...", email)
        profile_path = BrowserManager.get_profile_path(email)
        logger.info("   Profile: %s", profile_path)

        driver = None
        try:
            with _browser_launch_lock:
                driver = Driver(
                    uc=True,
                    headless=Config.HEADLESS,
                    user_data_dir=profile_path,
                    chromium_arg="start-maximized",
                    page_load_strategy="eager",
                )
        except Exception as e:
            logger.error("❌ Failed to create browser for %s: %s", email, e)
            raise

        try:
            driver.set_page_load_timeout(15)
            driver.set_script_timeout(15)
            driver.implicitly_wait(3)
        except Exception as e:
            logger.warning("⚠️ Timeout setup warning: %s", e)

        try:
            driver.set_page_load_timeout(25)
            driver.get(Config.MARKETPLACE_HOME)
        except Exception as e:
            logger.warning(
                "⚠️ Initial Marketplace load: %s — stopping load and continuing", e
            )
            try:
                driver.execute_script("window.stop();")
            except Exception:
                pass
        finally:
            try:
                driver.set_page_load_timeout(30)
            except Exception:
                pass
        if not Config.HEADLESS:
            ensure_chrome_maximized(driver, headless=False)
        logger.info("✅ Browser ready for %s (Marketplace open)", email)

        return driver

    @staticmethod
    def quit_driver(driver) -> None:
        """Close browser safely."""
        if driver is None:
            return
        try:
            driver.quit()
            logger.info("Browser closed")
        except Exception as e:
            logger.warning("Error closing browser: %s", e)

    @staticmethod
    def is_driver_responsive(driver) -> bool:
        """Check if driver is still responsive."""
        try:
            _ = driver.current_url
            return True
        except Exception:
            return False


# =============================================================================
# MONITORING & PUBLIC API
# =============================================================================


def monitor_account(account, config, check_interval=None, mode="unread", stop_event=None):
    email = account["email"]
    password = account["password"]
    wait_s = check_interval if check_interval is not None else Config.CHECK_INTERVAL

    logger.info("\n🚀 Starting chatbot for: %s\n", email)

    driver = None
    try:
        if stop_event and stop_event.is_set():
            logger.info("⛔ Stop requested before starting %s", email)
            return

        try:
            driver = BrowserManager.create_driver(email)
        except Exception as browser_err:
            logger.error("❌ Failed to create browser for %s: %s", email, browser_err)
            return

        if driver is None:
            logger.error("❌ Browser creation returned None for %s", email)
            return

        with _lock:
            _active_drivers[email] = driver

        if stop_event and stop_event.is_set():
            logger.info("⛔ Stop requested after browser creation for %s", email)
            return

        target_url = Config.MARKETPLACE_HOME
        try:
            cur = (driver.current_url or "").lower()
        except Exception:
            cur = ""
        if "facebook.com" in cur and "marketplace" in cur:
            logger.info("📍 Already on Marketplace — skipping second navigation")
            navigated = True
        else:
            logger.info("📍 Navigating to %s", target_url)
            navigated = Helpers.safe_navigate(driver, target_url, stop_event)

        try:
            driver.set_page_load_timeout(30)
        except Exception:
            pass

        if navigated:
            logger.info("✅ Ready - starting message monitoring\n")
        else:
            logger.warning("⚠️ Navigation incomplete but continuing anyway...\n")

        if not Config.HEADLESS:
            ensure_chrome_maximized(driver, headless=False)

        check_count = 0
        consecutive_errors = 0
        max_consecutive_errors = 3

        while not (stop_event and stop_event.is_set()):
            check_count += 1
            logger.info(
                "🔍 Check #%s — %s", check_count, datetime.now().strftime("%H:%M:%S")
            )

            if not BrowserManager.is_driver_responsive(driver):
                logger.error("❌ Browser unresponsive for %s, stopping...", email)
                break

            try:
                check_and_reply_item_page(driver, email, config, stop_event)
                consecutive_errors = 0
            except Exception as check_err:
                consecutive_errors += 1
                logger.warning(
                    "⚠️ Check error (%s/%s): %s",
                    consecutive_errors,
                    max_consecutive_errors,
                    str(check_err)[:100],
                )
                if consecutive_errors >= max_consecutive_errors:
                    logger.error("❌ Too many consecutive errors for %s, stopping...", email)
                    break

            if stop_event and stop_event.is_set():
                break

            logger.info("⏳ Waiting %ss before next check...\n", wait_s)
            if Helpers.interruptible_sleep(wait_s, stop_event):
                break

    except KeyboardInterrupt:
        logger.info("\n⛔ Stopping")
    except Exception as e:
        logger.error("❌ Error: %s", e)
    finally:
        if driver:
            BrowserManager.quit_driver(driver)
        with _lock:
            _active_drivers.pop(email, None)


def start_chatbot_for_accounts(
    login_ids: list, mode: str = "unread", check_interval: Optional[int] = None
) -> dict:
    try:
        config = load_config()
        accounts = load_accounts()
    except Exception:
        return {str(lid): "error" for lid in login_ids}

    results = {}

    for lid in login_ids:
        req_key = str(lid)
        account = resolve_account_from_login_id(lid, accounts)
        if not account:
            results[req_key] = "not_found"
            logger.warning(
                "⚠️ No account for login id %r — check id index or email in products.json",
                lid,
            )
            continue

        email_key = (account.get("email") or "").strip()
        if not email_key:
            results[req_key] = "not_found"
            continue

        with _lock:
            if email_key in _active_threads and _active_threads[email_key].is_alive():
                results[req_key] = "already_running"
                continue

        stop_event = threading.Event()
        interval = check_interval if check_interval is not None else Config.CHECK_INTERVAL

        t = threading.Thread(
            target=monitor_account,
            args=(account, config),
            kwargs={"check_interval": interval, "mode": mode, "stop_event": stop_event},
            daemon=True,
        )

        with _lock:
            _stop_events[email_key] = stop_event
            _active_threads[email_key] = t

        t.start()
        results[req_key] = "started"
        logger.info("✅ Thread started for %s (%s)", email_key, req_key)

        if len(login_ids) > 1:
            logger.info("⏳ Waiting 5s before next browser launch...")
            time.sleep(5)

    return results


def _canonical_email_for_chatbot_stop(login_token, accounts) -> Optional[str]:
    """Resolve stop target to the same email key used in _active_threads."""
    acc = resolve_account_from_login_id(login_token, accounts)
    if acc and acc.get("email"):
        return acc["email"].strip()
    cand = str(login_token).strip()
    with _lock:
        if cand in _active_threads:
            return cand
        for k in _active_threads:
            if k.lower() == cand.lower():
                return k
    return cand


def stop_chatbot_for_accounts(login_ids: list) -> dict:
    try:
        accounts = load_accounts()
    except Exception:
        accounts = []

    results = {}
    for lid in login_ids:
        req_key = str(lid)
        email_key = _canonical_email_for_chatbot_stop(lid, accounts)

        with _lock:
            stop_event = _stop_events.get(email_key)
            thread = _active_threads.get(email_key)

        if not stop_event and not thread:
            results[req_key] = "not_running"
            continue

        if stop_event:
            stop_event.set()

        if thread and thread.is_alive():
            thread.join(timeout=15)
            results[req_key] = "stopped"
        else:
            results[req_key] = "not_running"

        with _lock:
            _stop_events.pop(email_key, None)
            _active_threads.pop(email_key, None)
            _active_drivers.pop(email_key, None)

    return results


def stop_all_chatbots() -> dict:
    with _lock:
        all_ids = list(_active_threads.keys())
    return stop_chatbot_for_accounts(all_ids)


def stop_all_chatbots_for_ids(login_ids):
    return stop_chatbot_for_accounts(login_ids)


def force_quit_all_drivers():
    with _lock:
        for email, drv in list(_active_drivers.items()):
            try:
                drv.quit()
            except Exception:
                pass
        _active_drivers.clear()


def get_running_accounts() -> list:
    with _lock:
        return [lid for lid, t in _active_threads.items() if t.is_alive()]


def get_account_conversations(account_email: str) -> list:
    conversations_dir = "conversations"
    if not os.path.exists(conversations_dir):
        return []
    all_messages = []
    for filename in os.listdir(conversations_dir):
        if filename.startswith(account_email):
            filepath = os.path.join(conversations_dir, filename)
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    history = json.load(f)
                for msg in history:
                    all_messages.append(
                        {
                            "role": "user" if msg.get("sender") == "buyer" else "assistant",
                            "content": msg.get("message", ""),
                            "buyer_name": msg.get("buyer_name", ""),
                            "timestamp": msg.get("timestamp", ""),
                        }
                    )
            except Exception:
                continue
    all_messages.sort(key=lambda x: x.get("timestamp", ""))
    return all_messages


def get_all_accounts_with_messages() -> list:
    conversations_dir = "conversations"
    if not os.path.exists(conversations_dir):
        return []
    emails = set()
    for filename in os.listdir(conversations_dir):
        if filename.endswith(".json"):
            parts = filename.replace(".json", "").rsplit("_", 1)
            if parts:
                emails.add(parts[0])
    return sorted(emails)


def add_message(account_email: str, role: str, content: str, buyer_name: str = "") -> None:
    buyer_id = buyer_name.replace(" ", "_") if buyer_name else "manual_reply"
    sender = "buyer" if role == "user" else "assistant"
    save_conversation(account_email, buyer_id, buyer_name or "Manual", content, sender)


def clear_account_conversations(account_email: str) -> None:
    conversations_dir = "conversations"
    if not os.path.exists(conversations_dir):
        return
    for filename in os.listdir(conversations_dir):
        if filename.startswith(account_email):
            try:
                os.remove(os.path.join(conversations_dir, filename))
            except Exception:
                pass


def main():
    print("🤖 Facebook Marketplace Chatbot - FINAL FIX\n")

    os.makedirs(Config.PROFILES_DIR, exist_ok=True)

    config = load_config()
    accounts = load_accounts()

    if not accounts:
        print("❌ No accounts")
        return

    print("📋 Accounts:")
    for idx, acc in enumerate(accounts, 1):
        print(f"  {idx}. {acc['email']}")

    choice = input("\nSelect: ").strip()
    try:
        choice_num = int(choice)
    except ValueError:
        print("❌ Invalid")
        return

    if 1 <= choice_num <= len(accounts):
        account = accounts[choice_num - 1]
        stop_event = threading.Event()
        try:
            monitor_account(account, config, stop_event=stop_event)
        except KeyboardInterrupt:
            stop_event.set()


if __name__ == "__main__":
    main()
