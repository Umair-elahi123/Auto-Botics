"""
Pytest bootstrap: stub Selenium / SeleniumBase at import time so test collection can load chatbot
without a browser.
"""

import sys
import types
from unittest.mock import MagicMock


def _ensure_module(name: str):
    if name not in sys.modules:
        sys.modules[name] = types.ModuleType(name)


_ensure_module("selenium")
_ensure_module("selenium.webdriver")
_ensure_module("selenium.webdriver.common")
_ensure_module("selenium.webdriver.support")
_ensure_module("selenium.webdriver.support.ui")
_ensure_module("selenium.common")

by_mod = types.ModuleType("selenium.webdriver.common.by")


class By:
    XPATH = "xpath"
    CSS_SELECTOR = "css_selector"
    ID = "id"


by_mod.By = By
sys.modules["selenium.webdriver.common.by"] = by_mod

keys_mod = types.ModuleType("selenium.webdriver.common.keys")
keys_mod.Keys = MagicMock()
sys.modules["selenium.webdriver.common.keys"] = keys_mod

exc_mod = types.ModuleType("selenium.common.exceptions")
for exc_name in (
    "TimeoutException",
    "StaleElementReferenceException",
    "NoSuchElementException",
    "WebDriverException",
):
    setattr(exc_mod, exc_name, type(exc_name, (Exception,), {}))
sys.modules["selenium.common.exceptions"] = exc_mod

sup_ui = types.ModuleType("selenium.webdriver.support.ui")
sup_ui.WebDriverWait = MagicMock()
sys.modules["selenium.webdriver.support.ui"] = sup_ui

ec_mod = types.ModuleType("selenium.webdriver.support.expected_conditions")
ec_mod.element_to_be_clickable = MagicMock()
ec_mod.presence_of_element_located = MagicMock()
sys.modules["selenium.webdriver.support.expected_conditions"] = ec_mod

sb = types.ModuleType("seleniumbase")
sb.Driver = MagicMock()
sys.modules["seleniumbase"] = sb

wu = types.ModuleType("window_utils")
wu.ensure_chrome_maximized = MagicMock()
sys.modules["window_utils"] = wu
