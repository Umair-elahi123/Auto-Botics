"""
Single entry point for AI completions (Groq only).
Loads catalog-backed system instructions from chatbot_config.json on first use.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    from groq import Groq

    GROQ_AVAILABLE = True
except ImportError:
    GROQ_AVAILABLE = False

_CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatbot_config.json")
_RAW_CONFIG: Dict[str, Any] = {}
_config_loaded: bool = False
_groq_cooldown_until_mono: float = 0.0

_CATALOG_KEYS = ("business_info", "beds", "mattresses", "box_springs", "complete_packages")

# Model sometimes narrates "I should wait" instead of writing the actual seller text — reject those.
_META_NARRATION_RE = re.compile(
    r"\b("
    r"it seems(\s+like)?|"
    r"i should have|"
    r"this is not(\s+a)?\s+valid(\s+response)?|"
    r"i'?ll wait for|"
    r"wait for .+('?s)?\s+response|"
    r"since .+didn'?t respond|"
    r"didn'?t respond,\s*i|"
    r"end(ed)? the conversation|"
    r"instead of sending|"
    r"i was wrong to|"
    r"my mistake,?\s+i|"
    r"as an ai|"
    r"the assistant should"
    r")\b",
    re.IGNORECASE,
)


def _reply_is_meta_narration(text: str) -> bool:
    if not text or not text.strip():
        return False
    return bool(_META_NARRATION_RE.search(text))


def _ensure_config_loaded() -> None:
    global _RAW_CONFIG, _config_loaded
    if _config_loaded:
        return
    _config_loaded = True
    try:
        with open(_CONFIG_PATH, encoding="utf-8") as f:
            _RAW_CONFIG = json.load(f)
        logger.info("📋 llm: loaded config from %s", _CONFIG_PATH)
    except OSError as e:
        _RAW_CONFIG = {}
        logger.error("❌ llm: could not load %s: %s", _CONFIG_PATH, e)


def _catalog_json() -> str:
    blob = {k: _RAW_CONFIG.get(k, {}) for k in _CATALOG_KEYS}
    return json.dumps(blob, separators=(",", ":"))


def _groq_cooldown_seconds_from_error(exc: BaseException) -> float:
    """Parse Groq 'try again in XmYs' or default."""
    msg = str(exc)
    m = re.search(r"try again in (\d+)m([\d.]+)s", msg, re.I)
    if m:
        sec = float(m.group(1)) * 60.0 + float(m.group(2))
        return min(max(sec, 60.0), 86400.0)
    m2 = re.search(r"retry after[:\s]+(\d+)", msg, re.I)
    if m2:
        return min(max(float(m2.group(1)), 60.0), 86400.0)
    return 15 * 60.0


def _is_groq_rate_limit(exc: BaseException) -> bool:
    msg = str(exc).lower()
    if "429" in msg:
        return True
    if "rate_limit" in msg or "rate limit" in msg:
        return True
    code = getattr(exc, "status_code", None)
    if code == 429:
        return True
    return False


def _chatbot_helpers():
    """Late import to avoid circular import while chatbot loads llm."""
    import chatbot as cb

    return cb


def _build_system_prompt(conversation_history: Optional[List[Dict[str, Any]]]) -> str:
    cb = _chatbot_helpers()
    history = conversation_history or []
    effective_buyer = cb._last_clean_buyer_from_history(history)
    stated = cb._detect_stated_mattress_size(effective_buyer, history)
    size_rule = ""
    if stated:
        size_rule = (
            f"\nCRITICAL: The buyer already asked for {stated} (see conversation messages). "
            f"Do NOT ask what size they need. Acknowledge {stated} briefly. "
            "If they mentioned box or box spring, quote box_springs price for that size from CATALOG. "
            "Ask at most one different question (bed frame vs mattress, model, or delivery)—not size."
        )
    base = _RAW_CONFIG.get("system_prompt") or ""
    catalog = _catalog_json()
    return f"""{base}

Hard limits: ONE reply only. Max 3 short sentences. Max 45 words. No newlines. Catalog numbers must match JSON exactly.
Never repeat or argue about a dollar amount unless that exact price appears in CATALOG above or the customer wrote it as part of a real sentence. Ignore stray price-only snippets.

ROLE — first person as the store only: Your entire output is the single Messenger text the customer will see from Austin Beds & Mattresses. Write as "we/I" from the business. Do NOT narrate, analyze, or comment on the thread (no "it seems", "I should have waited", "I'll wait for [name]", "since they didn't respond", "this is not a valid response", "end the conversation"). Do NOT talk about yourself as a bot or assistant. If the customer's last message is a greeting or short ("hi", "here?"), reply briefly as the store and offer help with beds or mattresses — never discuss whether they replied or what you intended to do.

CATALOG: {catalog}{size_rule}"""


def _conversation_to_groq_turns(conversation_history: List[Dict[str, Any]], max_messages: int = 60):
    cb = _chatbot_helpers()
    out = []
    for entry in (conversation_history or [])[-max_messages:]:
        sender = entry.get("sender")
        if sender == "buyer":
            role = "user"
        elif sender == "assistant":
            role = "assistant"
        else:
            continue
        content = cb.clean_message(entry.get("message") or "")
        if not content:
            continue
        out.append({"role": role, "content": content})
    return out


def _normalize_reply_text(text: str) -> str:
    if not text:
        return ""
    text = text.replace("\n", " ").replace("\r", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _call_groq(system_prompt: str, conversation_history: List[Dict[str, Any]], api_key: str) -> str:
    global _groq_cooldown_until_mono

    now = time.monotonic()
    if now < _groq_cooldown_until_mono:
        left = int(_groq_cooldown_until_mono - now)
        logger.info("⏸️ Groq skipped — rate-limit cooldown (%s s remaining)", left)
        return ""

    thread_turns = _conversation_to_groq_turns(conversation_history)
    if not thread_turns:
        logger.warning("⚠️ Groq: no valid turns in conversation_history after cleaning — skipping")
        return ""

    cb = _chatbot_helpers()
    effective_buyer = cb._last_clean_buyer_from_history(conversation_history)
    logger.info("🤖 Provider: Groq (model=llama-3.1-8b-instant), %s message(s)", len(thread_turns))
    logger.info("📤 Groq thread (last user): %s...", (effective_buyer or "")[:50])

    client = Groq(api_key=api_key)
    groq_messages = [{"role": "system", "content": system_prompt}] + thread_turns

    try:
        response = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=groq_messages,
            max_tokens=100,
            temperature=0.15,
        )
        result = (response.choices[0].message.content or "").strip()
        result = _normalize_reply_text(result)
        result = cb._clamp_reply_text(result)
        result = cb._repair_redundant_size_question(result, effective_buyer, conversation_history, _RAW_CONFIG)
        if result and _reply_is_meta_narration(result):
            logger.warning(
                "⚠️ Groq reply rejected — meta-narration / out-of-character (not sent): %s...",
                result[:80],
            )
            return ""
        logger.info("📥 Groq returned: %s...", result[:50] if result else "(empty)")
        if result:
            logger.info("✅ Groq response OK (%s chars)", len(result))
        return result
    except Exception as e:
        if _is_groq_rate_limit(e):
            sec = _groq_cooldown_seconds_from_error(e)
            _groq_cooldown_until_mono = time.monotonic() + sec
            until_wall = datetime.now(timezone.utc).timestamp() + sec
            logger.error(
                "❌ Groq rate limit (429): %s — cooldown %s s (until ~%s UTC)",
                e,
                int(sec),
                datetime.fromtimestamp(until_wall, tz=timezone.utc).strftime("%H:%M:%S"),
            )
        else:
            logger.error("❌ Groq error: %s", e, exc_info=True)
        return ""


def get_ai_reply(conversation_history: list) -> str:
    """
    Call Groq only. Returns stripped reply text or "" on failure or cooldown skip.
    Caller must not send a message when this returns empty.
    """
    _ensure_config_loaded()
    if not _RAW_CONFIG:
        logger.error("❌ get_ai_reply: config not loaded")
        return ""

    system_prompt = _build_system_prompt(conversation_history)
    groq_key = _RAW_CONFIG.get("groq_api_key") or ""

    logger.info(
        "🔑 Groq key: %s",
        "✅ Present" if groq_key and str(groq_key).startswith("gsk_") else "❌ Missing/Invalid",
    )

    if groq_key and str(groq_key).startswith("gsk_") and GROQ_AVAILABLE:
        out = _call_groq(system_prompt, conversation_history, groq_key)
        if out:
            return out
        logger.warning("⚠️ Groq returned empty after attempt")
    elif groq_key and not GROQ_AVAILABLE:
        logger.warning("⚠️ Groq API key present but groq package is not installed")
    else:
        logger.info("⏭️ Groq skipped — no valid API key")

    logger.error("❌ Groq unavailable — returning empty string")
    return ""
