"""
Facebook Marketplace Auto Listing Bot

Automated posting of marketplace listings with support for:
- Multiple account management with persistent sessions
- Image upload and form field automation
- React-compatible input handling
- Concurrent browser execution
"""

# =============================================================================
# IMPORTS
# =============================================================================

from concurrent.futures import ThreadPoolExecutor, as_completed
from seleniumbase import Driver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException,
    StaleElementReferenceException,
    NoSuchElementException,
    ElementClickInterceptedException,
    WebDriverException
)
from datetime import datetime
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum
import threading
import time
import json
from json import JSONDecodeError
import os
import re
import random
import traceback
import logging

from window_utils import ensure_chrome_maximized

# =============================================================================
# LOGGING SETUP
# =============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

# =============================================================================
# DATA CLASSES & ENUMS
# =============================================================================

class ListingCondition(Enum):
    """Listing condition options."""
    NEW = "New"
    LIKE_NEW = "Like New"
    USED_GOOD = "Used - Good"
    USED_FAIR = "Used - Fair"


@dataclass
class Account:
    """Facebook account for automation."""
    email: str
    password: str
    listings_to_post: int = 5
    completed_listings: int = 0
    failed_listings: int = 0
    is_logged_in: bool = False


@dataclass
class ListingData:
    """Data for a single marketplace listing."""
    title: str
    price: str
    description: str
    category: str = "Furniture"
    condition: ListingCondition = ListingCondition.NEW
    image_path: str = ""
    tags: List[str] = field(default_factory=list)


@dataclass
class AutomationResult:
    """Result of automation for an account."""
    email: str
    success: bool
    listings_published: int = 0
    listings_failed: int = 0
    insights: Dict[str, int] = field(default_factory=dict)
    error_message: str = ""

# =============================================================================
# GLOBAL CONFIGURATION
# =============================================================================

class Config:
    """Global automation settings."""
    
    # Browser settings
    CONCURRENT_BROWSERS: int = 2
    PROFILES_DIR: str = r"C:\fb_profiles"
    HEADLESS: bool = False
    
    # Timing settings
    MIN_WAIT: float = 1.0
    MAX_WAIT: float = 2.0
    PAGE_LOAD_TIMEOUT: int = 30
    ELEMENT_TIMEOUT: int = 15
    TWO_FA_TIMEOUT: int = 120
    AFTER_FIELD_WAIT: float = 1.5
    
    # Retry settings
    MAX_RETRIES: int = 3
    RETRY_DELAY: float = 2.0
    MAX_CONSECUTIVE_FAILURES: int = 3
    
    # File paths
    PRODUCTS_FILE: str = "products.json"
    INSIGHTS_FILE: str = "insights_data.json"
    ACTIVITY_LOG_FILE: str = "automation_activity.json"
    MAX_ACTIVITY_LOG: int = 100
    
    # URLs
    FACEBOOK_URL: str = "https://www.facebook.com"
    MARKETPLACE_URL: str = "https://www.facebook.com/marketplace"
    CREATE_LISTING_URL: str = "https://www.facebook.com/marketplace/create/item/"
    SELLING_URL: str = "https://www.facebook.com/marketplace/you/selling"
    INSIGHTS_URL: str = "https://www.facebook.com/marketplace/you/insights"

# =============================================================================
# THREAD-SAFE LOCKS
# =============================================================================

_browser_launch_lock = threading.Lock()
_activity_log_lock = threading.Lock()
_insights_lock = threading.Lock()

# =============================================================================
# XPATH STRATEGIES - STABLE SELECTORS
# =============================================================================

class XPathStrategies:
    """Stable XPath strategies using aria-label, role, data-testid, and text."""
    
    # Login selectors
    EMAIL_FIELD = [
        '//input[@name="email"]',
        '//input[@id="email"]',
        '//input[@type="email"]',
        '//input[@autocomplete="email"]',
        '//input[contains(@aria-label, "email") or contains(@aria-label, "Email")]',
        '//input[contains(@placeholder, "Email") or contains(@placeholder, "email")]',
        '//input[contains(@placeholder, "Phone")]',
        '//input[contains(@aria-label, "Email address or mobile number")]',
        '//input[contains(@aria-label, "email address or mobile")]',
        '//input[contains(@placeholder, "Email address or mobile number")]',
        '//input[contains(@placeholder, "mobile number")]',
        '//form//input[@type="text"][1]',
        '//div[contains(text(),"Log in")]//following::input[1]',
    ]
    
    PASSWORD_FIELD = [
        '//input[@name="pass"]',
        '//input[@id="pass"]',
        '//input[@type="password"]',
        '//input[@autocomplete="current-password"]',
        '//input[contains(@aria-label, "Password")]',
        '//input[contains(@placeholder, "Password")]',
        '//form//input[@type="password"]',
    ]
    
    LOGIN_BUTTON = [
        '//button[@name="login"]',
        '//button[@type="submit"]',
        '//button[@data-testid="royal_login_button"]',
        '//button[@id="loginbutton"]',
        '//button[normalize-space()="Log in" or normalize-space()="Log In"]',
        '//div[@role="button"][contains(., "Log")]',
        '//button[@aria-label="Log in" or @aria-label="Log In"]',
        '//div[@aria-label="Log in"]',
        '//span[normalize-space()="Log in" or normalize-space()="Log In"]/ancestor::div[@role="button"]',
        '//form//button[1]',
    ]
    
    # Title field selectors
    TITLE_FIELD = [
        '//input[@aria-label="Title"]',
        '//input[@aria-label="title"]',
        '//label[.//span[normalize-space(text())="Title"]]//input',
        '//label[normalize-space(text())="Title"]//input',
        '//label[normalize-space(text())="Title"]/following-sibling::input',
        '//span[normalize-space(text())="Title"]/following::input[1]',
        '//span[normalize-space(text())="Title"]/ancestor::div[2]//input',
        '//input[@placeholder="Title"]',
        '//input[contains(@placeholder, "title") or contains(@placeholder, "Title")]',
        '//input[@name="title"]',
        '//input[@name="Title"]',
        '//input[contains(@aria-label, "Title") or contains(@aria-label, "title")]',
        '//*[normalize-space(text())="Title"]/following::input[@type="text"][1]',
        '//*[normalize-space(text())="Title"]/following::input[not(@type="hidden")][1]',
    ]

    # Price field selectors
    PRICE_FIELD = [
        '//input[@aria-label="Price"]',
        '//input[@aria-label="price"]',
        '//label[.//span[normalize-space(text())="Price"]]//input',
        '//label[normalize-space(text())="Price"]//input',
        '//label[normalize-space(text())="Price"]/following-sibling::input',
        '//span[normalize-space(text())="Price"]/following::input[1]',
        '//span[normalize-space(text())="Price"]/ancestor::div[2]//input',
        '//input[@placeholder="$"]',
        '//input[contains(@placeholder, "$")]',
        '//input[contains(@placeholder, "price") or contains(@placeholder, "Price")]',
        '//input[@name="price"]',
        '//input[@name="Price"]',
        '//input[@type="number"][@aria-label]',
        '//input[@type="number"]',
        '//input[contains(@aria-label, "Price") or contains(@aria-label, "price")]',
        '//*[normalize-space(text())="Price"]/following::input[@type="text"][1]',
        '//*[normalize-space(text())="Price"]/following::input[not(@type="hidden")][1]',
    ]

    # Other form field selectors
    CATEGORY_TRIGGER = [
        '//label[.//span[normalize-space()="Category"]]',
        '//label[.//span[text()="Category"]]',
        '//span[normalize-space()="Category"]/ancestor::label',
        '//span[text()="Category"]/ancestor::label',
        '//div[contains(@aria-label, "Category")]',
        '//div[@role="button"][.//span[normalize-space()="Category"]]',
        '//div[@role="button"][.//span[text()="Category"]]',
        '//div[@role="combobox"][contains(@aria-label, "Category")]',
        '//div[@role="combobox"][.//*[normalize-space()="Category"]]',
        '//*[normalize-space(text())="Category"]/ancestor::div[@role="button"][1]',
        '//*[normalize-space(text())="Category"]/ancestor::*[@role="combobox"][1]',
        '//span[normalize-space()="Category"]/ancestor::*[@role="button" or @role="combobox"][1]',
    ]
    
    CONDITION_TRIGGER = [
        '//label[.//span[text()="Condition"]]',
        '//span[text()="Condition"]/ancestor::label',
        '//div[contains(@aria-label, "Condition")]',
        '//div[@role="combobox"][contains(@aria-label, "Condition")]',
        '//*[normalize-space(text())="Condition"]/ancestor::div[@role="button"][1]',
    ]

    IMAGE_INPUT = [
        '//input[@accept="image/*,image/heif,image/heic"]',
        '//input[@type="file"][contains(@accept, "image")]',
        '//input[@type="file"]',
        '//input[@accept][@type="file"]',
        '//div[@role="main"]//input[@type="file"]',
        '//form//input[@type="file"]',
    ]
    
    DESCRIPTION_FIELD = [
        '//textarea[@aria-label="Description"]',
        '//textarea[contains(@aria-label, "escription")]',
        '//textarea[contains(@placeholder, "escribe")]',
        '//div[@role="main"]//textarea',
        '//form//textarea',
    ]
    
    TAGS_FIELD = [
        '//span[text()="Product tags"]/following-sibling::div//textarea',
        '//label[.//span[contains(text(), "tags")]]//textarea',
        '//textarea[contains(@aria-label, "tag")]',
    ]
    
    NEXT_BUTTON = [
        '//div[@role="button"]//span[normalize-space(text())="Next"]',
        '//div[@aria-label="Next"]',
        '//span[normalize-space(text())="Next"][not(ancestor::nav)]',
        '//button[normalize-space()="Next"]',
        '//button[contains(normalize-space(.), "Next")]',
        '//*[@role="button" and contains(normalize-space(.), "Next")]',
    ]
    
    PUBLISH_BUTTON = [
        '//div[@role="button"]//span[normalize-space(text())="Publish"]',
        '//div[@aria-label="Publish"]',
        '//span[normalize-space(text())="Publish"][not(ancestor::nav)]',
        '//button[normalize-space()="Publish"]',
        '//button[contains(normalize-space(.), "Publish")]',
        '//*[@role="button" and contains(normalize-space(.), "Publish")]',
        '//*[contains(translate(@aria-label,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"publish")]',
    ]
    
    # Facebook nests Furniture under "Home & Garden" — open parent first if leaf not visible.
    # (Avoid a bare "Home" token — it can match unrelated labels.)
    CATEGORY_PARENT_FIRST: Tuple[str, ...] = ("Home & Garden",)

    @staticmethod
    def category_option(category: str) -> List[str]:
        """Generate XPaths for a category tile/option (exact match preferred)."""
        c = category.replace('"', '\\"')
        return [
            f'//*[@role="option"][normalize-space()="{c}"]',
            f'//*[@role="option"]//*[normalize-space()="{c}"]',
            f'//span[normalize-space()="{c}"]',
            f'//div[normalize-space()="{c}"]',
            f'//span[text()="{c}"]',
            f'//div[text()="{c}"]',
            f'//li[.//span[normalize-space()="{c}"]]',
            f'//*[@role="menuitem"][normalize-space()="{c}"]',
            f'//*[@role="menuitemradio"][.//*[normalize-space()="{c}"]]',
            f'//*[@role="gridcell"][.//*[normalize-space()="{c}"]]',
            f'//*[normalize-space(text())="{c}"]',
        ]
    
    @staticmethod
    def condition_option(condition: str) -> List[str]:
        """Generate XPaths for condition option."""
        return [
            f'//span[text()="{condition}"]',
            f'//div[@role="option"][.//span[text()="{condition}"]]',
            f'//li[contains(., "{condition}")]',
            f'//*[@role="option"][normalize-space()="{condition}"]',
        ]

# =============================================================================
# REACT-SAFE INPUT HELPER
# =============================================================================

# JavaScript for React-compatible input handling
_REACT_SET_VALUE_JS = """
(function(el, text) {
    // Step 1: focus and clear
    el.scrollIntoView({block: 'center', behavior: 'smooth'});
    el.focus();
    el.click();

    // Step 2: Select all existing content and delete it
    el.select ? el.select() : null;
    document.execCommand('selectAll', false, null);
    document.execCommand('delete', false, null);

    // Step 3: Insert new text via execCommand (React-friendly)
    var inserted = document.execCommand('insertText', false, text);

    if (!inserted) {
        // Fallback: native setter trick for React fiber
        var nativeInputValueSetter = Object.getOwnPropertyDescriptor(
            window.HTMLInputElement.prototype, 'value'
        );
        var nativeTextAreaValueSetter = Object.getOwnPropertyDescriptor(
            window.HTMLTextAreaElement.prototype, 'value'
        );
        var setter = el.tagName === 'TEXTAREA'
            ? nativeTextAreaValueSetter && nativeTextAreaValueSetter.set
            : nativeInputValueSetter && nativeInputValueSetter.set;

        if (setter) {
            setter.call(el, text);
        } else {
            el.value = text;
        }

        // Fire React-expected synthetic events
        el.dispatchEvent(new Event('input',  {bubbles: true, cancelable: true}));
        el.dispatchEvent(new Event('change', {bubbles: true, cancelable: true}));
    }

    // Step 4: Always fire blur so React validates the field
    el.dispatchEvent(new Event('blur', {bubbles: true}));

    return el.value;
})(arguments[0], arguments[1]);
"""

# =============================================================================
# ACTIVITY LOGGING
# =============================================================================

class ActivityLogger:
    """Thread-safe activity logging for API access."""
    
    _log: List[Dict[str, Any]] = []
    
    @classmethod
    def log(cls, account_email: str, action: str, details: str = "") -> None:
        """Log an activity entry."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "account": account_email,
            "action": action,
            "details": details,
        }
        with _activity_log_lock:
            cls._log.append(entry)
            while len(cls._log) > Config.MAX_ACTIVITY_LOG:
                cls._log.pop(0)
        
        # Persist to file
        try:
            existing = []
            if os.path.exists(Config.ACTIVITY_LOG_FILE):
                with open(Config.ACTIVITY_LOG_FILE, "r", encoding="utf-8") as f:
                    try:
                        existing = json.load(f)
                    except JSONDecodeError:
                        existing = []
            existing.append(entry)
            existing = existing[-Config.MAX_ACTIVITY_LOG:]
            with open(Config.ACTIVITY_LOG_FILE, "w", encoding="utf-8") as f:
                json.dump(existing, f, indent=2)
        except Exception as e:
            logger.warning(f"Could not write activity log: {e}")
    
    @classmethod
    def get_log(cls) -> List[Dict[str, Any]]:
        """Get activity log from file."""
        try:
            if os.path.exists(Config.ACTIVITY_LOG_FILE):
                with open(Config.ACTIVITY_LOG_FILE, "r", encoding="utf-8") as f:
                    try:
                        return json.load(f)
                    except JSONDecodeError:
                        return []
        except Exception as e:
            logger.warning(f"Could not read activity log: {e}")
        return []
    
    @classmethod
    def clear(cls) -> None:
        """Clear activity log."""
        with _activity_log_lock:
            cls._log.clear()
        try:
            if os.path.exists(Config.ACTIVITY_LOG_FILE):
                os.remove(Config.ACTIVITY_LOG_FILE)
        except Exception as e:
            logger.warning(f"Could not clear activity log: {e}")

# =============================================================================
# HELPER UTILITIES
# =============================================================================

class Helpers:
    """Utility functions for automation."""
    
    @staticmethod
    def human_wait(min_sec: float = None, max_sec: float = None) -> None:
        """Random delay to simulate human behavior."""
        min_sec = min_sec or Config.MIN_WAIT
        max_sec = max_sec or Config.MAX_WAIT
        time.sleep(random.uniform(min_sec, max_sec))
    
    @staticmethod
    def scroll(driver, times: int = 2) -> None:
        """Scroll page to simulate browsing."""
        for _ in range(times):
            driver.execute_script(f"window.scrollBy(0, {random.randint(150, 400)});")
            time.sleep(random.uniform(0.3, 0.7))
    
    @staticmethod
    def safe_click(driver, element) -> bool:
        """Click element with JavaScript fallback."""
        try:
            element.click()
            return True
        except (ElementClickInterceptedException, WebDriverException):
            try:
                driver.execute_script("arguments[0].click();", element)
                return True
            except Exception:
                return False
    
    @staticmethod
    def wait_for_page_load(driver, timeout: int = None) -> bool:
        """Wait for page to fully load."""
        timeout = timeout or Config.PAGE_LOAD_TIMEOUT
        for _ in range(timeout):
            try:
                if driver.execute_script("return document.readyState") == "complete":
                    return True
            except Exception:
                pass
            time.sleep(1)
        return False
    
    @staticmethod
    def get_current_url_safe(driver) -> str:
        """Safely get current URL."""
        try:
            return driver.current_url
        except Exception:
            return ""
    
    @staticmethod
    def find_element_with_strategies(
        driver,
        xpaths: List[str],
        timeout: int = None,
        clickable: bool = False
    ) -> Optional[Any]:
        """Find element using multiple XPath strategies."""
        timeout = timeout or Config.ELEMENT_TIMEOUT
        per_xpath_timeout = max(2, timeout // len(xpaths))
        
        for xpath in xpaths:
            try:
                condition = (
                    EC.element_to_be_clickable((By.XPATH, xpath))
                    if clickable
                    else EC.presence_of_element_located((By.XPATH, xpath))
                )
                element = WebDriverWait(driver, per_xpath_timeout).until(condition)
                if element.is_displayed():
                    return element
            except (TimeoutException, StaleElementReferenceException, NoSuchElementException):
                continue
        return None

    @staticmethod
    def fill_react_field(driver, element, text: str) -> bool:
        """Fill React-controlled input field."""
        try:
            result = driver.execute_script(_REACT_SET_VALUE_JS, element, text)
            time.sleep(0.3)
            actual = driver.execute_script("return arguments[0].value;", element)
            if actual and len(str(actual)) > 0:
                logger.debug(f"  React field filled: '{str(actual)[:40]}'")
                return True
            else:
                logger.warning(f"  React field appears empty after fill (got: '{actual}')")
                return False
        except Exception as e:
            logger.warning(f"  fill_react_field error: {e}")
            return False
    
    @staticmethod
    def retry_action(action, max_retries: int = None, delay: float = None):
        """Retry action with exponential backoff."""
        max_retries = max_retries or Config.MAX_RETRIES
        delay = delay or Config.RETRY_DELAY
        for attempt in range(max_retries):
            try:
                return action()
            except Exception as e:
                if attempt < max_retries - 1:
                    logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying...")
                    time.sleep(delay * (attempt + 1))
                else:
                    raise
        return None
    
    @staticmethod
    def save_debug_snapshot(driver, label: str = "debug") -> None:
        """Save screenshot and page source for debugging."""
        try:
            ts = datetime.now().strftime("%H%M%S")
            driver.save_screenshot(f"debug_{label}_{ts}.png")
            with open(f"debug_{label}_{ts}.html", "w", encoding="utf-8") as f:
                f.write(driver.page_source)
            logger.info(f"Debug saved: debug_{label}_{ts}.png")
        except Exception as e:
            logger.warning(f"Debug snapshot failed: {e}")
    
    @staticmethod
    def ensure_on_create_page(driver) -> bool:
        """Verify and recover to create listing page."""
        current_url = Helpers.get_current_url_safe(driver).lower()
        if "marketplace/create" in current_url:
            return True
        logger.warning(f"Not on create page (URL: {current_url[:80]}), navigating back...")
        try:
            driver.get(Config.CREATE_LISTING_URL)
            Helpers.wait_for_page_load(driver)
            time.sleep(2)
            current_url = Helpers.get_current_url_safe(driver).lower()
            if "marketplace/create" in current_url:
                logger.info("Recovered to create page")
                return True
            else:
                logger.error(f"Failed to recover to create page (URL: {current_url[:80]})")
                return False
        except Exception as e:
            logger.error(f"Error recovering to create page: {e}")
            return False

# =============================================================================
# BROWSER MANAGER
# =============================================================================
# ================================================================

class BrowserManager:
    """Manages Chrome browser instances with persistent profiles."""
    
    @staticmethod
    def get_profile_path(email: str) -> str:
        """Get profile directory path for email."""
        safe_name = re.sub(r"[^a-zA-Z0-9_.-]", "_", email)
        path = os.path.join(Config.PROFILES_DIR, safe_name)
        os.makedirs(path, exist_ok=True)
        return path

    @staticmethod
    def _cleanup_profile_locks(profile_path: str) -> None:
        """Remove stale Chromium lock files from crashed sessions."""
        stale_files = [
            "SingletonLock",
            "SingletonCookie",
            "SingletonSocket",
            "DevToolsActivePort",
        ]
        for name in stale_files:
            file_path = os.path.join(profile_path, name)
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception:
                # Non-fatal; we'll still try to launch.
                pass
    
    @staticmethod
    def create_driver(email: str) -> Any:
        """Create Chrome driver with persistent profile and robust recovery."""
        logger.info(f"Opening Chrome for {email}...")
        profile_path = BrowserManager.get_profile_path(email)
        logger.info(f"  Profile: {profile_path}")

        last_error = None
        for attempt in range(1, 4):
            driver = None
            try:
                BrowserManager._cleanup_profile_locks(profile_path)

                with _browser_launch_lock:
                    driver = Driver(
                        uc=True,
                        headless=Config.HEADLESS,
                        user_data_dir=profile_path,
                        chromium_arg="start-maximized",
                        page_load_strategy="eager",
                    )

                # Validate a usable top-level window exists.
                if not driver.window_handles:
                    raise WebDriverException("No browser window handles available after launch")

                try:
                    _ = driver.current_window_handle
                except Exception as e:
                    raise WebDriverException(f"Driver launched but current window is unavailable: {e}")

                # Set timeouts immediately
                try:
                    driver.set_page_load_timeout(25)
                    driver.set_script_timeout(20)
                    driver.implicitly_wait(5)
                except Exception as e:
                    logger.warning(f"Timeout setup warning: {e}")

                # Open Marketplace directly — avoids data:text/html Loading… placeholder stuck in address bar
                try:
                    driver.get(Config.MARKETPLACE_URL)
                except Exception as e:
                    logger.warning(f"Initial Marketplace navigation: {e} — stopping load and continuing")
                    try:
                        driver.execute_script("window.stop();")
                    except Exception:
                        pass
                finally:
                    try:
                        driver.set_page_load_timeout(30)
                    except Exception:
                        pass

                if not Config.HEADLESS:
                    ensure_chrome_maximized(driver, headless=False)

                logger.info(f"Chrome ready for {email}")
                return driver

            except Exception as e:
                last_error = e
                logger.warning(f"Chrome launch attempt {attempt}/3 failed for {email}: {e}")
                if driver is not None:
                    try:
                        driver.quit()
                    except Exception:
                        pass
                time.sleep(1.5 * attempt)

        raise WebDriverException(
            f"Failed to launch Chrome after retries for {email}: {last_error}"
        )
    
    @staticmethod
    def quit_driver(driver) -> None:
        """Close browser safely."""
        if driver is None:
            return
        try:
            driver.quit()
            logger.info("Browser closed successfully")
        except Exception as e:
            logger.warning(f"Error closing browser: {e}")

# =============================================================================
# LOGIN HANDLER
# =============================================================================

class LoginHandler:
    
    @staticmethod
    def is_logged_in(driver) -> bool:
        """Check if user is logged in by URL and page content."""
        current_url = Helpers.get_current_url_safe(driver).lower()
        # Must be on Facebook domain; pages like Google/new-tab are not valid login states.
        if "facebook.com" not in current_url:
            return False
        
        # If URL indicates login/checkpoint page, not logged in
        if "login" in current_url or "checkpoint" in current_url or "two_step" in current_url:
            return False
        
        # Also check if login form is present on page (Facebook sometimes shows login form without redirect)
        try:
            # Look for login form elements
            login_form = driver.find_elements(By.XPATH, '//input[@name="email"] | //input[@name="pass"] | //button[@name="login"]')
            if len(login_form) >= 2:  # Both email and password fields present
                logger.info("   Login form detected on page")
                return False
        except Exception:
            pass
        
        return True
    
    @staticmethod
    def handle_landing_page(driver) -> None:
        Helpers.human_wait(2, 3)
        if "login" not in Helpers.get_current_url_safe(driver).lower():
            try:
                login_link = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH,
                        "//a[contains(@href,'login')] | "
                        "//div[@role='button'][contains(.,'Log')]"
                    ))
                )
                login_link.click()
                logger.info("Passed through FB landing page")
                Helpers.human_wait(3, 4)
            except Exception:
                pass
    
    @staticmethod
    def enter_credentials(driver, email: str, password: str) -> bool:
        email_field = Helpers.find_element_with_strategies(
            driver, XPathStrategies.EMAIL_FIELD, timeout=10
        )
        if not email_field:
            logger.error("❌ Email field not found")
            return False
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", email_field)
        Helpers.human_wait(0.3, 0.5)
        email_field.click()
        email_field.clear()
        for char in email:
            email_field.send_keys(char)
            time.sleep(random.uniform(0.03, 0.06))
        Helpers.human_wait(0.4, 0.7)
        
        pass_field = Helpers.find_element_with_strategies(
            driver, XPathStrategies.PASSWORD_FIELD, timeout=8
        )
        if not pass_field:
            logger.error("❌ Password field not found")
            return False
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", pass_field)
        Helpers.human_wait(0.3, 0.5)
        pass_field.click()
        pass_field.clear()
        for char in password:
            pass_field.send_keys(char)
            time.sleep(random.uniform(0.03, 0.06))
        Helpers.human_wait(0.4, 0.7)
        return True
    
    @staticmethod
    def wait_for_login_complete(driver, timeout: int = 30) -> bool:
        """Wait until login is complete and user is on home page."""
        logger.info("   ⏳ Waiting for login to complete...")
        start_time = time.time()
        while time.time() - start_time < timeout:
            current_url = Helpers.get_current_url_safe(driver).lower()
            # Check if we're on home page (not login page)
            if "facebook.com" in current_url and "login" not in current_url:
                # Check if login form is no longer present
                try:
                    login_forms = driver.find_elements(By.XPATH, '//input[@name="email"] | //button[@name="login"]')
                    if len(login_forms) == 0:
                        logger.info("   ✅ Login complete - on home page")
                        return True
                except Exception:
                    pass
            # Check for 2FA or checkpoint
            if "two_step" in current_url or "checkpoint" in current_url:
                logger.info("   🔐 2FA/Checkpoint detected")
                return True  # Let handle_2fa take over
            time.sleep(1)
        logger.warning(f"   ⚠️ Login wait timeout after {timeout}s")
        return True  # Continue anyway
    
    @staticmethod
    def click_login_button(driver, pass_field) -> bool:
        login_clicked = False
        for xpath in XPathStrategies.LOGIN_BUTTON:
            try:
                btn = WebDriverWait(driver, 3).until(
                    EC.element_to_be_clickable((By.XPATH, xpath))
                )
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", btn)
                Helpers.human_wait(0.2, 0.4)
                btn.click()
                login_clicked = True
                logger.info("🖱️ Login button clicked")
                break
            except Exception:
                continue
        if not login_clicked:
            logger.warning("⚠️ Login button not found — pressing Enter")
            pass_field.send_keys(Keys.RETURN)
        
        # Wait for login to complete and redirect to home page
        LoginHandler.wait_for_login_complete(driver)
        return True
    
    @staticmethod
    def handle_captcha(driver) -> None:
        try:
            driver.uc_gui_click_captcha()
            Helpers.human_wait(2, 3)
        except Exception:
            pass
    
    @staticmethod
    def handle_2fa(driver, email: str) -> bool:
        current_url = Helpers.get_current_url_safe(driver).lower()
        if "two_step" not in current_url and "checkpoint" not in current_url:
            return True
        logger.info(f"\n🔐 2FA required for {email}")
        logger.info(f"⏳ Waiting up to {Config.TWO_FA_TIMEOUT}s — please complete 2FA...")
        driver.get(driver.current_url)
        for tick in range(Config.TWO_FA_TIMEOUT // 5):
            time.sleep(5)
            url = Helpers.get_current_url_safe(driver).lower()
            if "two_step" not in url and "checkpoint" not in url:
                logger.info("✅ 2FA completed!")
                return True
            logger.info(f"   ⏳ Waiting... ({(tick + 1) * 5}s / {Config.TWO_FA_TIMEOUT}s)")
        logger.error("❌ 2FA timeout — skipping account")
        return False
    
    @staticmethod
    def login(driver, email: str, password: str) -> bool:
        try:
            # Step 1: Navigate to Facebook with robust retry
            logger.info(f"📍 Navigating to Facebook for {email}...")
            navigated = False
            
            for attempt in range(3):
                try:
                    driver.set_page_load_timeout(15)
                    try:
                        driver.get(Config.FACEBOOK_URL)
                    except Exception:
                        try:
                            driver.execute_script("window.stop();")
                        except:
                            pass
                    
                    time.sleep(1)
                    current_url = Helpers.get_current_url_safe(driver).lower()
                    
                    if "facebook.com" in current_url:
                        logger.info(f"   ✅ On Facebook")
                        navigated = True
                        break
                    
                    # Try JS navigation
                    logger.info(f"   Trying JS redirect (attempt {attempt + 1})...")
                    driver.execute_script(f"window.location.replace('{Config.FACEBOOK_URL}');")
                    time.sleep(3)
                    
                    current_url = Helpers.get_current_url_safe(driver).lower()
                    if "facebook.com" in current_url:
                        logger.info(f"   ✅ JS navigation successful")
                        navigated = True
                        break
                        
                except Exception as nav_error:
                    logger.warning(f"   ⚠️ Attempt {attempt + 1} failed: {nav_error}")
                
                time.sleep(2)
            
            # Reset timeout
            try:
                driver.set_page_load_timeout(60)
            except:
                pass
            
            if not navigated:
                logger.warning("   ⚠️ Navigation incomplete, continuing anyway...")
            
            current_url = Helpers.get_current_url_safe(driver).lower()
            
            # Step 2: Check if already logged in on home page
            if LoginHandler.is_logged_in(driver):
                logger.info(f"✅ Already logged in on Facebook for {email}")
                # Go directly to marketplace
                logger.info(f"   📍 Navigating to Marketplace...")
                driver.get(Config.MARKETPLACE_URL)
                time.sleep(3)
                current_url = Helpers.get_current_url_safe(driver).lower()
                if "marketplace" in current_url and "login" not in current_url:
                    logger.info("   ✅ Marketplace accessible")
                    return True
                elif "login" in current_url:
                    logger.warning("   ⚠️ Session expired - marketplace redirected to login")
                    # Fall through to login flow below
                else:
                    logger.info("   ✅ On Facebook, marketplace should be accessible")
                    return True
            
            # Step 3: Not logged in - enter credentials
            logger.info(f"🔑 Login required for {email} — entering credentials...")
            
            LoginHandler.handle_captcha(driver)
            LoginHandler.handle_landing_page(driver)
            
            if not LoginHandler.enter_credentials(driver, email, password):
                return False
            
            pass_field = Helpers.find_element_with_strategies(
                driver, XPathStrategies.PASSWORD_FIELD, timeout=5
            )
            LoginHandler.click_login_button(driver, pass_field)
            LoginHandler.handle_captcha(driver)
            
            if not LoginHandler.handle_2fa(driver, email):
                return False
            
            # Step 4: After login, go to marketplace
            logger.info("   📍 Navigating to Marketplace after login...")
            driver.get(Config.MARKETPLACE_URL)
            time.sleep(4)
            current_url = Helpers.get_current_url_safe(driver).lower()
            
            if "login" in current_url:
                logger.error("   ❌ Still on login page after authentication")
                return False
            if "marketplace" in current_url:
                logger.info("   ✅ Marketplace accessible")
            elif "facebook.com" in current_url:
                logger.info("   ✅ On Facebook, marketplace should be accessible")
            else:
                logger.warning(f"   ⚠️ Unexpected URL: {current_url[:80]}")
            
            logger.info(f"✅ Logged in: {email}")
            return True
            
        except Exception as e:
            logger.error(f"❌ Login failed for {email}: {e}")
            traceback.print_exc()
            return False


# ================================================================
# LISTING FIELD HANDLERS (v2.2 — TITLE & PRICE FIXED)
# ================================================================

class ListingFieldHandler:
    """Handles filling individual listing fields with robust strategies."""

    # ------------------------------------------------------------------
    # IMAGE UPLOAD
    # ------------------------------------------------------------------
    @staticmethod
    def upload_image(driver, image_path: str) -> bool:
        logger.info(f"  📷 Uploading image: {image_path}")
        if not image_path:
            logger.warning("  ⚠️ No image path provided — skipping image")
            return False
        if not os.path.exists(image_path):
            logger.error(f"  ❌ Image file not found at: {image_path}")
            return False
        
        normalized_path = os.path.abspath(image_path)
        logger.info(f"  📷 Image file confirmed: {normalized_path}")
        
        try:
            time.sleep(2)
            file_input = driver.execute_script("""
                var inputs = document.querySelectorAll('input[type="file"]');
                for (var i = 0; i < inputs.length; i++) {
                    var input = inputs[i];
                    var accept = input.getAttribute('accept') || '';
                    if (accept.includes('image') || accept === '*' || accept === '') {
                        return input;
                    }
                }
                return inputs.length > 0 ? inputs[0] : null;
            """)
            
            if file_input:
                logger.info("  ✅ Found file input via JS")
                driver.execute_script("""
                    arguments[0].style.display = 'block';
                    arguments[0].style.visibility = 'visible';
                    arguments[0].style.opacity = '1';
                    arguments[0].style.position = 'absolute';
                    arguments[0].style.zIndex = '9999';
                """, file_input)
                file_input.send_keys(normalized_path)
                logger.info(f"  ✅ Image uploaded: {os.path.basename(image_path)}")
                time.sleep(3)
                return True
            else:
                logger.warning("  ⚠️ No file input found on page — skipping image")
                return False
        except Exception as e:
            logger.warning(f"  ⚠️ Image upload error: {e} — continuing without image")
            traceback.print_exc()
            return False

    # ------------------------------------------------------------------
    # TITLE  (v2.2 — React-safe fill with XPath + JS dual strategy)
    # ------------------------------------------------------------------
    @staticmethod
    def enter_title(driver, title: str) -> bool:
        logger.info(f"  📝 Entering title: {title[:40]}...")
        time.sleep(1.5)

        # ── Strategy 1: Find via XPath list, fill with React-safe helper ──
        field = Helpers.find_element_with_strategies(
            driver, XPathStrategies.TITLE_FIELD, timeout=12, clickable=True
        )
        if field:
            logger.info("  ✅ Title field found via XPath")
            ok = Helpers.fill_react_field(driver, field, title)
            if ok:
                logger.info(f"  ✅ Title entered (XPath strategy): {title[:40]}")
                time.sleep(Config.AFTER_FIELD_WAIT)
                return True
            else:
                logger.warning("  ⚠️ XPath fill returned empty — trying send_keys fallback")
                # send_keys fallback on same element
                try:
                    field.click()
                    field.send_keys(Keys.CONTROL + "a")
                    field.send_keys(Keys.DELETE)
                    time.sleep(0.2)
                    for char in title:
                        field.send_keys(char)
                        time.sleep(0.04)
                    actual = field.get_attribute("value")
                    if actual:
                        logger.info(f"  ✅ Title entered (send_keys fallback): {actual[:40]}")
                        time.sleep(Config.AFTER_FIELD_WAIT)
                        return True
                except Exception as e:
                    logger.warning(f"  ⚠️ send_keys fallback error: {e}")

        # ── Strategy 2: Pure JavaScript DOM scan ──
        logger.info("  ⚠️ XPath strategies failed — trying JS DOM scan for title...")
        try:
            field = driver.execute_script("""
                // Look for visible text inputs that are labelled 'Title'
                var candidates = document.querySelectorAll('input[type="text"], input:not([type])');
                for (var inp of candidates) {
                    if (inp.offsetParent === null) continue;
                    var label = (inp.getAttribute('aria-label') || '').toLowerCase();
                    var placeholder = (inp.getAttribute('placeholder') || '').toLowerCase();
                    var name = (inp.getAttribute('name') || '').toLowerCase();
                    if (label.includes('title') || placeholder.includes('title') || name.includes('title')) {
                        return inp;
                    }
                }
                // Fallback: find span/label with text "Title" and grab nearby input
                var spans = document.querySelectorAll('span, label');
                for (var sp of spans) {
                    if (sp.innerText && sp.innerText.trim() === 'Title') {
                        var container = sp.closest('div[class]') || sp.parentElement;
                        if (container) {
                            var inp = container.querySelector('input');
                            if (inp && inp.offsetParent !== null) return inp;
                            // Go up one more level
                            var parent = container.parentElement;
                            if (parent) {
                                inp = parent.querySelector('input');
                                if (inp && inp.offsetParent !== null) return inp;
                            }
                        }
                    }
                }
                return null;
            """)

            if field:
                ok = Helpers.fill_react_field(driver, field, title)
                if ok:
                    logger.info(f"  ✅ Title entered (JS DOM scan): {title[:40]}")
                    time.sleep(Config.AFTER_FIELD_WAIT)
                    return True
                else:
                    # Last resort: ActionChains keyboard simulation
                    try:
                        ActionChains(driver).move_to_element(field).click().perform()
                        time.sleep(0.3)
                        ActionChains(driver).key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).perform()
                        ActionChains(driver).send_keys(Keys.DELETE).perform()
                        time.sleep(0.2)
                        ActionChains(driver).send_keys(title).perform()
                        time.sleep(0.3)
                        actual = field.get_attribute("value") or ""
                        if actual:
                            logger.info(f"  ✅ Title entered (ActionChains): {actual[:40]}")
                            time.sleep(Config.AFTER_FIELD_WAIT)
                            return True
                    except Exception as e:
                        logger.warning(f"  ⚠️ ActionChains error: {e}")

        except Exception as e:
            logger.error(f"  ❌ JS DOM scan error: {e}")
            traceback.print_exc()

        logger.error("  ❌ All title entry strategies failed")
        return False

    # ------------------------------------------------------------------
    # PRICE  (v2.2 — React-safe fill with XPath + JS dual strategy)
    # ------------------------------------------------------------------
    @staticmethod
    def enter_price(driver, price: str) -> bool:
        logger.info(f"  💰 Entering price: ${price}")
        # Strip non-numeric characters (keep decimal point)
        clean_price = re.sub(r"[^\d.]", "", str(price))
        time.sleep(1.0)

        # ── Strategy 1: Find via XPath list, fill with React-safe helper ──
        field = Helpers.find_element_with_strategies(
            driver, XPathStrategies.PRICE_FIELD, timeout=12, clickable=True
        )
        if field:
            logger.info("  ✅ Price field found via XPath")
            ok = Helpers.fill_react_field(driver, field, clean_price)
            if ok:
                logger.info(f"  ✅ Price entered (XPath strategy): ${clean_price}")
                time.sleep(Config.AFTER_FIELD_WAIT)
                return True
            else:
                logger.warning("  ⚠️ XPath fill returned empty — trying send_keys fallback")
                try:
                    field.click()
                    field.send_keys(Keys.CONTROL + "a")
                    field.send_keys(Keys.DELETE)
                    time.sleep(0.2)
                    for char in clean_price:
                        field.send_keys(char)
                        time.sleep(0.05)
                    field.send_keys(Keys.TAB)
                    actual = field.get_attribute("value")
                    if actual:
                        logger.info(f"  ✅ Price entered (send_keys fallback): ${actual}")
                        time.sleep(Config.AFTER_FIELD_WAIT)
                        return True
                except Exception as e:
                    logger.warning(f"  ⚠️ Price send_keys fallback error: {e}")

        # ── Strategy 2: Pure JavaScript DOM scan ──
        logger.info("  ⚠️ XPath strategies failed — trying JS DOM scan for price...")
        try:
            field = driver.execute_script("""
                var inputs = document.querySelectorAll('input');
                for (var inp of inputs) {
                    if (inp.offsetParent === null) continue;
                    var label       = (inp.getAttribute('aria-label')   || '').toLowerCase();
                    var placeholder = (inp.getAttribute('placeholder')  || '').toLowerCase();
                    var name        = (inp.getAttribute('name')         || '').toLowerCase();
                    var type        = (inp.getAttribute('type')         || '').toLowerCase();
                    if (label.includes('price') || placeholder.includes('price') ||
                        name.includes('price')  || placeholder.includes('$')) {
                        return inp;
                    }
                }
                // Fallback: span/label with "Price" text
                var spans = document.querySelectorAll('span, label');
                for (var sp of spans) {
                    if (sp.innerText && sp.innerText.trim() === 'Price') {
                        var container = sp.closest('div[class]') || sp.parentElement;
                        if (container) {
                            var inp = container.querySelector('input');
                            if (inp && inp.offsetParent !== null) return inp;
                            var parent = container.parentElement;
                            if (parent) {
                                inp = parent.querySelector('input');
                                if (inp && inp.offsetParent !== null) return inp;
                            }
                        }
                    }
                }
                return null;
            """)

            if field:
                ok = Helpers.fill_react_field(driver, field, clean_price)
                if ok:
                    logger.info(f"  ✅ Price entered (JS DOM scan): ${clean_price}")
                    time.sleep(Config.AFTER_FIELD_WAIT)
                    return True
                else:
                    try:
                        ActionChains(driver).move_to_element(field).click().perform()
                        time.sleep(0.3)
                        ActionChains(driver).key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).perform()
                        ActionChains(driver).send_keys(Keys.DELETE).perform()
                        time.sleep(0.2)
                        ActionChains(driver).send_keys(clean_price).perform()
                        time.sleep(0.3)
                        actual = field.get_attribute("value") or ""
                        if actual:
                            logger.info(f"  ✅ Price entered (ActionChains): ${actual}")
                            time.sleep(Config.AFTER_FIELD_WAIT)
                            return True
                    except Exception as e:
                        logger.warning(f"  ⚠️ Price ActionChains error: {e}")
            else:
                logger.warning("  ⚠️ Price field not found with any method — continuing")

        except Exception as e:
            logger.warning(f"  ⚠️ Price JS DOM scan error: {e}")
            traceback.print_exc()

        return False

    # ------------------------------------------------------------------
    # CATEGORY
    # ------------------------------------------------------------------
    @staticmethod
    def _fb_click_category_token(driver, token: str) -> bool:
        """Click a visible category label (tile/option). Handles nested text lines."""
        paths = XPathStrategies.category_option(token)
        option = Helpers.find_element_with_strategies(driver, paths, timeout=4, clickable=True)
        if option:
            try:
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", option)
                if Helpers.safe_click(driver, option):
                    return True
                driver.execute_script("arguments[0].click();", option)
                time.sleep(0.2)
                return True
            except Exception:
                pass
        try:
            return bool(
                driver.execute_script(
                    r"""
                    var exact = arguments[0];
                    var want = exact.toLowerCase();
                    var selectors = '[role="option"],[role="menuitem"],[role="menuitemradio"],[role="menuitemcheckbox"],[role="gridcell"],li,a,div[role="button"],span';
                    var nodes = document.querySelectorAll(selectors);
                    for (var i = 0; i < nodes.length; i++) {
                        var el = nodes[i];
                        if (!el.offsetParent) continue;
                        var raw = (el.innerText || '').trim();
                        if (!raw) continue;
                        if (raw === exact || raw.toLowerCase() === want) {
                            el.scrollIntoView({block:'center'});
                            el.click();
                            return true;
                        }
                        var lines = raw.split(/\r\n|\r|\n/);
                        for (var j = 0; j < lines.length; j++) {
                            var line = lines[j].trim();
                            if (line === exact || line.toLowerCase() === want) {
                                el.scrollIntoView({block:'center'});
                                el.click();
                                return true;
                            }
                        }
                    }
                    return false;
                    """,
                    token,
                )
            )
        except Exception:
            return False

    @staticmethod
    def set_category(driver, category: str = "Furniture") -> bool:
        logger.info(f"  📁 Setting category: {category}")
        time.sleep(0.8)

        if not Helpers.ensure_on_create_page(driver):
            logger.error("  ❌ Not on create page before category")
            return False

        try:
            trigger = Helpers.find_element_with_strategies(
                driver, XPathStrategies.CATEGORY_TRIGGER, timeout=10, clickable=True
            )
            opened = False
            if trigger:
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", trigger)
                if not Helpers.safe_click(driver, trigger):
                    driver.execute_script("arguments[0].click();", trigger)
                opened = True
                time.sleep(0.5)

            if not opened:
                opened = bool(
                    driver.execute_script(
                        """
                        var elements = document.querySelectorAll('label, div[role="button"], div[role="combobox"], span');
                        for (var el of elements) {
                            if (el.offsetParent === null) continue;
                            var text = (el.innerText || '').trim();
                            var label = (el.getAttribute('aria-label') || '').toLowerCase();
                            if (text === 'Category' || text.startsWith('Category') || label.includes('category')) {
                                el.scrollIntoView({block: 'center'});
                                el.click();
                                return true;
                            }
                        }
                        return false;
                        """
                    )
                )

            if not opened:
                logger.warning("  ⚠️ Category dropdown not found")
                return False

            logger.info("  ✅ Category dropdown opened")
            time.sleep(1.2)

            # 1) Leaf often nested under "Home & Garden" on Marketplace — try direct, then parents.
            if ListingFieldHandler._fb_click_category_token(driver, category):
                logger.info(f"  ✅ Category selected: {category}")
                time.sleep(Config.AFTER_FIELD_WAIT)
                if not Helpers.ensure_on_create_page(driver):
                    logger.warning("  ⚠️ Navigation occurred during category selection")
                    return False
                return True

            for parent in XPathStrategies.CATEGORY_PARENT_FIRST:
                logger.info(f"  📂 Opening parent bucket: {parent}")
                if ListingFieldHandler._fb_click_category_token(driver, parent):
                    time.sleep(1.8)
                    try:
                        driver.execute_script(
                            """
                            document.querySelectorAll('[role="dialog"],[aria-modal="true"],[role="listbox"]').forEach(function(r){
                              try { r.scrollTop = Math.min(r.scrollTop + 400, r.scrollHeight); } catch(e) {}
                            });
                            """
                        )
                    except Exception:
                        pass
                    if ListingFieldHandler._fb_click_category_token(driver, category):
                        logger.info(f"  ✅ Category selected: {category} (via {parent})")
                        time.sleep(Config.AFTER_FIELD_WAIT)
                        if not Helpers.ensure_on_create_page(driver):
                            logger.warning("  ⚠️ Navigation occurred during category selection")
                            return False
                        return True

            logger.warning(f"  ⚠️ Category option '{category}' not found (try manual FB UI check)")
            return False

        except Exception as e:
            logger.warning(f"  ⚠️ Category error: {e}")
            traceback.print_exc()
            Helpers.ensure_on_create_page(driver)
            return False

    # ------------------------------------------------------------------
    # CONDITION
    # ------------------------------------------------------------------
    @staticmethod
    def set_condition(driver, condition: ListingCondition = ListingCondition.NEW) -> bool:
        condition_text = condition.value
        logger.info(f"  🏷️ Setting condition: {condition_text}")
        time.sleep(1)
        
        if not Helpers.ensure_on_create_page(driver):
            logger.error("  ❌ Not on create page before condition")
            return False
        
        try:
            trigger = Helpers.find_element_with_strategies(
                driver, XPathStrategies.CONDITION_TRIGGER, timeout=8, clickable=True
            )
            if trigger:
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", trigger)
                if not Helpers.safe_click(driver, trigger):
                    driver.execute_script("arguments[0].click();", trigger)
                time.sleep(1)

            clicked = driver.execute_script("""
                var elements = document.querySelectorAll('label, div[role="button"], div[role="combobox"]');
                for (var el of elements) {
                    if (el.offsetParent === null) continue;
                    var text  = (el.innerText || '').trim().toLowerCase();
                    var label = (el.getAttribute('aria-label') || '').toLowerCase();
                    if (text === 'condition' || text.startsWith('condition') || label.includes('condition')) {
                        el.scrollIntoView({block: 'center'});
                        el.click();
                        return true;
                    }
                }
                return false;
            """)
            
            if not clicked:
                logger.warning("  ⚠️ Condition dropdown not found")
                return False
            
            logger.info("  ✅ Condition dropdown clicked")
            time.sleep(2)

            option_paths = XPathStrategies.condition_option(condition_text)
            option = Helpers.find_element_with_strategies(driver, option_paths, timeout=8, clickable=True)
            if option:
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", option)
                if Helpers.safe_click(driver, option):
                    logger.info(f"  ✅ Condition selected: {condition_text}")
                    time.sleep(Config.AFTER_FIELD_WAIT)
                    return True

            selected = driver.execute_script(f"""
                var condition = '{condition_text}';
                var options = document.querySelectorAll('span, div[role="option"], li, div[role="menuitem"]');
                for (var opt of options) {{
                    if (opt.offsetParent === null) continue;
                    var text = (opt.innerText || '').trim();
                    if (text === condition || text.toLowerCase() === condition.toLowerCase() || text.toLowerCase().includes(condition.toLowerCase())) {{
                        opt.scrollIntoView({{block: 'center'}});
                        opt.click();
                        return true;
                    }}
                }}
                return false;
            """)
            
            if selected:
                logger.info(f"  ✅ Condition selected: {condition_text}")
                time.sleep(Config.AFTER_FIELD_WAIT)
                if not Helpers.ensure_on_create_page(driver):
                    logger.warning("  ⚠️ Navigation occurred during condition selection")
                    return False
                return True
            else:
                logger.warning(f"  ⚠️ Condition option '{condition_text}' not found")
                return False
                
        except Exception as e:
            logger.warning(f"  ⚠️ Condition error: {e}")
            traceback.print_exc()
            Helpers.ensure_on_create_page(driver)
            return False

    # ------------------------------------------------------------------
    # DESCRIPTION
    # ------------------------------------------------------------------
    @staticmethod
    def enter_description(driver, description: str) -> bool:
        logger.info("  📄 Entering description...")
        clean_description = re.sub(r'[<>{}|\\^~`]', '', description).strip()
        
        # Try XPath-based find first
        field = Helpers.find_element_with_strategies(
            driver, XPathStrategies.DESCRIPTION_FIELD, timeout=10, clickable=True
        )
        if field:
            ok = Helpers.fill_react_field(driver, field, clean_description)
            if ok:
                logger.info(f"  ✅ Description entered ({len(clean_description)} chars)")
                time.sleep(Config.AFTER_FIELD_WAIT)
                return True

        # JS fallback
        try:
            field = driver.execute_script("""
                var textareas = document.querySelectorAll('textarea');
                for (var ta of textareas) {
                    if (ta.offsetParent === null) continue;
                    var label       = (ta.getAttribute('aria-label')  || '').toLowerCase();
                    var placeholder = (ta.getAttribute('placeholder') || '').toLowerCase();
                    if (label.includes('description') || label.includes('describe') ||
                        placeholder.includes('description') || placeholder.includes('describe')) {
                        return ta;
                    }
                }
                // Fallback: first visible textarea
                for (var ta of textareas) {
                    if (ta.offsetParent !== null) return ta;
                }
                return null;
            """)
            if field:
                ok = Helpers.fill_react_field(driver, field, clean_description)
                if ok:
                    logger.info(f"  ✅ Description entered (JS fallback, {len(clean_description)} chars)")
                    time.sleep(Config.AFTER_FIELD_WAIT)
                    return True
        except Exception as e:
            logger.warning(f"  ⚠️ Description JS fallback error: {e}")

        logger.warning("  ⚠️ Description field not found")
        return False

    # ------------------------------------------------------------------
    # TAGS
    # ------------------------------------------------------------------
    @staticmethod
    def enter_tags(driver, tags: List[str]) -> bool:
        if not tags:
            return True
        logger.info(f"  🏷️ Entering tags: {tags[:5]}")
        try:
            tag_field = driver.execute_script("""
                var inputs = document.querySelectorAll('input, textarea');
                for (var inp of inputs) {
                    if (inp.offsetParent === null) continue;
                    var label       = (inp.getAttribute('aria-label')  || '').toLowerCase();
                    var placeholder = (inp.getAttribute('placeholder') || '').toLowerCase();
                    if (label.includes('tag') || placeholder.includes('tag')) {
                        inp.scrollIntoView({block: 'center'});
                        inp.focus();
                        return inp;
                    }
                }
                return null;
            """)
            if tag_field:
                for tag in tags[:5]:
                    tag_field.send_keys(tag)
                    tag_field.send_keys(Keys.RETURN)
                    time.sleep(0.3)
                logger.info("  ✅ Tags added")
                time.sleep(Config.AFTER_FIELD_WAIT)
                return True
            else:
                logger.warning("  ⚠️ Tag field not found — continuing")
                return False
        except Exception as e:
            logger.warning(f"  ⚠️ Tags error: {e}")
            return False

    # ------------------------------------------------------------------
    # NEXT BUTTON
    # ------------------------------------------------------------------
    @staticmethod
    def click_next(driver) -> bool:
        logger.info("  ➡️ Clicking Next...")
        time.sleep(1.5)
        try:
            next_btn = Helpers.find_element_with_strategies(
                driver, XPathStrategies.NEXT_BUTTON, timeout=8, clickable=True
            )
            if next_btn:
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", next_btn)
                if Helpers.safe_click(driver, next_btn):
                    logger.info("  ✅ Next clicked (XPath strategy)")
                    time.sleep(3)
                    return True

            clicked = driver.execute_script("""
                var buttons = document.querySelectorAll('div[role="button"], button, span[role="button"], a[role="button"]');
                for (var btn of buttons) {
                    if (btn.offsetParent === null) continue;
                    var text  = (btn.innerText || '').toLowerCase().trim();
                    var label = (btn.getAttribute('aria-label') || '').toLowerCase();
                    if ((text === 'next' || label.includes('next')) &&
                        !btn.closest('nav') && !btn.closest('[role="navigation"]')) {
                        btn.scrollIntoView({block: 'center'});
                        btn.click();
                        return true;
                    }
                }
                return false;
            """)
            if clicked:
                logger.info("  ✅ Next clicked")
                time.sleep(3)
                return True
            else:
                logger.warning("  ⚠️ Next button not found — proceeding anyway")
                return False
        except Exception as e:
            logger.warning(f"  ⚠️ Next click error: {e}")
            return False

    # ------------------------------------------------------------------
    # MEETUP PREFERENCES (intermediate step before publish)
    # ------------------------------------------------------------------
    @staticmethod
    def complete_meetup_preferences(driver) -> bool:
        """
        On some flows Facebook shows a delivery/meetup screen after first Next.
        This selects up to 3 meetup preferences and advances to the publish step.
        Returns True when either:
          - meetup step is not present, or
          - meetup step was completed and Next was clicked.
        """
        logger.info("  🚚 Checking meetup preferences step...")
        time.sleep(1.2)
        try:
            state = driver.execute_script("""
                function isVisible(el) {
                    if (!el) return false;
                    const style = window.getComputedStyle(el);
                    if (style.display === 'none' || style.visibility === 'hidden') return false;
                    const rect = el.getBoundingClientRect();
                    return rect.width > 0 && rect.height > 0;
                }

                const pageText = (document.body && document.body.innerText || '').toLowerCase();
                const hasMeetupHeader = pageText.includes('meetup preferences');
                if (!hasMeetupHeader) {
                    return { found: false, selected: 0 };
                }

                const sectionCandidates = Array.from(document.querySelectorAll('div, section, form'));
                let meetupSection = null;
                for (const sec of sectionCandidates) {
                    if (!isVisible(sec)) continue;
                    const txt = (sec.innerText || '').toLowerCase();
                    if (txt.includes('meetup preferences')) {
                        meetupSection = sec;
                        break;
                    }
                }
                if (!meetupSection) meetupSection = document.body;

                const targetLabels = ['public meetup', 'door pickup', 'porch pickup', 'pickup'];
                let selected = 0;

                // Try clicking explicit labels/rows by text first.
                const rows = Array.from(meetupSection.querySelectorAll('label, div[role="checkbox"], div'));
                for (const row of rows) {
                    if (!isVisible(row)) continue;
                    const txt = (row.innerText || '').toLowerCase().trim();
                    if (!txt) continue;
                    const matches = targetLabels.some(t => txt.includes(t));
                    if (!matches) continue;

                    const checkbox = row.querySelector('input[type="checkbox"]');
                    const ariaChecked = (row.getAttribute('aria-checked') || '').toLowerCase();
                    const alreadyChecked = (checkbox && checkbox.checked) || ariaChecked === 'true';
                    if (alreadyChecked) continue;
                    row.scrollIntoView({ block: 'center' });
                    row.click();
                    selected += 1;
                }

                // Fallback: ensure at most 3 visible checkboxes are checked.
                if (selected < 3) {
                    const checkboxes = Array.from(meetupSection.querySelectorAll('input[type="checkbox"]'))
                        .filter(isVisible);
                    for (const cb of checkboxes) {
                        if (!cb.checked) {
                            cb.scrollIntoView({ block: 'center' });
                            cb.click();
                            selected += 1;
                        }
                        const totalChecked = checkboxes.filter(x => x.checked).length;
                        if (totalChecked >= 3) break;
                    }
                }

                return { found: true, selected: selected };
            """)

            if not state or not state.get("found"):
                logger.info("  ℹ️ Meetup preferences step not present")
                return True

            logger.info(f"  ✅ Meetup preferences handled (newly selected: {state.get('selected', 0)})")
            time.sleep(1.0)

            if ListingFieldHandler.click_next(driver):
                logger.info("  ✅ Advanced past meetup preferences")
                return True

            logger.warning("  ⚠️ Could not advance after meetup preferences")
            return False
        except Exception as e:
            logger.warning(f"  ⚠️ Meetup preferences handling error: {e}")
            return False

    # ------------------------------------------------------------------
    # PUBLISH BUTTON
    # ------------------------------------------------------------------
    @staticmethod
    def click_publish(driver) -> bool:
        logger.info("  📤 Clicking Publish...")
        time.sleep(2)
        for attempt in range(3):
            try:
                publish_btn = Helpers.find_element_with_strategies(
                    driver, XPathStrategies.PUBLISH_BUTTON, timeout=8, clickable=True
                )
                if publish_btn:
                    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", publish_btn)
                    if Helpers.safe_click(driver, publish_btn):
                        logger.info("  ✅ Publish clicked (XPath strategy)")
                        time.sleep(4)
                        return True

                clicked = driver.execute_script("""
                    var buttons = document.querySelectorAll('div[role="button"], button, span[role="button"], a[role="button"]');
                    for (var btn of buttons) {
                        if (btn.offsetParent === null) continue;
                        var text  = (btn.innerText || '').toLowerCase().trim();
                        var label = (btn.getAttribute('aria-label') || '').toLowerCase();
                        if (((text === 'publish' || text.startsWith('publish') || text.includes('publish now')) || label.includes('publish')) &&
                            !btn.closest('nav') && !btn.closest('[role="navigation"]')) {
                            btn.scrollIntoView({block: 'center'});
                            btn.click();
                            return true;
                        }
                    }
                    return false;
                """)
                if clicked:
                    logger.info("  ✅ Publish clicked")
                    time.sleep(4)
                    return True
                else:
                    if attempt < 2:
                        logger.warning(f"  ⚠️ Publish not found, attempt {attempt + 1}/3 — scrolling...")
                        Helpers.scroll(driver, 2)
                        time.sleep(2)
                    else:
                        logger.error("  ❌ Publish button not found after 3 attempts")
                        return False
            except Exception as e:
                logger.warning(f"  ⚠️ Publish click error (attempt {attempt + 1}): {e}")
                if attempt < 2:
                    time.sleep(2)
        return False


# ================================================================
# LISTING PUBLISHER
# ================================================================

class ListingPublisher:
    
    @staticmethod
    def navigate_to_create_listing(driver) -> bool:
        try:
            current_url = Helpers.get_current_url_safe(driver).lower()
            logger.info(f"   Starting from URL: {current_url[:80]}")
            
            if current_url == "https://www.facebook.com/" or ("facebook.com" in current_url and "marketplace" not in current_url):
                logger.info("   📍 On Facebook homepage, navigating to Marketplace first...")
                driver.get(Config.MARKETPLACE_URL)
                Helpers.wait_for_page_load(driver)
                time.sleep(4)
                current_url = Helpers.get_current_url_safe(driver).lower()
                if "login" in current_url:
                    logger.error("   ❌ Session expired - redirected to login")
                    return False
            
            logger.info(f"   Loading create URL: {Config.CREATE_LISTING_URL}")
            driver.get(Config.CREATE_LISTING_URL)
            Helpers.wait_for_page_load(driver)
            time.sleep(5)
            
            current_url = Helpers.get_current_url_safe(driver).lower()
            logger.info(f"   Current URL: {current_url[:80]}")
            
            if "login" in current_url:
                logger.error("   ❌ Session expired - redirected to login page")
                return False
            
            if "marketplace/create" not in current_url:
                logger.warning("   ⚠️ Not on marketplace create page — retrying...")
                driver.get(Config.MARKETPLACE_URL)
                Helpers.wait_for_page_load(driver)
                time.sleep(3)
                driver.get(Config.CREATE_LISTING_URL)
                Helpers.wait_for_page_load(driver)
                time.sleep(5)
                current_url = Helpers.get_current_url_safe(driver).lower()
                if "login" in current_url:
                    logger.error("   ❌ Session expired on retry")
                    return False
                if "marketplace/create" not in current_url:
                    logger.error(f"   ❌ Still not on create page. Final URL: {current_url}")
                    return False
            
            time.sleep(3)
            Helpers.scroll(driver, 1)
            time.sleep(1)
            
            try:
                driver.uc_gui_click_captcha()
                logger.info("   CAPTCHA handled")
                time.sleep(3)
            except Exception:
                pass
            
            current_url = Helpers.get_current_url_safe(driver).lower()
            if "marketplace/create" in current_url:
                logger.info("   ✅ Create listing page loaded and ready")
                return True
            else:
                logger.error(f"   ❌ Failed to reach create page. Final URL: {current_url[:80]}")
                return False
                
        except Exception as e:
            logger.error(f"   ❌ Failed to load create page: {e}")
            traceback.print_exc()
            return False
    
    @staticmethod
    def publish_listing(driver, listing: ListingData, email: str) -> bool:
        logger.info(f"\n{'─'*50}")
        logger.info(f"📦 LISTING START: {listing.title[:40]}...")
        logger.info(f"{'─'*50}")
        ActivityLogger.log(email, "listing_start", listing.title[:40])
        
        try:
            # Step 0: Navigate
            logger.info("STEP 0/9: Navigating to create listing page...")
            if not ListingPublisher.navigate_to_create_listing(driver):
                logger.error("❌ STEP 0 FAILED: Could not navigate to create listing page")
                ActivityLogger.log(email, "listing_failed", "Navigation failed")
                return False
            logger.info("✅ STEP 0 COMPLETE")

            # Step 1: Image
            logger.info(f"\nSTEP 1/9: Uploading image...")
            if listing.image_path and os.path.exists(listing.image_path):
                result = ListingFieldHandler.upload_image(driver, listing.image_path)
                logger.info("✅ STEP 1 COMPLETE" if result else "⚠️ STEP 1 WARNING: Image may have failed")
            else:
                logger.warning("⚠️ STEP 1 SKIPPED: No image available")
            
            if not Helpers.ensure_on_create_page(driver):
                return False

            # Step 2: Title (REQUIRED)
            logger.info(f"\nSTEP 2/9: Entering title...")
            if not ListingFieldHandler.enter_title(driver, listing.title):
                logger.error("❌ STEP 2 FAILED: Title entry failed — aborting listing")
                ActivityLogger.log(email, "listing_failed", "Title field not found")
                Helpers.save_debug_snapshot(driver, "title_fail")
                return False
            logger.info("✅ STEP 2 COMPLETE")
            
            if not Helpers.ensure_on_create_page(driver):
                return False

            # Step 3: Price
            logger.info(f"\nSTEP 3/9: Entering price...")
            result = ListingFieldHandler.enter_price(driver, listing.price)
            logger.info("✅ STEP 3 COMPLETE" if result else "⚠️ STEP 3 WARNING: Price may not have been set")
            
            if not Helpers.ensure_on_create_page(driver):
                return False

            # Step 4: Category
            logger.info(f"\nSTEP 4/9: Setting category...")
            ListingFieldHandler.set_category(driver, listing.category)
            logger.info("✅ STEP 4 COMPLETE")
            
            if not Helpers.ensure_on_create_page(driver):
                return False

            # Step 5: Condition
            logger.info(f"\nSTEP 5/9: Setting condition...")
            ListingFieldHandler.set_condition(driver, listing.condition)
            logger.info("✅ STEP 5 COMPLETE")
            
            if not Helpers.ensure_on_create_page(driver):
                return False

            # Step 6: Description
            logger.info(f"\nSTEP 6/9: Entering description...")
            ListingFieldHandler.enter_description(driver, listing.description)
            logger.info("✅ STEP 6 COMPLETE")

            # Step 7: Tags
            logger.info(f"\nSTEP 7/9: Entering tags...")
            if listing.tags:
                ListingFieldHandler.enter_tags(driver, listing.tags)
            logger.info("✅ STEP 7 COMPLETE")

            time.sleep(2)

            # Step 8: Next
            logger.info(f"\nSTEP 8/9: Clicking Next button...")
            ListingFieldHandler.click_next(driver)
            logger.info("✅ STEP 8 COMPLETE")

            time.sleep(3)

            # Some accounts land on a second-step screen (delivery/meetup preferences)
            # that requires another Next before Publish becomes available.
            logger.info("\nSTEP 8.5/9: Completing meetup preferences (if shown)...")
            if not ListingFieldHandler.complete_meetup_preferences(driver):
                logger.warning("⚠️ STEP 8.5 WARNING: Could not complete meetup step")
            else:
                logger.info("✅ STEP 8.5 COMPLETE")
            time.sleep(2)

            # Step 9: Publish
            logger.info(f"\nSTEP 9/9: Clicking Publish button...")
            if not ListingFieldHandler.click_publish(driver):
                logger.warning("⚠️ STEP 9 RETRY: Scrolling and retrying...")
                Helpers.scroll(driver, 3)
                time.sleep(2)
                if not ListingFieldHandler.click_publish(driver):
                    logger.error("❌ STEP 9 FAILED: Could not click Publish button")
                    ActivityLogger.log(email, "listing_failed", listing.title[:40])
                    return False
            logger.info("✅ STEP 9 COMPLETE: Publish clicked")

            time.sleep(5)
            logger.info(f"\n{'─'*50}")
            logger.info(f"🎉 LISTING PUBLISHED: {listing.title}")
            logger.info(f"{'─'*50}")
            ActivityLogger.log(email, "listing_published", listing.title[:40])
            return True
            
        except Exception as e:
            logger.error(f"❌ Listing failed with exception: {e}")
            traceback.print_exc()
            ActivityLogger.log(email, "listing_failed", f"{listing.title[:40]} - {str(e)}")
            return False


# ================================================================
# INSIGHTS SCRAPER
# ================================================================

class InsightsScraper:
    
    @staticmethod
    def scrape(driver, email: str) -> Dict[str, int]:
        metrics = {
            "clicks_on_listings": 0,
            "listing_saves": 0,
            "listing_shares": 0,
            "marketplace_followers": 0
        }
        if driver is None:
            return metrics
        
        label_map = {
            "clicks on listings": "clicks_on_listings",
            "listing saves": "listing_saves",
            "listing shares": "listing_shares",
            "marketplace followers": "marketplace_followers",
        }
        
        try:
            driver.get(Config.INSIGHTS_URL)
            Helpers.human_wait(2, 3)
            for label_text, key in label_map.items():
                xpath = (
                    f"//*[translate(normalize-space(text()),"
                    f"'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='{label_text}']"
                )
                try:
                    label_el = WebDriverWait(driver, 5).until(
                        EC.presence_of_element_located((By.XPATH, xpath))
                    )
                    for levels in range(1, 7):
                        ancestor_path = "/".join([".."] * levels)
                        try:
                            container = label_el.find_element(By.XPATH, ancestor_path)
                            for candidate in container.find_elements(By.XPATH, ".//*"):
                                raw = (candidate.text.strip()
                                       .replace(",", "")
                                       .replace("\u202f", ""))
                                if re.match(r"^\d+(\.\d+)?[Kk]?$", raw) and raw != label_text:
                                    if raw.lower().endswith("k"):
                                        val = int(float(raw[:-1]) * 1000)
                                    else:
                                        val = int(float(raw))
                                    metrics[key] = val
                                    break
                            if metrics[key] > 0:
                                break
                        except Exception:
                            pass
                except Exception:
                    pass
            logger.info(f"📊 [{email}] Insights: {metrics}")
        except Exception as e:
            logger.warning(f"⚠️ Insights error for {email}: {e}")
        return metrics
    
    @staticmethod
    def save(email: str, metrics: Dict[str, int], listings_published: int) -> None:
        with _insights_lock:
            try:
                data = {}
                if os.path.exists(Config.INSIGHTS_FILE):
                    with open(Config.INSIGHTS_FILE, "r", encoding="utf-8") as f:
                        data = json.load(f)
            except Exception:
                data = {}
            
            today = datetime.now().strftime("%Y-%m-%d")
            entry = {**metrics, "date": today}
            if email not in data:
                data[email] = {"history": []}
            data[email].update({
                "logged_in": True,
                "listings_published": listings_published,
                "metrics": metrics,
                "last_updated": datetime.now().isoformat(),
            })
            history = [h for h in data[email].get("history", []) if h.get("date") != today]
            history.append(entry)
            data[email]["history"] = sorted(history, key=lambda x: x["date"])[-30:]
            with open(Config.INSIGHTS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            logger.info(f"💾 Insights saved for {email}")


# ================================================================
# ACCOUNT WORKER
# ================================================================

class AccountWorker:
    
    def __init__(self, account: Dict[str, Any], listings: List[ListingData]):
        self.email = account["email"]
        self.password = account["password"]
        self.listings = listings
        self.driver = None
        self.published_count = 0
        self.failed_count = 0
    
    def run(self) -> AutomationResult:
        result = AutomationResult(email=self.email, success=False)
        logger.info(f"\n{'='*60}")
        logger.info(f"🚀 ACCOUNT START: {self.email}")
        logger.info(f"{'='*60}")
        ActivityLogger.log(self.email, "account_start")
        time.sleep(1)
        
        try:
            # PHASE 1: Browser
            logger.info(f"\n[PHASE 1] Creating browser for {self.email}...")
            try:
                self.driver = BrowserManager.create_driver(self.email)
                logger.info(f"✅ [PHASE 1] Browser created")
            except Exception as e:
                logger.error(f"❌ [PHASE 1] FAILED: {e}")
                result.error_message = f"Browser creation failed: {e}"
                return result
            
            # PHASE 2: Login
            logger.info(f"\n[PHASE 2] Logging into Facebook...")
            if not LoginHandler.login(self.driver, self.email, self.password):
                logger.error(f"❌ [PHASE 2] FAILED: Login failed")
                ActivityLogger.log(self.email, "login_failed")
                result.error_message = "Login failed"
                return result
            logger.info(f"✅ [PHASE 2] Login successful")
            ActivityLogger.log(self.email, "login_success")
            
            # PHASE 3: Validate
            logger.info(f"\n[PHASE 3] Validating listings configuration...")
            if not self.listings:
                logger.error(f"❌ [PHASE 3] FAILED: No listings configured!")
                result.error_message = "No listings configured"
                return result
            
            num_listings = len(self.listings)
            logger.info(f"✅ [PHASE 3] Found {num_listings} listing(s) to create")
            for idx, listing in enumerate(self.listings, 1):
                img_name = os.path.basename(listing.image_path) if listing.image_path else 'NONE'
                logger.info(f"   Listing {idx}: '{listing.title[:40]}' | Image: {img_name}")
            
            consecutive_failures = 0
            ActivityLogger.log(self.email, "listings_start", f"Creating {num_listings} listing(s)")
            
            # PHASE 4: Process listings
            logger.info(f"\n[PHASE 4] Processing {num_listings} listing(s)...")
            for i, listing in enumerate(self.listings, 1):
                logger.info(f"\n{'─'*60}")
                logger.info(f"📋 LISTING {i}/{num_listings} for {self.email}")
                logger.info(f"{'─'*60}")
                try:
                    success = ListingPublisher.publish_listing(self.driver, listing, self.email)
                    if success:
                        self.published_count += 1
                        consecutive_failures = 0
                        logger.info(f"✅ LISTING {i}/{num_listings} SUCCEEDED")
                    else:
                        self.failed_count += 1
                        consecutive_failures += 1
                        logger.error(f"❌ LISTING {i}/{num_listings} FAILED")
                except Exception as e:
                    logger.error(f"❌ LISTING {i}/{num_listings} EXCEPTION: {e}")
                    traceback.print_exc()
                    self.failed_count += 1
                    consecutive_failures += 1
                
                if consecutive_failures >= Config.MAX_CONSECUTIVE_FAILURES:
                    logger.warning(f"⚠️ {Config.MAX_CONSECUTIVE_FAILURES} consecutive failures — stopping")
                    break
                
                if i < num_listings:
                    wait_time = random.uniform(3, 6)
                    logger.info(f"⏳ Waiting {wait_time:.1f}s before next listing...")
                    time.sleep(wait_time)
            
            logger.info(f"\n{'='*60}")
            logger.info(f"📊 ACCOUNT SUMMARY: {self.email}")
            logger.info(f"   Published: {self.published_count}/{num_listings}")
            logger.info(f"   Failed:    {self.failed_count}/{num_listings}")
            logger.info(f"{'='*60}")
            ActivityLogger.log(self.email, "account_done", f"{self.published_count}/{num_listings} published")
            
            result.success = True
            result.listings_published = self.published_count
            result.listings_failed = self.failed_count
            
        except Exception as e:
            logger.error(f"❌ ACCOUNT ERROR: {self.email}: {e}")
            traceback.print_exc()
            result.error_message = str(e)
        
        finally:
            # PHASE 5: Insights
            logger.info(f"\n[PHASE 5] Scraping insights...")
            ActivityLogger.log(self.email, "scraping_insights")
            try:
                metrics = InsightsScraper.scrape(self.driver, self.email)
                InsightsScraper.save(self.email, metrics, self.published_count)
                result.insights = metrics
            except Exception as e:
                logger.warning(f"⚠️ Insights scraping failed: {e}")
            
            # PHASE 6: Close browser
            logger.info(f"\n[PHASE 6] Closing browser...")
            BrowserManager.quit_driver(self.driver)
            ActivityLogger.log(self.email, "browser_closed")
            logger.info(f"✅ [PHASE 6] Browser closed")
            time.sleep(1)
        
        return result


# ================================================================
# BATCH PROCESSOR
# ================================================================

class BatchProcessor:
    
    def __init__(self, accounts, listings_config, batch_size=None):
        self.accounts = accounts
        self.listings_config = listings_config
        self.batch_size = batch_size or Config.CONCURRENT_BROWSERS
        self.results: List[AutomationResult] = []
        self._lock = threading.Lock()
    
    def _create_listings_for_account(self, account) -> List[ListingData]:
        listings = []
        titles       = self.listings_config.get("titles", [])
        description  = self.listings_config.get("description", "")
        price        = str(int(self.listings_config.get("price", 69)))
        tags         = self.listings_config.get("tags", [])
        images       = self.listings_config.get("images", [])
        num_listings = self.listings_config.get("listings_per_account", 1)
        
        logger.info(f"[LISTINGS] Creating {num_listings} listing(s) with {len(images)} image(s)")
        if not images:
            logger.warning("[LISTINGS] ⚠️ No images available!")
        
        for i in range(num_listings):
            image_path = images[i % len(images)] if images else ""
            listing = ListingData(
                title=titles[i % len(titles)] if titles else "Item for Sale",
                price=price,
                description=description,
                category="Furniture",
                condition=ListingCondition.NEW,
                image_path=image_path,
                tags=tags[:5] if tags else []
            )
            img_name = os.path.basename(image_path) if image_path else 'NONE'
            logger.info(f"[LISTINGS] #{i+1}: title='{listing.title[:30]}' price=${price} image='{img_name}'")
            listings.append(listing)
        return listings
    
    def _run_account_wrapper(self, account, account_num) -> AutomationResult:
        email = account.get("email", "unknown")
        logger.info(f"\n🟢 [{account_num}/{len(self.accounts)}] STARTING: {email}")
        try:
            listings = self._create_listings_for_account(account)
            worker = AccountWorker(account, listings)
            result = worker.run()
            with self._lock:
                self.results.append(result)
            status = "✅" if result.success else "❌"
            done = len([r for r in self.results if r.success])
            logger.info(f"\n{status} [{email}] COMPLETED — {done}/{len(self.accounts)} done")
            return result
        except Exception as e:
            logger.error(f"\n❌ [{email}] FAILED: {e}")
            traceback.print_exc()
            result = AutomationResult(email=email, success=False, error_message=str(e))
            with self._lock:
                self.results.append(result)
            return result
    
    def process(self) -> List[AutomationResult]:
        logger.info(f"\n{'='*60}")
        logger.info("AutoBotic — Facebook Marketplace Auto-Lister v2.2 (Title/Price Fixed)")
        logger.info(f"{'='*60}")
        logger.info(f"Accounts     : {len(self.accounts)}")
        logger.info(f"Batch size   : {self.batch_size}")
        logger.info(f"Listings/acct: {self.listings_config.get('listings_per_account', 1)}")
        logger.info(f"{'='*60}\n")
        
        if not self.accounts:
            logger.error("❌ No accounts configured!")
            return []
        
        with ThreadPoolExecutor(max_workers=self.batch_size) as pool:
            future_map = {
                pool.submit(self._run_account_wrapper, acc, idx): (idx, acc)
                for idx, acc in enumerate(self.accounts, 1)
            }
            for future in as_completed(future_map):
                idx, acc = future_map[future]
                try:
                    result = future.result()
                    logger.info(f"   📊 Account {idx} finished: {result.email}")
                except Exception as e:
                    logger.error(f"   ⚠️ Account {idx} error: {e}")
        
        completed = [r for r in self.results if r.success]
        failed    = [r for r in self.results if not r.success]
        logger.info(f"\n{'='*60}")
        logger.info("✅ AUTOMATION COMPLETE")
        logger.info(f"   Total     : {len(self.accounts)}")
        logger.info(f"   Completed : {len(completed)}")
        logger.info(f"   Failed    : {len(failed)}")
        if failed:
            logger.info(f"   Failed accounts: {', '.join([r.email for r in failed])}")
        logger.info(f"   Listings published: {sum(r.listings_published for r in self.results)}")
        logger.info(f"   Listings failed   : {sum(r.listings_failed for r in self.results)}")
        logger.info(f"{'='*60}")
        return self.results


# ================================================================
# CONFIGURATION LOADER
# ================================================================

class ConfigLoader:
    
    @staticmethod
    def parse_listings_range(listings_str: str) -> int:
        """
        Parse listings count from a plain integer string.
        The frontend now computes rangeEnd - rangeStart + 1 and sends
        that as a plain integer via listingsPerAccount, which the backend
        writes to AUTOBOTIC_LISTINGS_TO_DO.
        
        Still supports legacy "1-2" range format (picks random value).
        """
        listings_str = str(listings_str).strip()
        if "-" in listings_str:
            try:
                parts = listings_str.split("-")
                if len(parts) == 2:
                    min_val = int(parts[0].strip())
                    max_val = int(parts[1].strip())
                    if min_val > max_val:
                        min_val, max_val = max_val, min_val
                    result = random.randint(min_val, max_val)
                    logger.info(f"[CONFIG] Legacy range '{listings_str}' → selected {result}")
                    return result
            except (ValueError, IndexError) as e:
                logger.warning(f"[CONFIG] Could not parse range '{listings_str}': {e}, defaulting to 1")
                return 1
        try:
            result = int(listings_str)
            logger.info(f"[CONFIG] Listings count: {result}")
            return max(1, result)
        except ValueError:
            logger.warning(f"[CONFIG] Invalid listings value '{listings_str}', defaulting to 1")
            return 1
    
    @staticmethod
    def load() -> Dict[str, Any]:
        config = {
            "accounts": [],
            "listings_config": {
                "titles": [],
                "description": "",
                "price": "69",
                "tags": [],
                "images": [],
                "listings_per_account": 1
            },
            "batch_size": Config.CONCURRENT_BROWSERS
        }
        
        # Load from products.json
        try:
            with open(Config.PRODUCTS_FILE, "r", encoding="utf-8") as f:
                products = json.load(f)
            config["accounts"] = products.get("accounts", [])
            # Optional subset from AutoBotic UI (pipe-separated emails); API sets AUTOBOTIC_ACCOUNT_EMAILS
            filter_raw = os.environ.get("AUTOBOTIC_ACCOUNT_EMAILS", "").strip()
            if filter_raw:
                wanted = [p.strip() for p in filter_raw.split("|") if p.strip()]
                filtered = []
                seen = set()
                for a in config["accounts"]:
                    em = (a.get("email") or "").strip()
                    if not em:
                        continue
                    for w in wanted:
                        if em == w or em.lower() == w.lower():
                            if em not in seen:
                                seen.add(em)
                                filtered.append(a)
                            break
                logger.info(
                    "[CONFIG] Account filter from UI: %s matched account(s)",
                    len(filtered),
                )
                config["accounts"] = filtered
            config["listings_config"]["titles"] = products.get("titles", [])
            config["listings_config"]["description"] = products.get(
                "description", "Quality item for sale. Contact for details."
            )
            config["listings_config"]["price"] = str(int(products.get("price", 69)))
            config["listings_config"]["tags"] = products.get("mattress_tags", [])
        except Exception as e:
            logger.error(f"Could not load products.json: {e}")
        
        # Load images from configured folder
        images_folder = os.environ.get("AUTOBOTIC_MATTRESS_FOLDER", "").strip()
        if not images_folder:
            logger.error("[IMG] ❌ No image folder configured!")
        elif not os.path.exists(images_folder):
            logger.error(f"[IMG] ❌ Folder does not exist: '{images_folder}'")
        elif not os.path.isdir(images_folder):
            logger.error(f"[IMG] ❌ Path is not a folder: '{images_folder}'")
        else:
            logger.info(f"[IMG] Using configured folder: {images_folder}")
            try:
                images = sorted([
                    os.path.join(images_folder, fn)
                    for fn in os.listdir(images_folder)
                    if fn.lower().endswith((".jpg", ".jpeg", ".png", ".gif", ".webp"))
                ])
                config["listings_config"]["images"] = images
                logger.info(f"[IMG] Found {len(images)} images")
                if images:
                    logger.info(f"[IMG] Sample: {[os.path.basename(i) for i in images[:3]]}")
            except Exception as e:
                logger.error(f"[IMG] Could not read images folder: {e}")
        
        # Batch size
        batch_size = int(os.environ.get("AUTOBOTIC_BATCH_SIZE", str(Config.CONCURRENT_BROWSERS)))
        if batch_size > 0:
            config["batch_size"] = batch_size
        
        # Listings count — frontend now sends plain integer (rangeEnd - rangeStart + 1)
        listings_str = os.environ.get("AUTOBOTIC_LISTINGS_TO_DO", "1")
        config["listings_config"]["listings_per_account"] = ConfigLoader.parse_listings_range(listings_str)
        
        logger.info(
            f"[CONFIG] accounts={len(config['accounts'])} "
            f"batch_size={config['batch_size']} "
            f"listings_per_account={config['listings_config']['listings_per_account']} "
            f"images={len(config['listings_config']['images'])}"
        )
        return config


# ================================================================
# MAIN ENTRY POINT
# ================================================================

def main():
    headless_env = os.environ.get('AUTOBOTIC_HEADLESS_MODE')
    if headless_env is not None:
        set_headless_mode(headless_env.lower() in ('true', '1', 't'))
        
    os.makedirs(Config.PROFILES_DIR, exist_ok=True)
    config = ConfigLoader.load()
    
    if not config["accounts"]:
        logger.error("❌ No accounts configured in products.json!")
        return
    if not config["listings_config"]["images"]:
        logger.warning("⚠️ No images found — listings will be created without images")
    if not config["listings_config"]["titles"]:
        logger.error("❌ No titles configured in products.json!")
        return
    
    processor = BatchProcessor(
        accounts=config["accounts"],
        listings_config=config["listings_config"],
        batch_size=config["batch_size"]
    )
    return processor.process()


# ================================================================
# HEADLESS MODE CONTROL
# ================================================================

_headless_mode = False

def get_headless_mode() -> bool:
    return Config.HEADLESS

def set_headless_mode(enabled: bool) -> bool:
    global _headless_mode
    Config.HEADLESS = bool(enabled)
    _headless_mode = Config.HEADLESS
    logger.info(f"Headless mode set to: {Config.HEADLESS}")
    return Config.HEADLESS

# ================================================================
# MODULE EXPORTS
# ================================================================

get_activity_log = ActivityLogger.get_log
clear_activity_log = ActivityLogger.clear

if __name__ == "__main__":
    main()