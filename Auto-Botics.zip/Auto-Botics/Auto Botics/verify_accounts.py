#!/usr/bin/env python3
"""
Validate chatbot + automation account wiring for every entry in products.json.
Does not open browsers or call Facebook (run listing/chatbot smoke tests locally).
"""

import json
import os
import sys

# Project root
ROOT = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT)


def main() -> int:
    with open("products.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    accounts = data.get("accounts") or []

    if len(accounts) != 4:
        print(f"[WARN] Expected 4 accounts in products.json, found {len(accounts)}")

    import chatbot

    print("=== Chatbot resolve_account_from_login_id ===")
    errors = []
    for i, acc in enumerate(accounts, start=1):
        email = acc.get("email", "")
        by_index = chatbot.resolve_account_from_login_id(i, accounts)
        by_email = chatbot.resolve_account_from_login_id(email, accounts)
        by_str_index = chatbot.resolve_account_from_login_id(str(i), accounts)

        ok = (
            by_index and by_index.get("email") == email
            and by_email and by_email.get("email") == email
            and by_str_index and by_str_index.get("email") == email
        )
        status = "OK" if ok else "FAIL"
        print(f"  [{status}] id={i} email={email!r}")
        if not ok:
            errors.append((i, email, by_index, by_email, by_str_index))

    # Phone / special chars: match by exact string
    for acc in accounts:
        em = acc["email"]
        if em.startswith("+"):
            r = chatbot.resolve_account_from_login_id(em, accounts)
            if not r or r.get("email") != em:
                print(f"  [FAIL] phone key {em!r}")
                errors.append(("phone", em))
            else:
                print(f"  [OK] phone key {em!r}")

    print("\n=== Automation account filter (ConfigLoader pattern) ===")
    try:
        import automation_script

        for acc in accounts:
            em = acc["email"]
            os.environ["AUTOBOTIC_ACCOUNT_EMAILS"] = em
            cfg = automation_script.ConfigLoader.load()
            got = [a["email"] for a in cfg["accounts"]]
            if got != [em]:
                print(f"  [FAIL] filter single {em!r} -> {got}")
                errors.append(("filter", em, got))
            else:
                print(f"  [OK] filter single {em!r}")

        all_four = "|".join(a["email"] for a in accounts)
        os.environ["AUTOBOTIC_ACCOUNT_EMAILS"] = all_four
        cfg = automation_script.ConfigLoader.load()
        got_emails = sorted([a["email"] for a in cfg["accounts"]])
        expect = sorted([a["email"] for a in accounts])
        if got_emails != expect:
            print(f"  [FAIL] filter all four -> {got_emails}")
            errors.append(("filter_all", got_emails))
        else:
            print(f"  [OK] filter all 4 accounts ({len(got_emails)} emails)")
        os.environ.pop("AUTOBOTIC_ACCOUNT_EMAILS", None)
    except Exception as e:
        print(f"  [FAIL] automation_script load: {e}")
        errors.append(("automation", str(e)))

    if errors:
        print(f"\nFAILED with {len(errors)} issue(s).")
        return 1
    print("\nAll account wiring checks passed.")
    print(
        "\nNote: Live Facebook automation/chatbot must be tested on your PC "
        "(Start Chatbot / Start Automation with all accounts selected)."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
