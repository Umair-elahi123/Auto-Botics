"""
Unit tests for simplified item-page popup chatbot (no browser).
"""

from unittest.mock import MagicMock, patch

import pytest

import chatbot


def test_find_popup_returns_element():
    mock_el = MagicMock()
    mock_el.is_displayed.return_value = True
    driver = MagicMock()
    driver.find_elements.return_value = [mock_el]

    assert chatbot._find_item_page_chat_popup(driver) is mock_el
    driver.find_elements.assert_called()


def test_find_popup_returns_none_when_hidden():
    mock_el = MagicMock()
    mock_el.is_displayed.return_value = False
    driver = MagicMock()
    driver.find_elements.return_value = [mock_el]

    assert chatbot._find_item_page_chat_popup(driver) is None


def test_get_buyer_name_strips_listing_title():
    span = MagicMock()
    span.text = "Maya · Massive Sale! Beds & Mattresses"
    popup = MagicMock()
    popup.find_elements.return_value = [span]

    assert chatbot._get_buyer_name_from_popup(popup) == "Maya"


def test_get_buyer_name_fallback():
    popup = MagicMock()
    popup.find_elements.return_value = []

    assert chatbot._get_buyer_name_from_popup(popup) == "Customer"


def test_accessibility_labels_set_direction():
    you_label = MagicMock()
    you_label.text = "Enter, Message sent 6:08 PM by You: What size do you need?"
    you_clean = MagicMock()
    you_clean.text = "What size do you need?"
    buyer_label = MagicMock()
    buyer_label.text = "Message sent 5:47 PM by Raqal: hi"
    buyer_clean = MagicMock()
    buyer_clean.text = "hi"
    spans = [you_label, you_clean, buyer_label, buyer_clean]
    popup = MagicMock()
    popup.find_elements = MagicMock(return_value=spans)

    messages = chatbot._get_popup_messages(popup)
    assert messages == [
        {"text": "What size do you need?", "is_outgoing": True},
        {"text": "hi", "is_outgoing": False},
    ]


def test_unicode_time_space_still_skips_accessibility_row():
    """U+202F between time and PM must not leave a duplicate IN accessibility line."""
    acc = MagicMock()
    acc.text = "Enter, Message sent 6:43\u202fPM by Raqal: here?"
    clean = MagicMock()
    clean.text = "here?"
    popup = MagicMock()
    popup.find_elements = MagicMock(return_value=[acc, clean])

    messages = chatbot._get_popup_messages(popup)
    assert messages == [{"text": "here?", "is_outgoing": False}]


def test_last_bubble_is_ours_waits():
    popup = MagicMock()
    messages = [
        {"text": "hi", "is_outgoing": False},
        {"text": "Thanks for reaching out!", "is_outgoing": True},
    ]

    with patch.object(chatbot, "_get_popup_messages", return_value=messages):
        with patch.object(chatbot, "load_conversation_history", return_value=[]):
            out = chatbot._get_last_unanswered_customer_message(
                popup, "a@b.com", "buyer_x"
            )

    assert out is None


def test_skips_truncated_copy_of_our_last_reply():
    """DOM can tag our bubble as IN; text is a prefix of saved assistant message."""
    popup = MagicMock()
    full_reply = (
        "We have King size mattresses starting at $190 for the Siesta Hybrid "
        "or $290 for the Paloma Pure Foam. Would you like to proceed?"
    )
    truncated_visible = "We have King size mattresses starting at $190 for the Siesta"
    messages = [{"text": truncated_visible, "is_outgoing": False}]
    history = [
        {"sender": "buyer", "message": "king mattress?"},
        {"sender": "assistant", "message": full_reply},
    ]

    with patch.object(chatbot, "_get_popup_messages", return_value=messages):
        with patch.object(chatbot, "load_conversation_history", return_value=history):
            out = chatbot._get_last_unanswered_customer_message(
                popup, "a@b.com", "item_1"
            )

    assert out is None


def test_skips_exact_duplicate_of_our_reply():
    popup = MagicMock()
    text = "Short reply from store."
    messages = [{"text": text, "is_outgoing": False}]
    history = [
        {"sender": "buyer", "message": "hi"},
        {"sender": "assistant", "message": text},
    ]

    with patch.object(chatbot, "_get_popup_messages", return_value=messages):
        with patch.object(chatbot, "load_conversation_history", return_value=history):
            out = chatbot._get_last_unanswered_customer_message(
                popup, "a@b.com", "item_1"
            )

    assert out is None


def test_same_message_skipped():
    popup = MagicMock()
    messages = [{"text": "hi", "is_outgoing": False}]
    history = [{"sender": "buyer", "message": "hi"}]

    with patch.object(chatbot, "_get_popup_messages", return_value=messages):
        with patch.object(chatbot, "load_conversation_history", return_value=history):
            out = chatbot._get_last_unanswered_customer_message(
                popup, "a@b.com", "buyer_x"
            )

    assert out is None


def test_new_message_returned():
    popup = MagicMock()
    messages = [
        {"text": "hi", "is_outgoing": False},
        {"text": "there", "is_outgoing": False},
    ]
    history = [{"sender": "buyer", "message": "hi"}]

    with patch.object(chatbot, "_get_popup_messages", return_value=messages):
        with patch.object(chatbot, "load_conversation_history", return_value=history):
            out = chatbot._get_last_unanswered_customer_message(
                popup, "a@b.com", "buyer_x"
            )

    assert out == "there"


def test_no_incoming_returns_none():
    popup = MagicMock()
    messages = [{"text": "What size?", "is_outgoing": True}]

    with patch.object(chatbot, "_get_popup_messages", return_value=messages):
        with patch.object(chatbot, "load_conversation_history", return_value=[]):
            out = chatbot._get_last_unanswered_customer_message(
                popup, "a@b.com", "buyer_x"
            )

    assert out is None


def test_full_conversation_flow():
    popup = MagicMock()
    messages = [
        {"text": "What size?", "is_outgoing": True},
        {"text": "Queen", "is_outgoing": False},
    ]
    history = [
        {"sender": "buyer", "message": "hi"},
        {"sender": "assistant", "message": "What size?"},
    ]

    with patch.object(chatbot, "_get_popup_messages", return_value=messages):
        with patch.object(chatbot, "load_conversation_history", return_value=history):
            out = chatbot._get_last_unanswered_customer_message(
                popup, "a@b.com", "item_1"
            )

    assert out == "Queen"


def test_send_message_types_and_submits():
    box = MagicMock()
    box.is_displayed.return_value = True
    popup = MagicMock()
    popup.find_elements = MagicMock(return_value=[box])
    driver = MagicMock()

    sent = chatbot._send_message_to_popup(driver, popup, "Hello!")

    assert sent is True
    assert box.send_keys.called
    chunks = [c[0][0] for c in box.send_keys.call_args_list if c[0]]
    joined = "".join(x for x in chunks if x != chatbot.Keys.RETURN)
    assert "Hello!" in joined or joined == "Hello!"
    last_call = box.send_keys.call_args_list[-1][0][0]
    assert last_call == chatbot.Keys.RETURN


def test_check_and_reply_full_flow():
    popup = MagicMock()
    driver = MagicMock()
    driver.current_url = "https://www.facebook.com/marketplace/item/12345/x"

    history_after_buyer = [
        {"sender": "buyer", "message": "hi"},
    ]

    with patch.object(chatbot, "_find_item_page_chat_popup", return_value=popup):
        with patch.object(
            chatbot, "_get_buyer_name_from_popup", return_value="Maya"
        ):
            with patch.object(
                chatbot,
                "_get_last_unanswered_customer_message",
                return_value="hi",
            ):
                with patch.object(
                    chatbot, "save_conversation"
                ) as save_conv:
                    with patch.object(
                        chatbot,
                        "load_conversation_history",
                        return_value=history_after_buyer,
                    ):
                        with patch.object(
                            chatbot,
                            "get_ai_reply",
                            return_value="What size bed do you need?",
                        ):
                            with patch.object(
                                chatbot,
                                "_send_message_to_popup",
                                return_value=True,
                            ):
                                with patch.object(
                                    chatbot, "log_activity"
                                ) as log_act:
                                    chatbot.check_and_reply_item_page(
                                        driver,
                                        "test@test.com",
                                        {},
                                        None,
                                    )

    assert save_conv.call_count == 2
    buyers = [c for c in save_conv.call_args_list if c[0][4] == "buyer"]
    assistants = [c for c in save_conv.call_args_list if c[0][4] == "assistant"]
    assert len(buyers) == 1 and len(assistants) == 1
    log_act.assert_called_once()
